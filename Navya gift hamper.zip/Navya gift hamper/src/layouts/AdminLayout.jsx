import React, { useState, useEffect } from 'react';
import { Outlet, NavLink, useLocation, useNavigate, Link } from 'react-router-dom';
import {
  LayoutDashboard,
  ShoppingBag,
  Gift,
  Tags,
  Users,
  MessageSquare,
  Settings,
  LogOut,
  ExternalLink,
  Menu,
  X,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { adminService } from '../services/adminService';

export const AdminLayout = () => {
  const { user, profile, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [badges, setBadges] = useState({ pendingOrders: 0, pendingReviews: 0 });

  // Close mobile drawer on route change
  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  // Load live counts for badges
  useEffect(() => {
    let isMounted = true;
    async function loadBadges() {
      try {
        const metrics = await adminService.getDashboardMetrics();
        if (isMounted && metrics.success) {
          setBadges((prev) => ({
            ...prev,
            pendingOrders: metrics.stats?.pendingOrders || 0
          }));
        }
        const revs = await adminService.getReviews({ status: 'pending', pageSize: 1 });
        if (isMounted) {
          setBadges((prev) => ({
            ...prev,
            pendingReviews: revs.total || 0
          }));
        }
      } catch (e) {
        console.warn('Could not load badge counts:', e);
      }
    }
    loadBadges();
    const interval = setInterval(loadBadges, 60000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const handleLogout = async () => {
    try {
      await signOut();
    } finally {
      navigate('/admin/login', { replace: true });
    }
  };

  // Sidebar navigation order as specified:
  // Dashboard, Orders, Products, Categories, Customers, Reviews, Settings
  const navItems = [
    {
      name: 'Dashboard',
      path: '/admin/dashboard',
      icon: LayoutDashboard,
      description: "Here's what's happening with your store today."
    },
    {
      name: 'Orders',
      path: '/admin/orders',
      icon: ShoppingBag,
      description: 'Manage and track customer orders.',
      badge: badges.pendingOrders > 0 ? badges.pendingOrders : null
    },
    {
      name: 'Products',
      path: '/admin/products',
      icon: Gift,
      description: 'Manage your gift collection and inventory.'
    },
    {
      name: 'Categories',
      path: '/admin/categories',
      icon: Tags,
      description: 'Organize hampers into curated collections.'
    },
    {
      name: 'Customers',
      path: '/admin/customers',
      icon: Users,
      description: 'Registered customer directory and spending history.'
    },
    {
      name: 'Reviews',
      path: '/admin/reviews',
      icon: MessageSquare,
      description: 'Moderate customer ratings and product testimonials.',
      badge: badges.pendingReviews > 0 ? badges.pendingReviews : null
    },
    {
      name: 'Settings',
      path: '/admin/settings',
      icon: Settings,
      description: 'Store operations, delivery rules, and inventory threshold.'
    }
  ];

  const getCurrentMeta = () => {
    if (location.pathname === '/admin/products/add') {
      return { title: 'Add Product', description: 'Create a new gift hamper in the store catalog.' };
    }
    if (location.pathname.startsWith('/admin/products/edit/')) {
      return { title: 'Edit Product', description: 'Modify pricing, stock, details, and photography.' };
    }
    const match = navItems.find((item) =>
      item.path === '/admin/dashboard'
        ? location.pathname === item.path
        : location.pathname.startsWith(item.path)
    );
    return match ? { title: match.name, description: match.description } : { title: 'Dashboard', description: '' };
  };

  const currentMeta = getCurrentMeta();

  return (
    <div className="min-h-screen bg-[#faf8f5] text-[#1a1815] flex flex-col md:flex-row antialiased font-sans">
      {/* ─── DESKTOP SIDEBAR ──────────────────────────────────────────────── */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-[#e8dfd1] shrink-0 sticky top-0 h-screen z-30 select-none">
        {/* Brand Header */}
        <div className="p-6 border-b border-[#f0e9df]">
          <Link to="/admin/dashboard" className="block group">
            <span className="font-serif tracking-widest text-base font-bold text-[#1a1815] block uppercase">
              NAVYA
            </span>
            <span className="font-serif tracking-wider text-xs text-[#8c7355] block -mt-0.5">
              GIFT HAMPER
            </span>
            <div className="mt-2.5 inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#f5f0e6] border border-[#e8dfd1]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#635340] font-semibold">
                OWNER PANEL
              </span>
            </div>
          </Link>
        </div>

        {/* Navigation items */}
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.path === '/admin/dashboard'
                ? location.pathname === item.path
                : location.pathname.startsWith(item.path);

            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={`flex items-center justify-between px-3.5 py-2.5 rounded-md text-xs font-medium transition-colors duration-150 group ${
                  isActive
                    ? 'bg-[#1a1815] text-white shadow-xs font-semibold'
                    : 'text-[#4a423b] hover:text-[#1a1815] hover:bg-[#f7f4ee]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-[#c5a880]' : 'text-[#8c7a65] group-hover:text-[#1a1815]'
                    }`}
                    strokeWidth={1.8}
                  />
                  <span>{item.name}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                      isActive
                        ? 'bg-[#c5a880] text-[#1a1815] font-bold'
                        : 'bg-[#f0e9df] text-[#635340] font-semibold'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Sidebar Bottom: Owner Account & Logout */}
        <div className="p-4 border-t border-[#f0e9df] bg-[#fdfcfb]">
          <div className="mb-3 px-2">
            <span className="text-[10px] font-mono uppercase tracking-wider text-[#8c7a65] block">
              Owner Account
            </span>
            <span className="text-xs font-medium text-[#1a1815] block truncate mt-0.5" title="supportnavya0@gmail.com">
              supportnavya0@gmail.com
            </span>
          </div>

          <button
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium text-[#8c4a4a] hover:text-rose-700 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition-colors"
          >
            <div className="flex items-center gap-2">
              <LogOut className="w-3.5 h-3.5" strokeWidth={1.8} />
              <span>Logout</span>
            </div>
            <span className="text-[10px] font-mono text-stone-400">Exit</span>
          </button>
        </div>
      </aside>

      {/* ─── MOBILE DRAWER OVERLAY ────────────────────────────────────────── */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-40 backdrop-blur-xs md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* ─── MOBILE DRAWER ────────────────────────────────────────────────── */}
      <aside
        className={`fixed top-0 left-0 bottom-0 w-72 bg-white border-r border-[#e8dfd1] z-50 flex flex-col transition-transform duration-200 ease-in-out md:hidden ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-5 border-b border-[#f0e9df] flex items-center justify-between">
          <div>
            <span className="font-serif tracking-widest text-sm font-bold text-[#1a1815] block uppercase">
              NAVYA
            </span>
            <span className="text-[10px] uppercase font-mono tracking-wider text-[#8c7355]">
              OWNER PANEL
            </span>
          </div>
          <button
            onClick={() => setMobileOpen(false)}
            className="p-1.5 rounded-md text-stone-500 hover:text-stone-900 hover:bg-stone-100"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.path === '/admin/dashboard'
                ? location.pathname === item.path
                : location.pathname.startsWith(item.path);

            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center justify-between px-3.5 py-2.5 rounded-md text-xs font-medium transition-colors ${
                  isActive
                    ? 'bg-[#1a1815] text-white font-semibold'
                    : 'text-[#4a423b] hover:text-[#1a1815] hover:bg-[#f7f4ee]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-4 h-4" strokeWidth={1.8} />
                  <span>{item.name}</span>
                </div>
                {item.badge && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#c5a880] text-[#1a1815] font-bold">
                    {item.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        <div className="p-4 border-t border-[#f0e9df] bg-[#fdfcfb] space-y-2">
          <Link
            to="/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-xs text-[#635340] hover:text-[#1a1815]"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open Customer Store</span>
          </Link>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center gap-2 text-xs text-rose-700 pt-2"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* ─── MAIN CONTENT AREA ────────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Subtle, Natural Top Header */}
        <header className="h-16 bg-white border-b border-[#e8dfd1] px-4 sm:px-6 lg:px-8 flex items-center justify-between shrink-0 sticky top-0 z-20">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setMobileOpen(true)}
              className="p-2 -ml-2 rounded-md text-[#635340] hover:text-[#1a1815] hover:bg-stone-100 md:hidden"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-serif font-bold text-[#1a1815] leading-tight truncate">
                {currentMeta.title}
              </h1>
              {currentMeta.description && (
                <p className="hidden sm:block text-xs text-[#7a6f64] truncate">
                  {currentMeta.description}
                </p>
              )}
            </div>
          </div>

          {/* Right Header items */}
          <div className="flex items-center gap-2.5 sm:gap-4 shrink-0">
            <Link
              to="/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-[#635340] hover:text-[#1a1815] px-3 py-1.5 rounded-md border border-[#e8dfd1] hover:border-[#c5a880] hover:bg-[#faf8f5] transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#8c7355]" />
              <span className="hidden sm:inline">View Store</span>
            </Link>

            {/* Owner profile chip */}
            <div className="flex items-center gap-2 pl-2 sm:pl-3 border-l border-[#e8dfd1]">
              <div className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] flex items-center justify-center font-serif font-bold text-xs">
                N
              </div>
              <div className="hidden lg:block text-left text-xs">
                <span className="text-[#1a1815] font-medium block leading-tight truncate max-w-[150px]">
                  supportnavya0@gmail.com
                </span>
                <span className="text-[10px] font-mono text-[#8c7355] block uppercase">
                  Store Owner
                </span>
              </div>

              <button
                type="button"
                onClick={handleLogout}
                title="Logout of admin"
                className="p-1.5 rounded-md text-[#7a6f64] hover:text-rose-700 hover:bg-rose-50 transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </header>

        {/* Page Content Body */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#faf8f5]">
          <div className="max-w-6xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};
