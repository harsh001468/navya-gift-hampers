import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Mail, Lock, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { BrandLogo } from '../components/BrandLogo';
import { insforge } from '../lib/insforge';

export const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [forgotMode, setForgotMode] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [isSendingReset, setIsSendingReset] = useState(false);
  const { signIn } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const returnTo = searchParams.get('returnTo') || '/profile';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    const res = await signIn({ email, password });
    setIsSubmitting(false);

    if (res.success) {
      navigate(returnTo);
    }
  };

  const handleForgotPassword = async (e) => {
    e.preventDefault();
    if (!forgotEmail.trim()) {
      addToast('Please enter your email address.', 'error');
      return;
    }
    setIsSendingReset(true);
    try {
      const { error } = await insforge.auth.sendResetPasswordEmail({ email: forgotEmail.trim() });
      if (error) {
        addToast(error.message || 'Failed to send reset email. Please try again.', 'error');
      } else {
        addToast('Password reset link sent! Please check your inbox.', 'success');
        setForgotMode(false);
        setForgotEmail('');
      }
    } catch {
      addToast('Failed to send reset email. Please try again.', 'error');
    }
    setIsSendingReset(false);
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16 space-y-6">
      <div className="text-center space-y-3">
        <div className="flex justify-center mb-2">
          <BrandLogo height="h-16" asLink={false} />
        </div>
        <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#8c7a65]">
          WELCOME BACK
        </span>
        <h1 className="font-serif text-3xl font-bold text-[#1a1815] uppercase tracking-wide">
          {forgotMode ? 'RESET PASSWORD' : 'SIGN IN'}
        </h1>
        <p className="font-serif italic text-stone-500 text-sm">
          {forgotMode
            ? '"Enter your email to receive a secure password reset link."'
            : '"Access your saved gift hampers, order history, and exclusive Privé rewards."'}
        </p>
      </div>

      <div className="bg-white rounded-xl p-8 border border-[#e8dfd1] shadow-sm">
        {forgotMode ? (
          /* ── Forgot Password Form ── */
          <form onSubmit={handleForgotPassword} className="space-y-4 font-sans text-xs">
            <div>
              <label className="block text-stone-700 font-semibold mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="your@email.com"
                  autoFocus
                  className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={isSendingReset}
              className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white font-semibold py-3 rounded-md uppercase tracking-wider transition-colors shadow-md flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <span>{isSendingReset ? 'Sending...' : 'Send Reset Link'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => { setForgotMode(false); setForgotEmail(''); }}
              className="w-full text-center text-[#8c7355] font-semibold hover:underline text-xs py-1 cursor-pointer"
            >
              ← Back to Sign In
            </button>
          </form>
        ) : (
          /* ── Login Form ── */
          <form onSubmit={handleSubmit} className="space-y-4 font-sans text-xs">
            <div>
              <label className="block text-stone-700 font-semibold mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-stone-700 font-semibold">Password</label>
                <button
                  type="button"
                  onClick={() => { setForgotMode(true); setForgotEmail(email); }}
                  className="text-[11px] text-[#8c7355] hover:underline cursor-pointer"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white font-semibold py-3 rounded-md uppercase tracking-wider transition-colors shadow-md flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <span>{isSubmitting ? 'Signing In...' : 'Sign In'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        <div className="mt-6 pt-6 border-t border-[#eee5d8] text-center text-xs text-stone-500 font-sans">
          <span>New to Navya Gift Hamper? </span>
          <Link
            to={`/signup?returnTo=${encodeURIComponent(returnTo)}`}
            className="text-[#8c7355] font-semibold hover:underline"
          >
            Create an Account
          </Link>
        </div>
      </div>
    </div>
  );
};
