import React, { useState } from 'react';
import { Mail, Phone, MessageCircle, Send, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { InstagramIcon } from '../components/SocialIcons';
import { useToast } from '../context/ToastContext';

export const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [openFaq, setOpenFaq] = useState(0);
  const { addToast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    addToast('Message received! Our dedicated concierge team will contact you shortly.', 'success');
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  const faqs = [
    {
      q: 'How long does shipping take across India?',
      a: 'We ship via express air logistics. Metro cities receive orders in 2-3 business days, while rest of India takes 3-4 days.'
    },
    {
      q: 'Can I add a personalized gift note to my order?',
      a: 'Yes! Every order includes a complimentary wax-sealed parchment greeting card where you can include a custom message.'
    },
    {
      q: 'Do you fulfill bulk corporate or wedding hamper orders?',
      a: 'Absolutely. We specialize in custom corporate branding, bulk wedding hampers, and personalized keepsakes. Contact us directly.'
    },
    {
      q: 'Can I customize the contents of a hamper?',
      a: 'Yes, you can specify preferences or custom items during checkout or reach out via WhatsApp for concierge curation.'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Header */}
      <div className="text-center space-y-3 max-w-xl mx-auto">
        <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#8c7a65]">
          WE WOULD LOVE TO HEAR FROM YOU
        </span>
        <h1 className="font-serif text-3xl sm:text-5xl font-bold text-[#1a1815] uppercase tracking-wide">
          CONTACT US
        </h1>
        <p className="font-serif italic text-stone-500 text-sm">
          “Have questions about a custom hamper or bulk celebration order? Reach our dedicated concierge team.”
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        {/* Contact Information & Details */}
        <div className="lg:col-span-5 bg-[#1a1815] text-[#faf8f5] rounded-xl p-8 space-y-8 shadow-xl border border-[#3e352b]">
          <div>
            <h2 className="font-serif text-2xl font-bold text-white tracking-widest uppercase">
              NAVYA GIFT HAMPER
            </h2>
            <p className="text-xs text-[#c5a880] uppercase tracking-widest mt-1 font-sans font-semibold">
              BESPOKE GIFTING STUDIO
            </p>
          </div>

          <div className="space-y-6 text-xs font-sans">
            <div className="flex items-start gap-4">
              <Mail className="w-5 h-5 text-[#c5a880] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">Email Support</span>
                <a href="mailto:Supportnavya0@gmail.com" className="text-stone-300 hover:text-[#c5a880] transition-colors">
                  Supportnavya0@gmail.com
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <InstagramIcon className="w-5 h-5 text-[#c5a880] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">Official Instagram</span>
                <a
                  href="https://www.instagram.com/navyagift_hamper?stkn=aDl5N3Q1NHZkb2Fv"
                  target="_blank"
                  rel="noreferrer"
                  className="text-stone-300 hover:text-[#c5a880] transition-colors"
                >
                  @navyagift_hamper
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <Phone className="w-5 h-5 text-[#c5a880] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">Call / Concierge</span>
                <a href="tel:+919772848274" className="text-stone-300 hover:text-white transition-colors">
                  +91 97728 48274
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <MessageCircle className="w-5 h-5 text-[#c5a880] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block">WhatsApp Concierge</span>
                <a
                  href="https://wa.me/message/SE4USKU3N2UNE1"
                  target="_blank"
                  rel="noreferrer"
                  className="text-stone-300 hover:text-[#25D366] transition-colors block"
                >
                  +91 97728 48274 (Click to Chat)
                </a>
                <span className="text-xs text-stone-400">Available Mon-Sat (10 AM - 7 PM IST)</span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-[#363028] text-[11px] text-stone-400 font-serif italic">
            “Curated with Love, Gifted with Emotion.”
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-7 bg-white rounded-xl p-8 border border-[#e8dfd1] shadow-sm space-y-6">
          <h3 className="font-serif text-xl font-bold text-[#1a1815] uppercase tracking-wider">
            SEND US A MESSAGE
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4 font-sans text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-stone-700 font-semibold mb-1">Your Full Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter your full name"
                  className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md p-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-semibold mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="Enter your email address"
                  className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md p-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                />
              </div>
            </div>

            <div>
              <label className="block text-stone-700 font-semibold mb-1">Phone Number</label>
              <input
                type="tel"
                required
                maxLength={10}
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value.replace(/\D/g, '') })}
                placeholder="10-digit mobile number"
                className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md p-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
              />
            </div>

            <div>
              <label className="block text-stone-700 font-semibold mb-1">Your Message or Inquiry</label>
              <textarea
                rows={4}
                required
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Tell us how we can assist you with your gift hamper..."
                className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md p-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
              />
            </div>

            <button
              type="submit"
              className="bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest px-8 py-3.5 rounded-md shadow-md transition-colors flex items-center justify-center gap-2"
            >
              <span>SEND MESSAGE</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="pt-12 border-t border-[#e8dfd1] space-y-6 max-w-4xl mx-auto">
        <div className="text-center space-y-1">
          <div className="flex items-center justify-center gap-2 text-xs font-bold text-[#8c7a65] uppercase tracking-widest">
            <HelpCircle className="w-4 h-4" />
            <span>FREQUENTLY ASKED QUESTIONS</span>
          </div>
          <h2 className="font-serif text-2xl font-bold text-[#1a1815]">NEED QUICK ANSWERS?</h2>
        </div>

        <div className="divide-y divide-[#e8dfd1] bg-white rounded-xl border border-[#e8dfd1] px-6 shadow-xs">
          {faqs.map((faq, index) => (
            <div key={index} className="py-4">
              <button
                onClick={() => setOpenFaq(openFaq === index ? null : index)}
                className="w-full flex items-center justify-between text-left font-serif font-bold text-sm text-[#1a1815]"
              >
                <span>{faq.q}</span>
                {openFaq === index ? <ChevronUp className="w-4 h-4 text-[#8c7355]" /> : <ChevronDown className="w-4 h-4 text-stone-400" />}
              </button>
              {openFaq === index && (
                <p className="mt-2 text-xs text-stone-600 font-sans leading-relaxed">
                  {faq.a}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
