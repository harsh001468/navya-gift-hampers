import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle2, Package, ArrowRight } from 'lucide-react';
import { orderService } from '../services/orderService';
import { BrandLogo } from '../components/BrandLogo';
import { useAuth } from '../context/AuthContext';

export const OrderSuccess = () => {
  const { orderId } = useParams();
  const { user } = useAuth();
  const [latestOrder, setLatestOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrder = async () => {
      setLoading(true);
      let ord = null;
      if (orderId) {
        ord = await orderService.getOrderById(orderId);
      }
      if (!ord && user?.id) {
        ord = await orderService.getRecentOrder(user.id);
      }
      setLatestOrder(ord);
      setLoading(false);
    };
    fetchOrder();

    const handleSync = (e) => {
      if (!e.detail?.type || e.detail.type === 'orders') {
        fetchOrder();
      }
    };
    window.addEventListener('navya:data_sync', handleSync);
    return () => window.removeEventListener('navya:data_sync', handleSync);
  }, [orderId, user]);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center space-y-8">
      {/* Animated Success Icon */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 20 }}
        className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner"
      >
        <CheckCircle2 className="w-14 h-14 stroke-[1.75]" />
      </motion.div>

      {/* Headings */}
      <div className="space-y-2">
        <div className="flex justify-center mb-3">
          <BrandLogo height="h-14" asLink={false} />
        </div>
        <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#8c7a65]">
          THANK YOU FOR YOUR ORDER
        </span>
        <h1 className="font-serif text-3xl sm:text-5xl font-bold text-[#1a1815] uppercase tracking-wide">
          ORDER CONFIRMED
        </h1>
        <p className="font-serif italic text-lg text-stone-600">
          “Curated with Love, Gifted with Emotion.”
        </p>
      </div>

      {/* Order Details Card */}
      {loading ? (
        <div className="p-8 bg-white rounded-xl border border-[#e8dfd1] max-w-md mx-auto text-xs font-sans text-stone-500">
          Loading confirmed order details...
        </div>
      ) : latestOrder ? (
        <div className="bg-white rounded-xl border border-[#e8dfd1] p-6 sm:p-8 shadow-sm text-left space-y-6 max-w-2xl mx-auto">
          {/* Order Header & Status Badges */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#e8dfd1] gap-3">
            <div>
              <span className="text-xs text-stone-500 uppercase tracking-wider block font-sans">Order Number</span>
              <span className="font-serif font-bold text-xl text-[#1a1815]">{latestOrder.orderId}</span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1 text-[11px] bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Status: {latestOrder.status || 'Confirmed'}
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] bg-emerald-600 text-white font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                Payment: {latestOrder.paymentStatus?.toUpperCase() || 'PAID'}
              </span>
            </div>
          </div>

          {/* Delivery & Payment Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
            {/* Delivery Estimate — prominent card */}
            <div className="bg-gradient-to-br from-[#f5f0e6] to-[#faf8f5] border border-[#dfc99e] rounded-xl p-4 space-y-1.5">
              <span className="text-stone-500 uppercase tracking-wider block text-[10px] font-bold">Estimated Delivery</span>
              <div className="flex items-center gap-2">
                <span className="text-base">🚚</span>
                <span className="font-serif font-bold text-[#1a1815] text-base">
                  {latestOrder.estimatedDelivery || '7–15 Days'}
                </span>
              </div>
              <p className="text-[11px] text-stone-600 leading-relaxed">
                Calculated from order confirmation. May vary due to courier delays, public holidays, weather, or address factors.
              </p>
            </div>
            <div className="bg-[#faf8f5] rounded-xl border border-[#e8dfd1] p-4 space-y-1.5">
              <span className="text-stone-500 uppercase tracking-wider block text-[10px] font-bold">Payment Method</span>
              <span className="font-bold text-[#1a1815] block mt-0.5">
                {latestOrder.paymentMethod || 'Google Pay / UPI'}
              </span>
              {latestOrder.transactionId && (
                <span className="text-[10px] text-stone-500 font-mono block">
                  Txn: {latestOrder.transactionId}
                </span>
              )}
            </div>
          </div>

          {/* Item List */}
          <div className="space-y-3">
            <h4 className="font-serif text-xs uppercase font-bold tracking-widest text-[#1a1815]">
              Ordered Items ({latestOrder.items?.length || 0})
            </h4>
            <div className="divide-y divide-[#f4efe6]">
              {latestOrder.items?.map((item, idx) => (
                <div key={item.key || idx} className="py-2.5 flex items-center justify-between text-xs font-sans">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.product?.images?.[0]}
                      alt={item.product?.name}
                      className="w-10 h-12 object-cover rounded-xs bg-stone-100 shrink-0"
                    />
                    <div>
                      <p className="font-bold text-stone-900">{item.product?.name}</p>
                      <p className="text-stone-500">Qty: {item.quantity} | {item.selectedSize || 'Standard'}</p>
                    </div>
                  </div>
                  <span className="font-bold text-stone-900">
                    ₹{((item.product?.price || 0) * (item.quantity || 1)).toLocaleString('en-IN')}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Shipping Address & Summary */}
          <div className="pt-4 border-t border-[#e8dfd1] grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
            <div>
              <span className="font-bold text-stone-900 block mb-1">Shipping Address:</span>
              <p className="text-stone-600">
                {latestOrder.customer?.name} ({latestOrder.customer?.phone})
                <br />
                {latestOrder.shippingAddress?.street}, {latestOrder.shippingAddress?.apartment}
                <br />
                {latestOrder.shippingAddress?.city}, {latestOrder.shippingAddress?.state} - {latestOrder.shippingAddress?.pincode}
              </p>
            </div>
            <div className="sm:text-right space-y-1">
              <span className="font-bold text-stone-900 block">Total Paid:</span>
              <span className="font-serif font-bold text-xl text-emerald-800 block">
                ₹{latestOrder.totalAmount?.toLocaleString('en-IN')}
              </span>
              <span className="text-[11px] text-stone-500 block">Paid to vishualk375-2@okaxis</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-6 bg-white rounded-lg border border-[#e8dfd1] max-w-md mx-auto text-xs font-sans text-stone-600">
          Your receipt details have been dispatched to your email address.
        </div>
      )}

      {/* Action Buttons */}
      <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
        <Link
          to="/profile"
          className="w-full sm:w-auto bg-white border border-[#e8dfd1] hover:border-[#1a1815] text-[#1a1815] text-xs uppercase font-bold tracking-widest px-6 py-3.5 rounded-md transition-colors flex items-center justify-center gap-2"
        >
          <Package className="w-4 h-4" />
          <span>View in My Orders</span>
        </Link>
        <Link
          to="/gifts"
          className="w-full sm:w-auto bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest px-8 py-3.5 rounded-md shadow-lg transition-colors flex items-center justify-center gap-2"
        >
          <span>Continue Shopping</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};
