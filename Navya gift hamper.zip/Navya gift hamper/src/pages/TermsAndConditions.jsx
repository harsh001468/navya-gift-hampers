import React from 'react';
import { Link } from 'react-router-dom';
import {
  FileText,
  ShieldCheck,
  Mail,
  MessageCircle,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { InstagramIcon } from '../components/SocialIcons';

export const TermsAndConditions = () => {
  const lastUpdatedDate = 'September 20, 2026';

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12 font-sans text-stone-800">
      {/* Breadcrumb navigation */}
      <nav className="flex items-center gap-2 text-xs text-stone-500">
        <Link to="/" className="hover:text-black transition-colors">
          Home
        </Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <span className="font-semibold text-[#1a1815]">Terms & Conditions</span>
      </nav>

      {/* Header Banner */}
      <div className="bg-[#141210] rounded-2xl p-8 sm:p-12 text-[#faf8f5] shadow-xl relative overflow-hidden border border-[#2c251e]">
        <div className="absolute top-0 right-0 opacity-10 translate-x-8 -translate-y-6 pointer-events-none">
          <Sparkles className="w-72 h-72 text-[#c5a880]" />
        </div>
        <div className="space-y-3 relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-[#8c7355]/30 text-[#e8dfd1] text-[10px] uppercase font-bold tracking-[0.2em] px-3 py-1 rounded-full border border-[#8c7355]/40">
            <FileText className="w-3 h-3 text-[#c5a880]" />
            <span>LEGAL & COMMERCE POLICIES</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold tracking-wide uppercase text-white">
            Terms & Conditions
          </h1>
          <p className="text-xs sm:text-sm text-stone-300 leading-relaxed font-serif italic">
            “Transparent, fair, and bespoke gifting policies designed to ensure a seamless luxury shopping experience.”
          </p>
          <div className="pt-2 text-[11px] text-[#c5a880] font-sans font-semibold">
            Last Updated: {lastUpdatedDate} • Policy Version 1.0
          </div>
        </div>
      </div>

      {/* Quick Summary Notice */}
      <div className="bg-[#faf8f5] border border-[#e8dfd1] rounded-2xl p-6 sm:p-8 space-y-3 shadow-xs">
        <div className="flex items-center gap-2.5 text-stone-900 font-serif font-bold text-base">
          <ShieldCheck className="w-5 h-5 text-[#8c7355]" />
          <span>Notice Regarding Orders & Inquiries</span>
        </div>
        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
          Please review these Terms & Conditions thoroughly before browsing, creating an account, or placing an order on <strong>Navya Gift Hamper</strong>. By accessing our platform, placing an order, or completing checkout, you acknowledge that you have read, understood, and agreed to be bound by the terms, order confirmation protocols, payment terms, and delivery policies outlined below.
        </p>
      </div>

      {/* Main Policy Content Sections */}
      <div className="bg-white rounded-2xl border border-[#e8dfd1] p-6 sm:p-10 md:p-12 shadow-xs space-y-12 text-xs sm:text-sm leading-relaxed text-stone-700">
        {/* Section 1 */}
        <section id="general-terms" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">1</span>
            General Terms of Service
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              1.1. <strong>Platform Overview:</strong> Navya Gift Hamper operates an exclusive online e-commerce platform dedicated to curating artisanal gift hampers, bespoke celebratory collections, premium gift boxes, and lifestyle accessories.
            </p>
            <p>
              1.2. <strong>Account Responsibility:</strong> When registering an account or placing an order, customers agree to provide true, accurate, current, and complete personal and delivery details. Customers are solely responsible for maintaining the confidentiality of their account login credentials and for all activities that occur under their authenticated session.
            </p>
            <p>
              1.3. <strong>Catalogue & Pricing Updates:</strong> Navya Gift Hamper reserves the right to modify, adjust, or discontinue product descriptions, pricing, promotional discounts, coupon terms, and stock availability at any time without prior notice. All prices are displayed in Indian Rupees (INR ₹) inclusive of applicable goods and services taxes.
            </p>
          </div>
        </section>

        {/* Section 2 */}
        <section id="customer-information" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">2</span>
            Customer Information & Verification
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              2.1. <strong>Authentic Details:</strong> All information provided during registration or checkout—including Full Name, Contact Email, Mobile Number, Street Address, City, State, and PIN Code—must belong directly to the purchaser or authorized recipient.
            </p>
            <p>
              2.2. <strong>Prohibition of Misleading Data:</strong> The use of fictitious names, disposable or temporary email addresses, fraudulent telephone numbers, or unauthorized shipping addresses is strictly prohibited. Orders submitted with deliberately false or misleading details may be subject to immediate cancellation without liability.
            </p>
            <p>
              2.3. <strong>Pre-Submission Verification:</strong> Customers are advised to carefully double-check all contact and delivery details prior to clicking "Proceed to Payment" or "Place Order".
            </p>
          </div>
        </section>

        {/* Section 3 */}
        <section id="order-confirmation" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">3</span>
            Order Confirmation & Cancellation Policy
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              3.1. <strong>Condition for Confirmation:</strong> An order is deemed formally confirmed only once valid checkout data has been accepted by our database and payment status is verified as <em>"Paid"</em>.
            </p>
            <p>
              3.2. <strong>Irrevocability of Confirmed Orders:</strong> Once an order and payment are successfully confirmed, the transaction cannot be cancelled or automatically refunded merely due to a customer's change of mind.
            </p>
            <p>
              3.3. <strong>Production & Customization Window:</strong> Because our hampers contain custom greeting cards, artisanal perishables, wax-sealed parchments, and specialized gift packaging, orders enter immediate assembly upon payment. If an order has already entered processing, packaging, personalized engraving, or logistics dispatch, cancellation requests cannot be accepted.
            </p>
            <p>
              3.4. <strong>Correction Requests:</strong> If you identify an error in your delivery address or contact number immediately following order placement, you must notify our Concierge Team as soon as possible before dispatch.
            </p>
          </div>
        </section>

        {/* Section 4 */}
        <section id="payment-terms" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">4</span>
            Payment Terms & Anti-Fraud Protections
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              4.1. <strong>Supported Methods:</strong> Orders must be paid through the official payment channels designated during checkout (including Google Pay / UPI instant transfers to our verified UPI merchant ID <code>vishualk375-2@okaxis</code>).
            </p>
            <p>
              4.2. <strong>Verification Requirement:</strong> Orders remain in a pending state until payment verification is confirmed. Any payment status recorded on the database cannot be reversed arbitrarily.
            </p>
            <p>
              4.3. <strong>Strict Anti-Fraud Safeguards:</strong> Customers are strictly prohibited from submitting altered transaction screenshots, forged UPI reference IDs (UTR numbers), or manipulated payment receipts. Any fraudulent payment claim will result in instant order termination and account blacklisting.
            </p>
            <p>
              4.4. <strong>No Credential Storage:</strong> In compliance with security standards, Navya Gift Hamper does not store, request, or have access to your private UPI PINs, bank account passwords, card CVVs, or One-Time Passwords (OTPs).
            </p>
          </div>
        </section>

        {/* Section 5 */}
        <section id="product-availability" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">5</span>
            Product Availability & Visual Representation
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              5.1. <strong>Inventory Flux:</strong> While we maintain live inventory synchronizations, unforeseen demand spikes or seasonal component scarcity may occasionally affect availability.
            </p>
            <p>
              5.2. <strong>Scarcity Protocol:</strong> If an ordered item or component becomes unavailable post-payment, our concierge team will promptly contact the customer to offer an equivalent or superior luxury substitute, store credit, or an immediate refund.
            </p>
            <p>
              5.3. <strong>Representation:</strong> Product imagery on the platform is created to accurately represent the luxury hampers. Subtle variations in botanical floral arrangements, hand-crafted ribbon styling, or lighting differences may occur naturally.
            </p>
          </div>
        </section>

        {/* Section 6 */}
        <section id="product-quality" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">6</span>
            Product Quality, Damaged Items & Replacement Policy
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              6.1. <strong>Immediate Inspection:</strong> Customers or authorized recipients must inspect the parcel exterior and contents upon delivery.
            </p>
            <p>
              6.2. <strong>Reporting Damaged or Defective Goods:</strong> In the rare event that a hamper arrives damaged in transit, broken, defective, or missing components, you must notify our Concierge Team within <strong>48 hours</strong> of delivery.
            </p>
            <p>
              6.3. <strong>Required Evidence:</strong> To process a damage claim efficiently, please provide:
            </p>
            <ul className="list-disc pl-5 space-y-1.5 text-stone-600">
              <li>Your Order Number (e.g., <code>NAVYA-XXXXXX</code>)</li>
              <li>Clear photographs or unboxing video of the parcel and courier shipping label</li>
              <li>Close-up images clearly demonstrating the damage, defect, or discrepancy</li>
              <li>Please do not discard the outer packaging until our team has concluded the review</li>
            </ul>
            <p>
              6.4. <strong>Resolutions Offered:</strong> Following verification, resolutions may include immediate replacement of the damaged component/hamper, store credit vouchers, or full/partial refunds according to the verified situation.
            </p>
          </div>
        </section>

        {/* Section 7 */}
        <section id="wrong-or-missing" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">7</span>
            Incorrect or Missing Items
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              7.1. If you receive an incorrect item or an element specified in your hamper is missing, notify our support within 48 hours with photographic evidence.
            </p>
            <p>
              7.2. Navya Gift Hamper will audit the packing log and dispatch the missing or correct replacement item via express air courier at no additional cost to you.
            </p>
          </div>
        </section>

        {/* Section 8 */}
        <section id="delivery-terms" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">8</span>
            Pan-India Shipping & Delivery Timelines
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              8.1. <strong>Estimated Timelines:</strong> Standard Express shipping typically delivers within an estimated <strong>7–15 days</strong> from the date of successful order confirmation and payment. Delivery timeframes are estimates only and are not guaranteed. Actual delivery may be earlier or later depending on the destination, courier partner operational capacity, and other external factors beyond our reasonable control. All timelines are provided in conjunction with premier courier logistics partners.
            </p>
            <p>
              8.2. <strong>Circumstances Outside Control:</strong> Delays caused by severe weather conditions, national holidays, local disruptions, or courier operational bottlenecks are beyond our direct control; however, our concierge team actively tracks all parcels until secure hand-off.
            </p>
            <p>
              8.3. <strong>Incomplete Addresses & Re-Delivery:</strong> Customers must provide an accurate address with landmarks and a reachable mobile phone number. If delivery fails due to incorrect address details provided by the purchaser or repeated recipient unavailability, re-dispatch charges may apply.
            </p>
          </div>
        </section>

        {/* Section 9 */}
        <section id="returns-and-refunds" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">9</span>
            Returns & Refund Policy
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              9.1. <strong>Return Ineligibility for Custom/Bespoke Hampers:</strong> Due to the personalized, handmade, and perishable nature of curated gift hampers (e.g., customized greeting cards, edible delicacies, skincare items, and personalized engravings), general returns based solely on change-of-mind are not permitted.
            </p>
            <p>
              9.2. <strong>Eligible Return Scenarios:</strong> Returns and replacements are accepted exclusively for verified damaged items, expired products, incorrect dispatches, or lost consignments as substantiated by courier records.
            </p>
            <p>
              9.3. <strong>Refund Timelines:</strong> When a refund is approved by our management, it will be credited back to the original payment source (bank account or UPI handle) within <strong>5–7 business days</strong>, depending on bank processing schedules.
            </p>
          </div>
        </section>

        {/* Section 10 */}
        <section id="customer-responsibilities" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">10</span>
            Customer Responsibilities & Fair Usage
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>As a valued patron of Navya Gift Hamper, you agree to:</p>
            <ul className="list-disc pl-5 space-y-1.5 text-stone-600">
              <li>Provide accurate personal, recipient, and billing details.</li>
              <li>Ensure authorization for all payment instruments used.</li>
              <li>Inspect hampers promptly upon arrival and report any issues within 48 hours.</li>
              <li>Refrain from abusive communications, chargeback manipulation, or misuse of customer support channels.</li>
            </ul>
          </div>
        </section>

        {/* Section 11 */}
        <section id="fraud-and-misuse" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">11</span>
            Fraud Prevention & Misuse Policies
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              11.1. <strong>Zero Tolerance for Fraud:</strong> Navya Gift Hamper enforces zero tolerance against fake orders, forged transaction receipts, systematic cancellation abuse, unauthorized coupon generation, account impersonation, or fake review posting.
            </p>
            <p>
              11.2. <strong>Account Termination:</strong> We reserve the right to cancel suspicious orders, block user accounts, and report fraudulent activities to relevant cyber security authorities in accordance with applicable laws of India.
            </p>
          </div>
        </section>

        {/* Section 12 */}
        <section id="reviews-and-content" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">12</span>
            Product Reviews & User-Generated Content
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              12.1. <strong>Verified Reviews:</strong> Product reviews may only be submitted by verified patrons whose purchases have been successfully delivered.
            </p>
            <p>
              12.2. <strong>Content Moderation:</strong> Reviews containing abusive language, promotional spam, defamatory claims, or third-party private information will be moderated and removed.
            </p>
          </div>
        </section>

        {/* Section 13 */}
        <section id="intellectual-property" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">13</span>
            Intellectual Property Rights
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              13.1. All brand assets, logos, hamper curation designs, custom product photographs, textual descriptions, software scripts, and visual aesthetics published on this platform are the exclusive intellectual property of <strong>Navya Gift Hamper</strong>.
            </p>
            <p>
              13.2. Reproduction, scraping, distribution, or unauthorized commercial use of our proprietary assets is strictly prohibited without explicit written authorization.
            </p>
          </div>
        </section>

        {/* Section 14 */}
        <section id="limitation-of-liability" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">14</span>
            Limitation of Liability
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              14.1. To the fullest extent permitted by applicable Indian law, Navya Gift Hamper shall not be liable for indirect, incidental, punitive, or consequential damages resulting from courier transit delays, third-party logistics disruptions, or events of force majeure.
            </p>
            <p>
              14.2. In all circumstances, our maximum aggregate liability to any customer for any claim arising out of an order shall be limited strictly to the total amount paid by the customer for the specific order under dispute.
            </p>
          </div>
        </section>

        {/* Section 15 */}
        <section id="policy-amendments" className="space-y-4 pb-8 border-b border-[#eee5d8]">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">15</span>
            Amendments & Governance
          </h2>
          <div className="space-y-3 pl-2 sm:pl-10">
            <p>
              15.1. Navya Gift Hamper reserves the right to revise or update these Terms & Conditions as necessary to reflect operational, legal, or regulatory modifications.
            </p>
            <p>
              15.2. Continued use of the website following any policy updates constitutes full acceptance of the revised terms.
            </p>
          </div>
        </section>

        {/* Section 16 */}
        <section id="concierge-support" className="space-y-4 pt-2">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#1a1815] flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-[#1a1815] text-[#c5a880] text-xs flex items-center justify-center font-sans font-bold">16</span>
            Dedicated Customer Support & Inquiries
          </h2>
          <div className="space-y-4 pl-2 sm:pl-10">
            <div className="bg-[#faf8f5] border border-[#e8dfd1] rounded-xl p-5 space-y-2">
              <p className="font-semibold text-stone-900">
                ⚠️ Urgent Damage or Order Discrepancy Notice:
              </p>
              <p className="text-xs text-stone-600 leading-relaxed">
                “Please contact Navya Gift Hamper support as soon as possible if you receive a damaged, defective, incorrect, or incomplete order.”
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              {/* Email */}
              <a
                href="mailto:Supportnavya0@gmail.com"
                className="p-4 rounded-xl border border-[#e8dfd1] hover:border-[#8c7355] bg-[#faf8f5]/60 hover:bg-[#faf8f5] transition-colors flex items-center gap-3"
              >
                <Mail className="w-5 h-5 text-[#8c7355] shrink-0" />
                <div className="min-w-0">
                  <span className="font-bold text-xs text-[#1a1815] block">Email Support</span>
                  <span className="text-[11px] text-stone-500 truncate block">Supportnavya0@gmail.com</span>
                </div>
              </a>

              {/* WhatsApp */}
              <a
                href="https://wa.me/message/SE4USKU3N2UNE1"
                target="_blank"
                rel="noreferrer"
                className="p-4 rounded-xl border border-[#e8dfd1] hover:border-[#25D366] bg-[#faf8f5]/60 hover:bg-[#25D366]/5 transition-colors flex items-center gap-3"
              >
                <MessageCircle className="w-5 h-5 text-[#25D366] shrink-0" />
                <div className="min-w-0">
                  <span className="font-bold text-xs text-[#1a1815] block">WhatsApp Concierge</span>
                  <span className="text-[11px] text-stone-500 truncate block">Instant Chat Assistance</span>
                </div>
              </a>

              {/* Instagram */}
              <a
                href="https://www.instagram.com/navyagift_hamper?stkn=aDl5N3Q1NHZkb2Fv"
                target="_blank"
                rel="noreferrer"
                className="p-4 rounded-xl border border-[#e8dfd1] hover:border-[#8c7355] bg-[#faf8f5]/60 hover:bg-[#faf8f5] transition-colors flex items-center gap-3"
              >
                <InstagramIcon className="w-5 h-5 text-[#8c7355] shrink-0" />
                <div className="min-w-0">
                  <span className="font-bold text-xs text-[#1a1815] block">Official Instagram</span>
                  <span className="text-[11px] text-stone-500 truncate block">@navyagift_hamper</span>
                </div>
              </a>
            </div>
          </div>
        </section>
      </div>

      {/* Footer Navigation Back Link */}
      <div className="text-center pt-4">
        <Link
          to="/gifts"
          className="inline-flex items-center gap-2 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest px-8 py-3.5 rounded-lg shadow-md transition-colors"
        >
          <span>Continue Shopping Hampers</span>
          <ChevronRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};
