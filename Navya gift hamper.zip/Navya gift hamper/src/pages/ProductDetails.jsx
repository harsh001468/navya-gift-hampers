import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Star,
  Heart,
  ShoppingBag,
  Gift,
  Truck,
  ShieldCheck,
  ChevronRight,
  Plus,
  Minus,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowRight,
  ThumbsUp,
  BadgeCheck,
  MessageSquarePlus,
  SlidersHorizontal,
  Lock,
  ShoppingCart,
  X
} from 'lucide-react';
import { productService } from '../services/productService';
import { reviewService } from '../services/reviewService';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';

import { useAuth } from '../context/AuthContext';
import { useStore } from '../context/StoreContext';
import { ProductCard } from '../components/ProductCard';

/* ─── Helper: render star row ─────────────────────────────── */
const StarRow = ({ rating, size = 'sm' }) => {
  const sz = size === 'lg' ? 'w-5 h-5' : size === 'md' ? 'w-4 h-4' : 'w-3.5 h-3.5';
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          className={`${sz} ${
            s <= Math.round(rating)
              ? 'fill-amber-500 stroke-amber-500'
              : s - 0.5 <= rating
              ? 'fill-amber-300 stroke-amber-300'
              : 'fill-stone-200 stroke-stone-300'
          }`}
        />
      ))}
    </div>
  );
};

/* ─── Helper: relative time ──────────────────────────────── */
const relativeTime = (dateStr) => {
  const diff = Date.now() - new Date(dateStr).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 30) return `${days} days ago`;
  if (days < 365) return `${Math.floor(days / 30)} months ago`;
  return `${Math.floor(days / 365)} years ago`;
};

/* ─── Rating breakdown calc ──────────────────────────────── */
const calcBreakdown = (reviews) => {
  const counts = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  reviews.forEach((r) => {
    const n = Math.round(Number(r.rating));
    if (n >= 1 && n <= 5) counts[n]++;
  });
  const avg =
    reviews.reduce((s, r) => s + Number(r.rating), 0) / (reviews.length || 1);
  return { counts, total: reviews.length, avg };
};

/* ─── Sort helper ────────────────────────────────────────── */
const sortReviews = (reviews, sortBy) => {
  const arr = [...reviews];
  switch (sortBy) {
    case 'highest':
      return arr.sort((a, b) => b.rating - a.rating);
    case 'lowest':
      return arr.sort((a, b) => a.rating - b.rating);
    case 'helpful':
      return arr.sort(
        (a, b) => (b.helpful_count || 0) - (a.helpful_count || 0)
      );
    case 'recent':
    default:
      return arr.sort(
        (a, b) => new Date(b.created_at) - new Date(a.created_at)
      );
  }
};

/* ════════════════════════════════════════════════════════════
   REVIEWS SECTION COMPONENT
   ════════════════════════════════════════════════════════════ */
const ReviewsSection = ({ productId, initialReviews }) => {
  const { user, profile } = useAuth();
  const { addToast } = useToast();

  const [reviews, setReviews] = useState(initialReviews || []);
  const [sortBy, setSortBy] = useState('recent');
  const [showForm, setShowForm] = useState(false);
  const [eligibility, setEligibility] = useState(null); // null = checking
  const [eligibilityLoading, setEligibilityLoading] = useState(false);
  const [helpfulClicked, setHelpfulClicked] = useState(new Set());
  const [visibleCount, setVisibleCount] = useState(4);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [form, setForm] = useState({
    name: profile?.name || '',
    location: '',
    rating: 5,
    hoverRating: 0,
    title: '',
    comment: ''
  });

  // Pre-fill name/location from profile
  useEffect(() => {
    if (profile?.name) {
      setForm((f) => ({
        ...f,
        name: profile.name
      }));
    }
  }, [profile]);

  // Check eligibility when user or product changes
  useEffect(() => {
    let mounted = true;
    if (!user) {
      setEligibility(null);
      setEligibilityLoading(false);
      return;
    }
    setEligibilityLoading(true);
    reviewService.checkReviewEligibility(user.id, productId).then((result) => {
      if (mounted) {
        setEligibility(result);
        setEligibilityLoading(false);
      }
    });
    return () => {
      mounted = false;
    };
  }, [user, productId]);

  // Update reviews when prop changes
  useEffect(() => {
    if (initialReviews && initialReviews.length > 0) {
      setReviews(initialReviews);
    }
  }, [initialReviews]);

  const breakdown = calcBreakdown(reviews);
  const sorted = sortReviews(reviews, sortBy);
  const visible = sorted.slice(0, visibleCount);

  const handleMarkHelpful = async (reviewId) => {
    if (helpfulClicked.has(reviewId)) return;
    setHelpfulClicked((prev) => new Set([...prev, reviewId]));
    const result = await reviewService.markHelpful(reviewId);
    if (result.success) {
      setReviews((prev) =>
        prev.map((r) =>
          r.id === reviewId
            ? { ...r, helpful_count: (r.helpful_count || 0) + 1 }
            : r
        )
      );
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.comment.trim()) return;

    setIsSubmitting(true);
    const res = await reviewService.addReview({
      productId,
      authorName: form.name || profile?.name || 'Valued Customer',
      authorLocation: form.location || 'Verified Buyer',
      rating: form.rating,
      title: form.title,
      comment: form.comment,
      userId: user?.id,
      orderId: eligibility?.orderId
    });
    setIsSubmitting(false);

    if (res.success) {
      addToast('Your review has been submitted! Thank you.', 'success');
      setShowForm(false);
      setForm({ name: '', location: '', rating: 5, hoverRating: 0, title: '', comment: '' });
      // Refresh
      const updatedRevs = await reviewService.getProductReviews(productId);
      setReviews(updatedRevs);
      setVisibleCount(4);
      setSortBy('recent');
    } else {
      addToast('Failed to submit review. Please try again.', 'error');
    }
  };

  /* Eligibility message block */
  const renderEligibilityGate = () => {
    if (!user) {
      return (
        <div className="flex flex-col items-center gap-3 py-6 bg-[#faf8f5] rounded-xl border border-[#e8dfd1] text-center">
          <Lock className="w-8 h-8 text-[#8c7355]" />
          <div>
            <p className="font-serif font-bold text-stone-800 text-sm">Sign in to write a review</p>
            <p className="text-xs text-stone-500 mt-1">Only customers who purchased this product can review it.</p>
          </div>
          <Link
            to="/login"
            className="inline-flex items-center gap-2 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-bold uppercase tracking-wider px-5 py-2.5 rounded-lg transition-colors"
          >
            Sign In
          </Link>
        </div>
      );
    }

    if (eligibilityLoading) {
      return (
        <div className="flex items-center justify-center gap-2 py-5 text-stone-400 text-xs">
          <div className="w-4 h-4 border-2 border-[#8c7355] border-t-transparent rounded-full animate-spin" />
          Checking your purchase history...
        </div>
      );
    }

    if (!eligibility) return null;

    if (eligibility.reason === 'already_reviewed') {
      return (
        <div className="flex items-center gap-3 p-4 bg-emerald-50 border border-emerald-200 rounded-xl">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <p className="text-xs text-emerald-700 font-medium">You've already reviewed this product. Thank you for your feedback!</p>
        </div>
      );
    }

    if (eligibility.reason === 'no_completed_order' || eligibility.reason === 'product_not_purchased') {
      return (
        <div className="flex flex-col items-center gap-3 py-6 bg-amber-50 border border-amber-200 rounded-xl text-center">
          <ShoppingCart className="w-7 h-7 text-amber-600" />
          <div>
            <p className="font-serif font-bold text-stone-800 text-sm">Purchase required to review</p>
            <p className="text-xs text-stone-500 mt-1">
              Only verified buyers with a delivered order can write a review.
            </p>
          </div>
        </div>
      );
    }

    if (eligibility.eligible) {
      return (
        <button
          onClick={() => setShowForm((v) => !v)}
          className="w-full flex items-center justify-center gap-2 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-bold uppercase tracking-widest py-3.5 rounded-xl transition-colors"
        >
          <MessageSquarePlus className="w-4 h-4" />
          {showForm ? 'Cancel Review' : 'Write a Review'}
        </button>
      );
    }

    return null;
  };

  return (
    <div className="space-y-6">
      {/* ── Rating Summary ── */}
      {reviews.length > 0 && (
        <div className="bg-gradient-to-br from-[#faf8f5] to-[#f0ebe2] rounded-2xl border border-[#e8dfd1] p-5 flex flex-col sm:flex-row gap-5 items-start sm:items-center">
          {/* Big avg score */}
          <div className="flex flex-col items-center min-w-[80px]">
            <span className="font-serif text-5xl font-bold text-[#1a1815]">
              {breakdown.avg.toFixed(1)}
            </span>
            <StarRow rating={breakdown.avg} size="md" />
            <span className="text-[11px] text-stone-500 mt-1">
              {breakdown.total} review{breakdown.total !== 1 ? 's' : ''}
            </span>
          </div>

          {/* Breakdown bars */}
          <div className="flex-1 space-y-1.5 w-full">
            {[5, 4, 3, 2, 1].map((star) => {
              const count = breakdown.counts[star] || 0;
              const pct = breakdown.total > 0 ? Math.round((count / breakdown.total) * 100) : 0;
              return (
                <div key={star} className="flex items-center gap-2 text-xs font-sans">
                  <span className="text-stone-500 w-8 text-right shrink-0">{star} ★</span>
                  <div className="flex-1 h-2 bg-[#e8dfd1] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-400 rounded-full transition-all duration-700"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span className="text-stone-400 w-8 shrink-0">{pct}%</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Sort & Eligibility Gate ── */}
      <div className="flex flex-col gap-3">
        {reviews.length > 1 && (
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <span className="text-xs text-stone-500 font-sans">Sort:</span>
            {['recent', 'highest', 'lowest', 'helpful'].map((opt) => (
              <button
                key={opt}
                onClick={() => setSortBy(opt)}
                className={`text-[11px] font-sans px-2.5 py-1 rounded-full border transition-all ${
                  sortBy === opt
                    ? 'bg-[#1a1815] text-white border-[#1a1815]'
                    : 'bg-white text-stone-600 border-[#e8dfd1] hover:border-[#8c7355]'
                }`}
              >
                {opt === 'recent' ? 'Most Recent' : opt === 'highest' ? 'Highest' : opt === 'lowest' ? 'Lowest' : 'Most Helpful'}
              </button>
            ))}
          </div>
        )}

        {renderEligibilityGate()}
      </div>

      {/* ── Review Form ── */}
      {showForm && eligibility?.eligible && (
        <form
          onSubmit={handleSubmit}
          className="bg-white border-2 border-[#8c7355] rounded-2xl p-5 space-y-4 shadow-md"
        >
          <div className="flex items-center justify-between">
            <h4 className="font-serif font-bold text-[#1a1815] text-base">Your Review</h4>
            <button type="button" onClick={() => setShowForm(false)} className="text-stone-400 hover:text-stone-700">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Star picker */}
          <div className="space-y-1">
            <span className="text-xs font-bold text-stone-600 uppercase tracking-wider">Overall Rating *</span>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onMouseEnter={() => setForm((f) => ({ ...f, hoverRating: star }))}
                  onMouseLeave={() => setForm((f) => ({ ...f, hoverRating: 0 }))}
                  onClick={() => setForm((f) => ({ ...f, rating: star }))}
                  className="transition-transform hover:scale-125"
                >
                  <Star
                    className={`w-7 h-7 transition-colors ${
                      star <= (form.hoverRating || form.rating)
                        ? 'fill-amber-500 stroke-amber-500'
                        : 'fill-stone-200 stroke-stone-300'
                    }`}
                  />
                </button>
              ))}
              <span className="text-xs text-stone-400 ml-2 font-sans">
                {form.hoverRating || form.rating}/5
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-600 uppercase tracking-wider">Your Name *</label>
              <input
                required
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Enter your name"
                className="w-full bg-[#faf8f5] border border-[#e8dfd1] focus:border-[#8c7355] focus:outline-none rounded-lg px-3 py-2 text-xs font-sans"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-600 uppercase tracking-wider">City / Location</label>
              <input
                type="text"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
                placeholder="e.g. Mumbai"
                className="w-full bg-[#faf8f5] border border-[#e8dfd1] focus:border-[#8c7355] focus:outline-none rounded-lg px-3 py-2 text-xs font-sans"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-stone-600 uppercase tracking-wider">Review Title</label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Summarise your experience in a few words"
              className="w-full bg-[#faf8f5] border border-[#e8dfd1] focus:border-[#8c7355] focus:outline-none rounded-lg px-3 py-2 text-xs font-sans"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-stone-600 uppercase tracking-wider">Your Review *</label>
            <textarea
              required
              rows={4}
              value={form.comment}
              onChange={(e) => setForm({ ...form, comment: e.target.value })}
              placeholder="Tell others what you loved (or didn't love) about this gift hamper..."
              className="w-full bg-[#faf8f5] border border-[#e8dfd1] focus:border-[#8c7355] focus:outline-none rounded-lg px-3 py-2 text-xs font-sans resize-none"
            />
          </div>

          <div className="flex items-center gap-2 p-3 bg-emerald-50 rounded-lg border border-emerald-200">
            <BadgeCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="text-xs text-emerald-700">
              Your review will be marked as <strong>Verified Purchase</strong> since you ordered this product.
            </span>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-[#1a1815] hover:bg-[#8c7355] disabled:opacity-60 text-white font-bold py-3 rounded-xl uppercase tracking-widest text-xs transition-colors flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Submitting...
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                Submit Review
              </>
            )}
          </button>
        </form>
      )}

      {/* ── Review Cards ── */}
      {visible.length > 0 ? (
        <div className="space-y-3">
          {visible.map((rev, idx) => (
            <div
              key={rev.id || idx}
              className="bg-white rounded-2xl border border-[#e8dfd1] p-4 space-y-2.5 hover:border-[#c5a880] transition-colors shadow-sm"
            >
              {/* Top row */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  {/* Avatar */}
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#c5a880] to-[#8c7355] flex items-center justify-center text-white font-bold text-sm shrink-0 font-serif">
                    {(rev.author_name || 'A').charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-xs text-stone-900 font-sans">
                        {rev.author_name || 'Anonymous'}
                      </span>
                      {rev.author_location && (
                        <span className="text-[10px] text-stone-400 font-sans">
                          · {rev.author_location}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <StarRow rating={rev.rating} size="sm" />
                      <span className="text-[10px] text-stone-400 font-sans">
                        {relativeTime(rev.created_at)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Verified badge */}
                {(rev.is_verified_purchase || rev.is_verified_buyer) && (
                  <div className="flex items-center gap-1 bg-emerald-50 border border-emerald-200 text-emerald-700 px-2 py-0.5 rounded-full shrink-0">
                    <BadgeCheck className="w-3 h-3" />
                    <span className="text-[10px] font-bold">Verified</span>
                  </div>
                )}
              </div>

              {/* Title */}
              {rev.title && (
                <h5 className="font-serif font-bold text-stone-900 text-sm leading-snug">
                  {rev.title}
                </h5>
              )}

              {/* Comment */}
              <p className="text-xs text-stone-600 font-sans leading-relaxed">
                "{rev.comment}"
              </p>

              {/* Helpful */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => handleMarkHelpful(rev.id)}
                  disabled={helpfulClicked.has(rev.id)}
                  className={`flex items-center gap-1.5 text-[11px] font-sans px-3 py-1.5 rounded-full border transition-all ${
                    helpfulClicked.has(rev.id)
                      ? 'bg-[#f5f0e6] border-[#c5a880] text-[#8c7355]'
                      : 'bg-white border-[#e8dfd1] text-stone-500 hover:border-[#c5a880] hover:text-[#8c7355]'
                  }`}
                >
                  <ThumbsUp className="w-3 h-3" />
                  Helpful
                  {(rev.helpful_count || 0) > 0 && (
                    <span className="font-bold">({rev.helpful_count})</span>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-stone-400 text-sm font-sans">
          No reviews yet. Be the first to share your experience!
        </div>
      )}

      {/* Load More */}
      {visibleCount < sorted.length && (
        <button
          onClick={() => setVisibleCount((n) => n + 4)}
          className="w-full text-xs font-bold uppercase tracking-widest text-[#8c7355] hover:text-[#1a1815] border border-[#e8dfd1] hover:border-[#8c7355] py-3 rounded-xl transition-all font-sans"
        >
          Load More Reviews ({sorted.length - visibleCount} remaining)
        </button>
      )}
    </div>
  );
};

/* ════════════════════════════════════════════════════════════
   PRODUCT DETAILS PAGE
   ════════════════════════════════════════════════════════════ */
export const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();


  const [product, setProduct] = useState(null);
  const [relatedProducts, setRelatedProducts] = useState([]);
  const [productReviews, setProductReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [giftNote, setGiftNote] = useState('');
  const [quantity, setQuantity] = useState(1);

  // Accordion open states
  const [openAccordion, setOpenAccordion] = useState('inside');

  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { delivery } = useStore();

  useEffect(() => {
    const fetchProduct = async () => {
      setLoading(true);
      const data = await productService.getProductById(id);
      if (data) {
        setProduct(data);
        setSelectedImage(0);
        if (data.sizes && data.sizes.length > 0) setSelectedSize(data.sizes[0]);
        if (data.colors && data.colors.length > 0) setSelectedColor(data.colors[0]);

        // fetch related & product reviews from InsForge DB
        const [all, revs] = await Promise.all([
          productService.getProducts(),
          reviewService.getProductReviews(id)
        ]);
        const related = all.filter(
          (p) => (p.category === data.category || p.gender === data.gender) && p.id !== data.id
        );
        setRelatedProducts(related.slice(0, 4));
        setProductReviews(revs);
      }
      setLoading(false);
    };
    fetchProduct();

    const handleSync = () => {
      fetchProduct();
    };
    window.addEventListener('navya:data_sync', handleSync);
    return () => window.removeEventListener('navya:data_sync', handleSync);
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-12 h-12 border-4 border-[#8c7355] border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="font-serif text-lg text-stone-600">Unboxing hamper details...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="font-serif text-3xl font-bold text-[#1a1815]">Product Not Found</h2>
        <p className="text-xs text-stone-500 font-sans">
          The requested gift hamper is unavailable or has been unlisted.
        </p>
        <Link
          to="/gifts"
          className="inline-block bg-[#1a1815] text-white text-xs uppercase font-semibold px-6 py-3 rounded-md"
        >
          Explore All Gifts
        </Link>
      </div>
    );
  }

  const isLiked = isInWishlist(product.id);

  const handleAddToCart = () => {
    addToCart(product, quantity, {
      size: selectedSize,
      color: selectedColor,
      giftNote
    });
  };

  const handleBuyNow = () => {
    addToCart(product, quantity, {
      size: selectedSize,
      color: selectedColor,
      giftNote
    });
    navigate('/checkout');
  };

  const toggleSection = (section) => {
    setOpenAccordion(openAccordion === section ? null : section);
  };

  // Compute avg rating from productReviews
  const avgRating =
    productReviews.length > 0
      ? (productReviews.reduce((s, r) => s + Number(r.rating), 0) / productReviews.length).toFixed(1)
      : product.rating;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs text-stone-500 font-sans">
        <Link to="/" className="hover:text-black">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <Link to={`/${product.gender.toLowerCase()}`} className="hover:text-black">
          {product.category}
        </Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <span className="font-semibold text-[#1a1815] truncate max-w-xs">{product.name}</span>
      </nav>

      {/* Main Grid PDP */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
        {/* Left Column: Multi-Image Gallery */}
        <div className="lg:col-span-7 space-y-4">
          <div className="relative aspect-4/5 w-full bg-[#f7f4ef] rounded-xl overflow-hidden border border-[#e8dfd1] shadow-sm">
            <img
              src={product.images[selectedImage]}
              alt={product.name}
              className="w-full h-full object-cover object-center"
              referrerPolicy="no-referrer"
            />
            {product.badge && (
              <span className="absolute top-4 left-4 bg-[#1a1815] text-white text-[11px] font-bold uppercase tracking-wider px-3 py-1 rounded-xs">
                {product.badge}
              </span>
            )}
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-2">
              {product.images.map((img, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`w-20 h-24 rounded-md overflow-hidden border-2 transition-all shrink-0 ${
                    selectedImage === index ? 'border-[#8c7355] ring-2 ring-[#8c7355]/20' : 'border-[#e8dfd1] opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={`Thumb ${index + 1}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Information & CTAs */}
        <div className="lg:col-span-5 space-y-6">
          {/* Header & Rating */}
          <div className="space-y-2 border-b border-[#e8dfd1] pb-4">
            <div className="flex items-center justify-between text-xs font-sans text-[#8c7a65]">
              <span className="uppercase tracking-widest font-bold">{product.subcategory || product.category}</span>
              <div className="flex items-center gap-1 text-amber-600">
                <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                <span className="font-bold">{avgRating}</span>
                <span className="text-stone-400">({productReviews.length || product.reviews} reviews)</span>
              </div>
            </div>

            <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#1a1815] leading-snug">
              {product.name}
            </h1>

            {/* Price */}
            <div className="flex items-baseline gap-3 pt-1">
              <span className="font-sans text-2xl font-bold text-[#1a1815]">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-stone-400 line-through">
                  ₹{product.originalPrice.toLocaleString('en-IN')}
                </span>
              )}
              {product.discount > 0 && (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-xs">
                  SAVE {product.discount}%
                </span>
              )}
            </div>
          </div>

          {/* Description */}
          <p className="text-xs sm:text-sm text-stone-600 leading-relaxed font-sans">
            {product.description}
          </p>

          {/* Variants Selector */}
          {product.sizes && product.sizes.length > 0 && (
            <div className="space-y-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#1a1815]">
                Gift Box Edition: <span className="font-normal text-stone-600">{selectedSize}</span>
              </label>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((sz) => (
                  <button
                    key={sz}
                    onClick={() => setSelectedSize(sz)}
                    className={`text-xs px-3.5 py-2 rounded-md border font-sans transition-all ${
                      selectedSize === sz
                        ? 'bg-[#1a1815] text-white border-[#1a1815] shadow-xs'
                        : 'bg-white text-stone-700 border-[#e8dfd1] hover:border-[#8c7355]'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Personalized Message Note */}
          <div className="space-y-2 bg-[#f5f0e6] p-4 rounded-lg border border-[#e5dccb]">
            <div className="flex items-center gap-2 text-xs font-bold text-[#1a1815] uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-[#8c7355]" />
              <span>Complimentary Personal Gift Note</span>
            </div>
            <textarea
              rows={2}
              value={giftNote}
              onChange={(e) => setGiftNote(e.target.value)}
              placeholder="Write your custom message for the receiver here... (Printed on luxury parchment card)"
              className="w-full bg-white text-xs p-2.5 rounded-md border border-[#e5dccb] focus:outline-none focus:border-[#8c7355] text-stone-800 placeholder-stone-400 font-sans"
            />
          </div>

          {/* Quantity & Actions */}
          <div className="space-y-4 pt-2">
            {(!product.inStock || (product.stockQuantity !== undefined && product.stockQuantity <= 0)) ? (
              <div className="space-y-3">
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs font-semibold flex items-center justify-between">
                  <span>This gift hamper is currently Out of Stock</span>
                  <span className="text-[10px] uppercase tracking-wider bg-rose-600 text-white px-2 py-0.5 rounded font-mono">
                    Sold Out
                  </span>
                </div>
                <div className="flex gap-3">
                  <button
                    disabled
                    className="flex-1 bg-stone-300 text-stone-500 text-xs uppercase font-bold tracking-widest py-4 px-4 rounded-md cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <span>Out of Stock</span>
                  </button>
                  <button
                    onClick={() => toggleWishlist(product)}
                    className={`p-3 rounded-md border transition-all flex items-center gap-2 text-xs font-semibold ${
                      isLiked
                        ? 'bg-rose-50 text-rose-600 border-rose-200'
                        : 'bg-white text-stone-700 border-[#e8dfd1] hover:border-stone-400'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-600' : ''}`} />
                    <span className="hidden sm:inline">{isLiked ? 'Saved' : 'Wishlist'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-4">
                  <div className="flex items-center border border-[#d8cbb8] rounded-md bg-white">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-2.5 text-stone-600 hover:text-black"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-4 text-sm font-bold font-sans text-[#1a1815]">{quantity}</span>
                    <button
                      onClick={() => {
                        const maxStock = product.stockQuantity ?? product.stock ?? 99;
                        setQuantity(Math.min(maxStock, quantity + 1));
                      }}
                      className="p-2.5 text-stone-600 hover:text-black"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    onClick={() => toggleWishlist(product)}
                    className={`p-3 rounded-md border transition-all flex items-center gap-2 text-xs font-semibold ${
                      isLiked
                        ? 'bg-rose-50 text-rose-600 border-rose-200'
                        : 'bg-white text-stone-700 border-[#e8dfd1] hover:border-stone-400'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-600' : ''}`} />
                    <span className="hidden sm:inline">{isLiked ? 'Saved' : 'Wishlist'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={handleAddToCart}
                    className="bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest py-4 px-4 rounded-md shadow-lg transition-colors flex items-center justify-center gap-2"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Add to Bag</span>
                  </button>
                  <button
                    onClick={handleBuyNow}
                    className="bg-[#c5a880] hover:bg-[#d4b993] text-black text-xs uppercase font-bold tracking-widest py-4 px-4 rounded-md shadow-lg transition-colors flex items-center justify-center gap-2"
                  >
                    <span>Buy Now</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Quick Perks Bar */}
          <div className="grid grid-cols-3 gap-2 text-[11px] font-sans text-stone-600 border-t border-b border-[#e8dfd1] py-4 text-center">
            <div className="flex flex-col items-center">
              <Gift className="w-4 h-4 text-[#8c7355] mb-1" />
              <span>Free Luxury Wrap</span>
            </div>
            <div className="flex flex-col items-center">
              <Truck className="w-4 h-4 text-[#8c7355] mb-1" />
              <span>Express Pan-India</span>
            </div>
            <div className="flex flex-col items-center">
              <ShieldCheck className="w-4 h-4 text-[#8c7355] mb-1" />
              <span>Safe Delivery</span>
            </div>
          </div>

          {/* Accordion Sections */}
          <div className="divide-y divide-[#e8dfd1] border-b border-[#e8dfd1]">
            {/* What's Inside */}
            {product.contents && product.contents.length > 0 && (
              <div>
                <button
                  onClick={() => toggleSection('inside')}
                  className="w-full py-4 flex items-center justify-between text-left font-serif font-bold text-sm text-[#1a1815]"
                >
                  <span>WHAT'S INSIDE THIS HAMPER</span>
                  {openAccordion === 'inside' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
                {openAccordion === 'inside' && (
                  <div className="pb-4 space-y-2 text-xs font-sans text-stone-600">
                    {product.contents.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Delivery Info */}
            <div>
              <button
                onClick={() => toggleSection('delivery')}
                className="w-full py-4 flex items-center justify-between text-left font-serif font-bold text-sm text-[#1a1815]"
              >
                <span>DELIVERY & PACKAGING DETAILS</span>
                {openAccordion === 'delivery' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {openAccordion === 'delivery' && (
                <div className="pb-4 space-y-2 text-xs font-sans text-stone-600 leading-relaxed">
                  <p>• {product.deliveryInfo || `Standard Express Delivery: ${delivery?.estimated_days || '7–15 Days'} across India.`}</p>
                  <p>• Complimentary luxury gift box with ribbon and personalized card included.</p>
                  <p>• Carefully packed with protective cushioning for pristine courier transit.</p>
                </div>
              )}
            </div>

            {/* Customer Reviews Accordion */}
            <div>
              <button
                onClick={() => toggleSection('reviews')}
                className="w-full py-4 flex items-center justify-between text-left font-serif font-bold text-sm text-[#1a1815]"
              >
                <div className="flex items-center gap-2">
                  <span>VERIFIED REVIEWS</span>
                  {productReviews.length > 0 && (
                    <span className="bg-[#1a1815] text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                      {productReviews.length}
                    </span>
                  )}
                </div>
                {openAccordion === 'reviews' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {openAccordion === 'reviews' && (
                <div className="pb-4">
                  <ReviewsSection productId={id} initialReviews={productReviews} />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="space-y-6 pt-12 border-t border-[#e8dfd1]">
          <div className="flex justify-between items-end">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#8c7a65]">
                YOU MAY ALSO LIKE
              </span>
              <h2 className="font-serif text-2xl font-bold text-[#1a1815] uppercase tracking-wide">
                RECOMMENDED GIFTS
              </h2>
            </div>
            <Link
              to="/gifts"
              className="text-xs font-bold uppercase tracking-widest text-[#8c7355] hover:text-[#1a1815]"
            >
              View All
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
