import React, { useState, useEffect, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, ChevronRight, Gift } from 'lucide-react';
import { productService } from '../services/productService';
import { ProductCard } from '../components/ProductCard';
import { FilterSidebar } from '../components/FilterSidebar';
import { SortDropdown } from '../components/SortDropdown';
import { LoadingSkeleton } from '../components/LoadingSkeleton';

export const Gifts = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeSubParam = searchParams.get('sub') || searchParams.get('category') || 'All';
  const filterParam = searchParams.get('filter');

  const [products, setProducts] = useState([]);
  const [dbCategories, setDbCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortOption, setSortOption] = useState('featured');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const [filters, setFilters] = useState({
    subcategories: activeSubParam !== 'All' ? [activeSubParam] : [],
    maxPrice: 8000,
    badges: filterParam === 'offers' ? [] : filterParam === 'new' ? ['New'] : [],
    inStockOnly: false
  });

  const loadData = async () => {
    setLoading(true);
    const [prods, cats] = await Promise.all([
      productService.getProducts(),
      productService.getGiftCategories()
    ]);
    setProducts(prods);
    setDbCategories(cats);
    setLoading(false);
  };

  useEffect(() => {
    loadData();

    // Listen to live synchronization events
    const handleSync = () => {
      loadData();
    };
    window.addEventListener('navya:data_sync', handleSync);
    return () => window.removeEventListener('navya:data_sync', handleSync);
  }, []);

  // Compute dynamic category list exclusively from currently available in-stock products
  const subCategoriesList = useMemo(() => {
    const set = new Set();
    products.forEach((p) => {
      if (p.subcategory && p.subcategory !== 'Hampers' && p.inStock) {
        set.add(p.subcategory);
      }
    });
    return ['All', ...Array.from(set)];
  }, [products]);

  useEffect(() => {
    const targetSub = activeSubParam !== 'All' ? [activeSubParam] : [];
    setFilters((prev) => {
      if (JSON.stringify(prev.subcategories) === JSON.stringify(targetSub)) return prev;
      return { ...prev, subcategories: targetSub };
    });
  }, [activeSubParam]);

  const handleSubTabChange = (sub) => {
    if (sub === 'All') {
      searchParams.delete('sub');
      searchParams.delete('category');
    } else {
      searchParams.set('sub', sub);
    }
    setSearchParams(searchParams);
  };

  const filteredProducts = useMemo(() => {
    const matches = products.filter((p) => {
      if (filters.subcategories.length > 0) {
        const matched = filters.subcategories.some(
          (sub) =>
            (p.subcategory && p.subcategory.toLowerCase() === sub.toLowerCase()) ||
            (p.category && p.category.toLowerCase() === sub.toLowerCase())
        );
        if (!matched) return false;
      }
      if (p.price > filters.maxPrice) {
        return false;
      }
      if (filters.badges.length > 0 && !filters.badges.includes(p.badge)) {
        return false;
      }
      if (filters.inStockOnly && p.stock <= 0) {
        return false;
      }
      return true;
    });

    // If an unavailable category was requested (e.g. Wedding/Corporate/Chocolate) which has 0 products,
    // seamlessly display all available active products instead of an empty screen
    if (matches.length === 0 && filters.subcategories.length > 0 && products.length > 0) {
      return products;
    }

    return matches;
  }, [products, filters]);

  const sortedProducts = useMemo(() => {
    const list = [...filteredProducts];
    if (sortOption === 'price-asc') {
      return list.sort((a, b) => a.price - b.price);
    }
    if (sortOption === 'price-desc') {
      return list.sort((a, b) => b.price - a.price);
    }
    if (sortOption === 'rating') {
      return list.sort((a, b) => b.rating - a.rating);
    }
    if (sortOption === 'newest') {
      return list.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
    }
    return list;
  }, [filteredProducts, sortOption]);

  const resetFilters = () => {
    searchParams.delete('sub');
    searchParams.delete('filter');
    setSearchParams(searchParams);
    setFilters({
      subcategories: [],
      maxPrice: 8000,
      badges: [],
      inStockOnly: false
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs text-stone-500 font-sans">
        <Link to="/" className="hover:text-black">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <span className="font-semibold text-[#1a1815]">Gift Hampers</span>
      </nav>

      {/* Header Banner */}
      <div className="bg-[#1a1815] text-[#faf8f5] rounded-xl p-8 sm:p-12 relative overflow-hidden shadow-lg border border-[#3e352b]">
        <div
          className="absolute inset-0 opacity-25 bg-cover bg-center"
          style={{
            backgroundImage:
              'url(https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&q=80&w=1600)'
          }}
        />
        <div className="relative z-10 max-w-xl space-y-3">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-[#c5a880]">
            <Gift className="w-4 h-4 text-[#c5a880]" />
            <span>BESPOKE GIFTING STUDIO</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-5xl font-bold uppercase tracking-wide text-white">
            GIFT HAMPERS & EDITS
          </h1>
          <p className="font-serif italic text-base text-stone-300">
            “Explore curated hampers for Birthdays, Anniversaries, Weddings, Valentine's Day, and Personal Celebrations.”
          </p>
        </div>
      </div>

      {/* Horizontal Subcategory Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2 border-b border-[#e8dfd1]">
        {subCategoriesList.map((sub) => {
          const isActive = activeSubParam === sub || (sub === 'All' && activeSubParam === 'All');
          return (
            <button
              key={sub}
              onClick={() => handleSubTabChange(sub)}
              className={`whitespace-nowrap text-xs font-bold uppercase tracking-wider px-4 py-2.5 rounded-full border transition-all ${
                isActive
                  ? 'bg-[#1a1815] text-white border-[#1a1815] shadow-md'
                  : 'bg-white text-stone-700 border-[#e8dfd1] hover:border-[#8c7355]'
              }`}
            >
              {sub}
            </button>
          );
        })}
      </div>

      {/* Controls Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-[#e8dfd1] gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="lg:hidden flex items-center gap-2 bg-white border border-[#e8dfd1] text-xs font-semibold px-4 py-2 rounded-md"
          >
            <SlidersHorizontal className="w-4 h-4 text-[#8c7355]" />
            <span>Filter</span>
          </button>
          <span className="text-xs text-stone-500 font-sans font-medium">
            Showing <strong className="text-[#1a1815]">{sortedProducts.length}</strong> hampers
          </span>
        </div>

        <SortDropdown sortOption={sortOption} setSortOption={setSortOption} />
      </div>

      {/* Layout */}
      <div className="flex gap-8">
        <FilterSidebar
          filters={filters}
          setFilters={setFilters}
          resetFilters={resetFilters}
          availableSubcategories={subCategoriesList.filter((s) => s !== 'All')}
          isMobileOpen={mobileFilterOpen}
          onCloseMobile={() => setMobileFilterOpen(false)}
        />

        {/* Product Grid */}
        <main className="flex-1">
          {loading ? (
            <LoadingSkeleton count={6} />
          ) : sortedProducts.length === 0 ? (
            <div className="py-16 text-center space-y-3 bg-white rounded-lg border border-[#e8dfd1]">
              <h3 className="font-serif text-xl font-semibold text-[#1a1815]">
                No hampers match your filter criteria
              </h3>
              <p className="text-xs text-stone-500 font-sans">
                Try widening your price limit or clearing active category filters.
              </p>
              <button
                onClick={resetFilters}
                className="bg-[#1a1815] text-white text-xs uppercase font-semibold px-6 py-2.5 rounded-md"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedProducts.map((prod) => (
                <ProductCard key={prod.id} product={prod} />
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
