import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CheckCircle2,
  XCircle,
  Loader2,
  QrCode,
  Smartphone,
  ShieldCheck,
  Lock,
  ChevronRight,
  Copy,
  Check,
  AlertTriangle
} from 'lucide-react';
import { orderService } from '../services/orderService';
import { paymentService } from '../services/paymentService';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';


// Payment states
const STATES = {
  LOADING: 'loading',
  READY: 'ready',
  VERIFYING: 'verifying',
  SUCCESS: 'success',
  FAILED: 'failed',
  ERROR: 'error'
};

export const Payment = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToast } = useToast();

  const [order, setOrder] = useState(null);
  const [payment, setPayment] = useState(null);
  const [paymentState, setPaymentState] = useState(STATES.LOADING);
  const [copied, setCopied] = useState(false);

  // Load order and create payment record
  useEffect(() => {
    const init = async () => {
      try {
        // Load order details
        const orderData = await orderService.getOrderById(orderId);
        if (!orderData) {
          setPaymentState(STATES.ERROR);
          return;
        }

        // If already paid, redirect to success
        if (orderData.paymentStatus === 'paid') {
          navigate(`/order-success/${orderId}`, { replace: true });
          return;
        }

        setOrder(orderData);

        // Create or get existing payment record
        const existingPayment = await paymentService.getPaymentByOrderId(orderId);
        if (existingPayment && existingPayment.status === 'pending') {
          setPayment(existingPayment);
        } else {
          const res = await paymentService.createPayment({
            orderId: orderId,
            amount: orderData.totalAmount,
            userId: user?.id || null
          });
          if (res.success) {
            setPayment(res.payment);
          }
        }

        setPaymentState(STATES.READY);
      } catch (e) {
        console.error('Payment init error:', e);
        setPaymentState(STATES.ERROR);
      }
    };

    init();
  }, [orderId, user, navigate]);

  // Handle "I've Completed the Payment" click
  const handlePaymentCompleted = async (isInstant = false) => {
    setPaymentState(STATES.VERIFYING);

    // Simulate verification delay (1.5 seconds if instant, 2.5 seconds otherwise)
    await new Promise((resolve) => setTimeout(resolve, isInstant ? 1200 : 2200));

    try {
      // Simulate success
      const paymentResult = await paymentService.simulateSuccess(
        payment?.id,
        payment?.transaction_id
      );

      if (paymentResult.success) {
        // Update order status to "Confirmed" and payment status to "paid"
        await orderService.updateOrderPayment(orderId, {
          method: 'Google Pay / UPI',
          transactionId: payment?.transaction_id,
          paidAt: new Date().toISOString()
        });

        setPaymentState(STATES.SUCCESS);
        addToast('Payment successful! Order marked as Confirmed & Paid.', 'success');

        // Auto-redirect to order confirmation page
        setTimeout(() => {
          navigate(`/order-success/${order?.id || orderId}`, { replace: true });
        }, 1800);
      } else {
        setPaymentState(STATES.FAILED);
      }
    } catch (e) {
      console.error('Payment completion error:', e);
      setPaymentState(STATES.FAILED);
    }
  };

  // Retry payment
  const handleRetry = async () => {
    // Create a fresh payment record
    const res = await paymentService.createPayment({
      orderId: orderId,
      amount: order.totalAmount,
      userId: user?.id || null
    });
    if (res.success) {
      setPayment(res.payment);
    }
    setPaymentState(STATES.READY);
  };

  // Copy UPI ID to clipboard
  const handleCopyUPI = () => {
    navigator.clipboard.writeText('vishualk375-2@okaxis');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // UPI deep link for mobile
  const handleUPIIntent = () => {
    if (!order) return;
    const upiUrl = `upi://pay?pa=vishualk375-2@okaxis&pn=Navya%20Gift%20Hamper&am=${order.totalAmount}&cu=INR&tn=Order%20${order.orderId}`;
    window.location.href = upiUrl;
  };

  // -- RENDER --

  // Loading state
  if (paymentState === STATES.LOADING) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="w-10 h-10 text-[#8c7355] animate-spin mx-auto" />
          <p className="text-sm text-stone-500 font-sans">Loading payment details...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (paymentState === STATES.ERROR) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4">
        <div className="text-center space-y-4 max-w-md">
          <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto" />
          <h2 className="font-serif text-2xl font-bold text-[#1a1815]">Order Not Found</h2>
          <p className="text-sm text-stone-500 font-sans">
            We couldn't find this order. It may have expired or the link is invalid.
          </p>
          <Link
            to="/gifts"
            className="inline-block bg-[#1a1815] text-white text-xs uppercase font-semibold px-6 py-3 rounded-md"
          >
            Continue Shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs text-stone-500 font-sans">
        <Link to="/" className="hover:text-black">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <Link to="/checkout" className="hover:text-black">Checkout</Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <span className="font-semibold text-[#1a1815]">Payment</span>
      </nav>

      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#e8dfd1] pb-4">
        <div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#1a1815] uppercase tracking-wide">
            Complete Your Payment
          </h1>
          <p className="text-xs text-stone-500 font-sans mt-1 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-emerald-600" />
            256-Bit SSL Secured Payment
          </p>
        </div>
        {order && (
          <div className="text-right hidden sm:block">
            <span className="text-xs text-stone-500 block">Order</span>
            <span className="font-serif font-bold text-[#1a1815]">{order.orderId}</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Payment */}
        <div className="lg:col-span-7 space-y-6">
          <AnimatePresence mode="wait">
            {/* VERIFYING STATE */}
            {paymentState === STATES.VERIFYING && (
              <motion.div
                key="verifying"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white rounded-xl border border-[#e8dfd1] p-8 sm:p-12 text-center space-y-6"
              >
                <div className="w-20 h-20 rounded-full bg-[#f5f0e6] flex items-center justify-center mx-auto">
                  <Loader2 className="w-10 h-10 text-[#8c7355] animate-spin" />
                </div>
                <div>
                  <h2 className="font-serif text-2xl font-bold text-[#1a1815]">Verifying Payment...</h2>
                  <p className="text-sm text-stone-500 font-sans mt-2">
                    Please wait while we confirm your payment. Do not close this page.
                  </p>
                </div>
              </motion.div>
            )}

            {/* SUCCESS STATE */}
            {paymentState === STATES.SUCCESS && (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-xl border border-emerald-200 p-8 sm:p-12 text-center space-y-6"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 260, damping: 20 }}
                  className="w-24 h-24 rounded-full bg-emerald-100 flex items-center justify-center mx-auto"
                >
                  <CheckCircle2 className="w-14 h-14 text-emerald-600" />
                </motion.div>
                <div>
                  <h2 className="font-serif text-3xl font-bold text-emerald-700">Payment Successful ✓</h2>
                  <p className="text-sm text-stone-600 font-sans mt-2">
                    Your order has been confirmed. Redirecting to order details...
                  </p>
                </div>
                {payment?.transaction_id && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg px-4 py-3 text-xs font-sans">
                    <span className="text-stone-500">Transaction ID: </span>
                    <span className="font-bold text-emerald-800">{payment.transaction_id}</span>
                  </div>
                )}
              </motion.div>
            )}

            {/* FAILED STATE */}
            {paymentState === STATES.FAILED && (
              <motion.div
                key="failed"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-xl border border-red-200 p-8 sm:p-12 text-center space-y-6"
              >
                <div className="w-20 h-20 rounded-full bg-red-100 flex items-center justify-center mx-auto">
                  <XCircle className="w-12 h-12 text-red-500" />
                </div>
                <div>
                  <h2 className="font-serif text-2xl font-bold text-red-700">Payment Failed</h2>
                  <p className="text-sm text-stone-500 font-sans mt-2">
                    We were unable to verify your payment. Please try again or choose a different method.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                  <button
                    onClick={handleRetry}
                    className="bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest px-6 py-3 rounded-md transition-colors"
                  >
                    Try Again
                  </button>
                  <Link
                    to="/cart"
                    className="bg-white border border-[#e8dfd1] hover:border-[#1a1815] text-[#1a1815] text-xs uppercase font-bold tracking-widest px-6 py-3 rounded-md transition-colors text-center"
                  >
                    Return to Cart
                  </Link>
                </div>
              </motion.div>
            )}

            {/* READY STATE — QR Payment */}
            {paymentState === STATES.READY && (
              <motion.div
                key="ready"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                {/* Payment Method Header */}
                <div className="bg-white rounded-xl border border-[#e8dfd1] p-6 space-y-6">
                  <div className="flex items-center gap-3 pb-4 border-b border-[#e8dfd1]">
                    <div className="w-10 h-10 rounded-full bg-[#f5f0e6] flex items-center justify-center shrink-0">
                      <QrCode className="w-5 h-5 text-[#8c7355]" />
                    </div>
                    <div>
                      <h3 className="font-serif text-lg font-bold text-[#1a1815]">
                        Google Pay / UPI
                      </h3>
                      <p className="text-xs text-stone-500 font-sans">
                        Scan & Pay using any UPI application
                      </p>
                    </div>
                    <span className="ml-auto text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-xs uppercase tracking-wide">
                      Instant
                    </span>
                  </div>

                  {/* Amount to Pay */}
                  <div className="text-center py-2">
                    <span className="text-xs text-stone-500 block uppercase tracking-wider font-semibold mb-1">
                      Amount to Pay
                    </span>
                    <span className="font-serif text-4xl sm:text-5xl font-bold text-[#1a1815]">
                      ₹{order?.totalAmount?.toLocaleString('en-IN')}
                    </span>
                  </div>

                  {/* QR Code Section */}
                  <div className="bg-[#faf8f5] rounded-xl p-6 space-y-4">
                    <h4 className="text-center font-serif text-base font-bold text-[#1a1815] uppercase tracking-wider">
                      Scan & Pay
                    </h4>

                    {/* QR Image — client's exact image, not modified */}
                    <div className="flex justify-center">
                      <div className="bg-white rounded-2xl p-4 shadow-md border border-[#e8dfd1] max-w-[280px]">
                        <img
                          src="/payment-qr.jpeg"
                          alt="UPI Payment QR Code — Scan to pay"
                          className="w-full h-auto rounded-lg"
                          draggable={false}
                        />
                      </div>
                    </div>

                    <p className="text-center text-xs text-stone-500 font-sans max-w-sm mx-auto">
                      Scan this QR code using Google Pay, PhonePe, Paytm or any supported UPI application.
                    </p>

                    {/* UPI ID */}
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-xs text-stone-500 font-sans">UPI ID:</span>
                      <span className="text-xs font-bold text-[#1a1815] font-mono bg-white px-2.5 py-1 rounded border border-[#e8dfd1]">
                        vishualk375-2@okaxis
                      </span>
                      <button
                        onClick={handleCopyUPI}
                        className="text-[#8c7355] hover:text-[#1a1815] transition-colors p-1 flex items-center gap-1 text-xs"
                        title="Copy UPI ID"
                      >
                        {copied ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="text-emerald-600 text-[10px] font-bold">Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span className="text-[10px] font-medium text-stone-500">Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Mobile UPI Button */}
                  <button
                    onClick={handleUPIIntent}
                    className="w-full bg-[#4285F4] hover:bg-[#3367D6] text-white text-sm font-bold py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2.5 shadow-md"
                  >
                    <Smartphone className="w-5 h-5" />
                    <span>Pay with Google Pay / UPI</span>
                  </button>

                  {/* Divider */}
                  <div className="flex items-center gap-4">
                    <div className="flex-1 h-px bg-[#e8dfd1]" />
                    <span className="text-xs text-stone-400 uppercase tracking-wider font-semibold">Simulate & Confirm</span>
                    <div className="flex-1 h-px bg-[#e8dfd1]" />
                  </div>

                  <div className="space-y-3">
                    {/* "I've Completed the Payment" button */}
                    <button
                      onClick={() => handlePaymentCompleted(false)}
                      className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest py-4 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg"
                    >
                      <CheckCircle2 className="w-4 h-4 text-[#c5a880]" />
                      <span>I've Completed the Payment</span>
                    </button>

                    {/* Instant Simulate Success Button */}
                    <button
                      type="button"
                      onClick={() => handlePaymentCompleted(true)}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs uppercase font-bold tracking-widest py-3 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm"
                    >
                      <Check className="w-4 h-4" />
                      <span>Simulate Payment Success (Demo Confirmation)</span>
                    </button>
                  </div>

                  {/* Security Note */}
                  <div className="flex items-start gap-2 text-[11px] text-stone-400 font-sans bg-[#faf8f5] rounded-lg p-3 border border-[#e8dfd1]">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <p>
                        <strong className="text-stone-600">Simulated Payment (Demo Mode):</strong>{' '}
                        This is a development demo. In production, payment verification will be handled
                        by a secure backend webhook from the UPI payment provider.
                      </p>
                      {payment?.transaction_id && (
                        <p className="mt-1 text-stone-500">
                          Transaction ID: <strong className="font-mono">{payment.transaction_id}</strong>
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Column: Order Summary */}
        {order && (paymentState === STATES.READY || paymentState === STATES.FAILED) && (
          <div className="lg:col-span-5">
            <div className="bg-white rounded-xl border border-[#e8dfd1] p-6 shadow-sm space-y-5 sticky top-24">
              <h3 className="font-serif text-base font-bold text-[#1a1815] uppercase tracking-wider pb-3 border-b border-[#e8dfd1]">
                Order Summary
              </h3>

              {/* Order ID */}
              <div className="flex justify-between text-xs font-sans">
                <span className="text-stone-500">Order ID</span>
                <span className="font-bold text-[#1a1815]">{order.orderId}</span>
              </div>

              {/* Customer Name */}
              <div className="flex justify-between text-xs font-sans">
                <span className="text-stone-500">Customer</span>
                <span className="font-bold text-[#1a1815]">{order.customer?.name}</span>
              </div>

              {/* Items */}
              <div className="space-y-3 border-t border-[#e8dfd1] pt-3">
                <h4 className="text-[10px] uppercase tracking-widest text-stone-500 font-bold">Items</h4>
                <div className="max-h-48 overflow-y-auto space-y-2.5 pr-1">
                  {order.items?.map((item, i) => (
                    <div key={item.key || i} className="flex gap-3 text-xs font-sans">
                      <img
                        src={item.product?.images?.[0]}
                        alt={item.product?.name}
                        className="w-12 h-14 object-cover rounded-md bg-stone-100 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-stone-900 truncate">{item.product?.name}</p>
                        <p className="text-stone-500">Qty: {item.quantity}</p>
                        <p className="font-bold text-stone-900">
                          ₹{((item.product?.price || 0) * (item.quantity || 1)).toLocaleString('en-IN')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price Breakdown */}
              <div className="space-y-2 text-xs font-sans border-t border-[#e8dfd1] pt-4">
                <div className="flex justify-between text-stone-600">
                  <span>Subtotal</span>
                  <span>₹{order.subtotal?.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Shipping</span>
                  <span>{order.shippingFee === 0 ? 'FREE' : `₹${order.shippingFee}`}</span>
                </div>
                {order.discount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount</span>
                    <span>-₹{order.discount?.toLocaleString('en-IN')}</span>
                  </div>
                )}
                <div className="flex justify-between text-stone-600">
                  <span>Gift Packaging</span>
                  <span className="text-emerald-700 font-bold">Included</span>
                </div>
              </div>

              {/* Total */}
              <div className="flex justify-between font-serif font-bold text-xl text-[#1a1815] pt-3 border-t border-[#e8dfd1]">
                <span>Total</span>
                <span>₹{order.totalAmount?.toLocaleString('en-IN')}</span>
              </div>

              {/* Delivery info */}
              <div className="bg-gradient-to-br from-[#f5f0e6] to-[#faf8f5] rounded-xl p-3.5 border border-[#dfc99e] text-xs font-sans space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-base">🚚</span>
                  <span className="font-serif font-bold text-[#1a1815] text-sm">
                    Estimated Delivery: {order.estimatedDelivery || '7–15 Days'}
                  </span>
                </div>
                <p className="text-[11px] text-stone-600 leading-relaxed">
                  Delivery: {order.deliveryMethod || 'Standard Express'} · Dispatched within 24–48 hrs of payment. Timeline may vary due to courier, holidays, or address factors.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
