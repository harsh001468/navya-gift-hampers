import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  User,
  Package,
  Heart,
  Tag,
  Gift,
  MapPin,
  Star,
  Bell,
  Settings,
  HelpCircle,
  LogOut,
  ChevronRight,
  Sparkles,
  CheckCircle2,
  Truck,
  Plus,
  Trash2,
  Edit2,
  Copy,
  Check,
  Mail,
  MessageCircle,
  ShoppingBag,
  Eye,
  X,
  Loader2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useToast } from '../context/ToastContext';
import { orderService } from '../services/orderService';
import { addressService } from '../services/addressService';
import { reviewService } from '../services/reviewService';
import { insforge } from '../lib/insforge';

export const Profile = () => {
  const { user, profile, signOut, updateProfile } = useAuth();
  const { addToCart, setIsCartOpen } = useCart();
  const { wishlist, removeFromWishlist } = useWishlist();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const activeTab = searchParams.get('tab') || 'overview';
  const setActiveTab = (tab) => {
    setSearchParams({ tab });
  };

  // Data states
  const [orders, setOrders] = useState([]);
  const [loadingOrders, setLoadingOrders] = useState(true);
  const [addresses, setAddresses] = useState([]);
  const [loadingAddresses, setLoadingAddresses] = useState(true);
  const [userReviews, setUserReviews] = useState([]);
  const [loadingReviews, setLoadingReviews] = useState(true);

  // Modals
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [reviewModalProduct, setReviewModalProduct] = useState(null);
  const [addressModalOpen, setAddressModalOpen] = useState(false);
  const [editingAddress, setEditingAddress] = useState(null);
  const [copiedCode, setCopiedCode] = useState(null);

  // Form states
  const [profileForm, setProfileForm] = useState({
    name: profile?.name || user?.user_metadata?.full_name || '',
    phone: profile?.phone || user?.user_metadata?.phone || ''
  });
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);

  // Password update form
  const [passwordForm, setPasswordForm] = useState({
    newPassword: '',
    confirmPassword: ''
  });
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);

  // Review submission state
  const [reviewForm, setReviewForm] = useState({
    rating: 5,
    title: '',
    comment: ''
  });
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);

  // Address form
  const [addressForm, setAddressForm] = useState({
    name: '',
    phone: '',
    street: '',
    apartment: '',
    city: '',
    state: '',
    pincode: '',
    is_default: false
  });
  const [isSavingAddress, setIsSavingAddress] = useState(false);

  // Notification preferences
  const [notifications, setNotifications] = useState({
    orderUpdates: true,
    deliverySms: true,
    promotions: true,
    vouchers: true
  });

  // Load orders & user data
  useEffect(() => {
    if (!user) return;
    async function loadUserData() {
      setLoadingOrders(true);
      const fetchedOrders = await orderService.getUserOrders(user.id);
      setOrders(fetchedOrders);
      setLoadingOrders(false);

      setLoadingAddresses(true);
      const fetchedAddresses = await addressService.getUserAddresses(user.id);
      setAddresses(fetchedAddresses);
      setLoadingAddresses(false);

      setLoadingReviews(true);
      const fetchedReviews = await reviewService.getUserReviews(user.id);
      setUserReviews(fetchedReviews);
      setLoadingReviews(false);
    }
    loadUserData();

    const handleSync = (e) => {
      const type = e.detail?.type;
      if (!type || ['orders', 'reviews', 'addresses'].includes(type)) {
        loadUserData();
      }
    };
    window.addEventListener('navya:data_sync', handleSync);
    return () => window.removeEventListener('navya:data_sync', handleSync);
  }, [user]);

  // Sync profile form
  useEffect(() => {
    if (profile || user) {
      setProfileForm({
        name: profile?.name || user?.user_metadata?.full_name || '',
        phone: profile?.phone || user?.user_metadata?.phone || ''
      });
    }
  }, [profile, user]);

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    setIsUpdatingProfile(true);
    const res = await updateProfile({
      name: profileForm.name.trim(),
      phone: profileForm.phone.trim()
    });
    setIsUpdatingProfile(false);
    if (res.success) {
      addToast('Profile updated successfully!', 'success');
    } else {
      addToast(res.error || 'Failed to update profile.', 'error');
    }
  };

  const handlePasswordUpdate = async (e) => {
    e.preventDefault();
    if (!passwordForm.newPassword) {
      addToast('Please enter a new password.', 'error');
      return;
    }
    if (passwordForm.newPassword.length < 6) {
      addToast('Password must be at least 6 characters.', 'error');
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      addToast('Passwords do not match.', 'error');
      return;
    }

    setIsUpdatingPassword(true);
    try {
      const { error } = await insforge.auth.updateUser({
        password: passwordForm.newPassword
      });
      setIsUpdatingPassword(false);
      if (error) {
        addToast(error.message, 'error');
      } else {
        addToast('Password changed successfully!', 'success');
        setPasswordForm({ newPassword: '', confirmPassword: '' });
      }
    } catch {
      setIsUpdatingPassword(false);
      addToast('Failed to update password.', 'error');
    }
  };

  const handleSaveAddress = async (e) => {
    e.preventDefault();
    if (!addressForm.name || !addressForm.phone || !addressForm.street || !addressForm.city || !addressForm.pincode) {
      addToast('Please fill all required address fields.', 'error');
      return;
    }

    setIsSavingAddress(true);
    let res;
    if (editingAddress) {
      res = await addressService.updateAddress(user.id, editingAddress.id, addressForm);
    } else {
      res = await addressService.addAddress(user.id, addressForm);
    }
    setIsSavingAddress(false);

    if (res.success) {
      addToast(editingAddress ? 'Address updated!' : 'Address added!', 'success');
      setAddressModalOpen(false);
      setEditingAddress(null);
      // Reload addresses
      const updated = await addressService.getUserAddresses(user.id);
      setAddresses(updated);
    } else {
      addToast(res.error || 'Failed to save address.', 'error');
    }
  };

  const handleDeleteAddress = async (id) => {
    if (!window.confirm('Are you sure you want to delete this address?')) return;
    const res = await addressService.deleteAddress(user.id, id);
    if (res.success) {
      addToast('Address deleted.', 'success');
      setAddresses((prev) => prev.filter((a) => a.id !== id));
    } else {
      addToast('Failed to delete address.', 'error');
    }
  };

  const handleSetDefaultAddress = async (id) => {
    const res = await addressService.setDefaultAddress(user.id, id);
    if (res.success) {
      addToast('Default address updated.', 'success');
      const updated = await addressService.getUserAddresses(user.id);
      setAddresses(updated);
    }
  };

  const openAddAddressModal = () => {
    setEditingAddress(null);
    setAddressForm({
      name: profile?.name || '',
      phone: profile?.phone || '',
      street: '',
      apartment: '',
      city: '',
      state: '',
      pincode: '',
      is_default: addresses.length === 0
    });
    setAddressModalOpen(true);
  };

  const openEditAddressModal = (addr) => {
    setEditingAddress(addr);
    setAddressForm({
      name: addr.name || '',
      phone: addr.phone || '',
      street: addr.street || '',
      apartment: addr.apartment || '',
      city: addr.city || '',
      state: addr.state || '',
      pincode: addr.pincode || '',
      is_default: Boolean(addr.is_default)
    });
    setAddressModalOpen(true);
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!reviewModalProduct) return;
    if (!reviewForm.comment.trim()) {
      addToast('Please write a short review.', 'error');
      return;
    }

    setIsSubmittingReview(true);
    const res = await reviewService.submitReview({
      userId: user.id,
      productId: reviewModalProduct.productId,
      orderId: reviewModalProduct.orderId,
      authorName: profile?.name || user?.user_metadata?.full_name || 'Verified Buyer',
      authorLocation: reviewModalProduct.city || 'India',
      rating: reviewForm.rating,
      title: reviewForm.title,
      comment: reviewForm.comment
    });
    setIsSubmittingReview(false);

    if (res.success) {
      addToast('Thank you! Your verified purchase review has been published.', 'success');
      setReviewModalProduct(null);
      setReviewForm({ rating: 5, title: '', comment: '' });
      // Reload reviews
      const updatedReviews = await reviewService.getUserReviews(user.id);
      setUserReviews(updatedReviews);
    } else {
      addToast(res.error || 'Failed to submit review.', 'error');
    }
  };

  const handleCopyCoupon = (code) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    addToast(`Coupon code ${code} copied!`, 'success');
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const handleBuyAgain = (item) => {
    if (item.product) {
      addToCart(item.product, item.quantity || 1, item.selectedSize || 'Standard');
      addToast(`Added ${item.product.name} to your bag!`, 'success');
      setIsCartOpen(true);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    addToast('You have been logged out safely.', 'info');
    navigate('/');
  };

  const navigationItems = [
    { id: 'overview', label: 'Overview', icon: User },
    { id: 'orders', label: 'My Orders', icon: Package, badge: orders.length || null },
    { id: 'wishlist', label: 'Wishlist', icon: Heart, badge: wishlist.length || null },
    { id: 'offers', label: 'Offers & Coupons', icon: Tag },
    { id: 'vouchers', label: 'Gift Vouchers', icon: Gift },
    { id: 'addresses', label: 'Saved Addresses', icon: MapPin },
    { id: 'reviews', label: 'My Reviews', icon: Star, badge: userReviews.length || null },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'settings', label: 'Account Settings', icon: Settings },
    { id: 'help', label: 'Help & Support', icon: HelpCircle }
  ];

  const statusProgressSteps = ['Pending', 'Confirmed', 'Processing', 'Shipped', 'Delivered'];

  const getStatusStepIndex = (status) => {
    if (!status) return 0;
    const lower = status.toLowerCase();
    if (lower === 'pending') return 0;
    if (lower === 'confirmed') return 1;
    if (lower === 'processing') return 2;
    if (lower === 'shipped' || lower === 'out for delivery') return 3;
    if (lower === 'delivered') return 4;
    const idx = statusProgressSteps.indexOf(status);
    return idx >= 0 ? idx : 1;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Luxury Welcome Banner */}
      <div className="bg-[#141210] rounded-2xl p-6 sm:p-8 text-[#faf8f5] shadow-xl relative overflow-hidden border border-[#2c251e]">
        <div className="absolute top-0 right-0 opacity-10 translate-x-10 -translate-y-8 pointer-events-none">
          <Sparkles className="w-72 h-72 text-[#c5a880]" />
        </div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-br from-[#c5a880] to-[#8c7355] text-white flex items-center justify-center font-serif text-2xl sm:text-3xl font-bold shadow-lg ring-4 ring-[#8c7355]/30 shrink-0">
              {(profile?.name || user?.email || 'N')[0].toUpperCase()}
            </div>
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 bg-[#8c7355]/30 text-[#e8dfd1] text-[10px] uppercase font-bold tracking-[0.2em] px-2.5 py-0.5 rounded-full border border-[#8c7355]/40">
                <Sparkles className="w-2.5 h-2.5 text-[#c5a880]" />
                <span>NAVYA PRIVÉ MEMBER</span>
              </div>
              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-white tracking-wide">
                Hello, {profile?.name || user?.email?.split('@')[0] || 'Valued Customer'}
              </h1>
              <p className="text-xs text-stone-300 font-sans">
                Manage your account, orders and preferences.
              </p>
            </div>
          </div>

          <button
            onClick={handleSignOut}
            className="self-start sm:self-center bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-semibold px-4 py-2.5 rounded-lg transition-colors flex items-center gap-2 cursor-pointer shrink-0"
          >
            <LogOut className="w-4 h-4 text-stone-300" />
            <span>Log Out</span>
          </button>
        </div>
      </div>

      {/* Main Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Sidebar Navigation */}
        <aside className="lg:col-span-3 bg-white rounded-2xl border border-[#e8dfd1] shadow-xs p-3 space-y-1 overflow-x-auto lg:overflow-visible flex lg:flex-col gap-1 lg:gap-1 sticky top-24 z-10">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs font-sans font-semibold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-[#1a1815] text-[#e8dfd1] shadow-md font-bold'
                    : 'text-stone-600 hover:bg-[#faf8f5] hover:text-stone-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#c5a880]' : 'text-stone-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && item.badge !== null && (
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold ml-2 ${
                      isActive ? 'bg-[#8c7355] text-white' : 'bg-stone-100 text-stone-600'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </aside>

        {/* Content Area */}
        <main className="lg:col-span-9 bg-white rounded-2xl border border-[#e8dfd1] shadow-xs p-6 sm:p-8 min-h-[500px]">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              <div className="border-b border-[#e8dfd1] pb-4">
                <h2 className="font-serif text-2xl font-bold text-[#1a1815]">Account Overview</h2>
                <p className="text-xs text-stone-500 font-sans mt-0.5">
                  Summary of your profile details, active orders, and quick actions.
                </p>
              </div>

              {/* Quick Stat Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-[#faf8f5] border border-[#e8dfd1] rounded-xl p-4 text-center space-y-1">
                  <span className="text-2xl font-serif font-bold text-[#1a1815] block">{orders.length}</span>
                  <span className="text-[11px] uppercase tracking-wider text-stone-500 font-sans font-semibold">
                    Total Orders
                  </span>
                </div>
                <div className="bg-[#faf8f5] border border-[#e8dfd1] rounded-xl p-4 text-center space-y-1">
                  <span className="text-2xl font-serif font-bold text-[#1a1815] block">{wishlist.length}</span>
                  <span className="text-[11px] uppercase tracking-wider text-stone-500 font-sans font-semibold">
                    Saved Items
                  </span>
                </div>
                <div className="bg-[#faf8f5] border border-[#e8dfd1] rounded-xl p-4 text-center space-y-1">
                  <span className="text-2xl font-serif font-bold text-[#1a1815] block">{addresses.length}</span>
                  <span className="text-[11px] uppercase tracking-wider text-stone-500 font-sans font-semibold">
                    Addresses
                  </span>
                </div>
                <div className="bg-[#faf8f5] border border-[#e8dfd1] rounded-xl p-4 text-center space-y-1">
                  <span className="text-2xl font-serif font-bold text-[#8c7355] block">10% OFF</span>
                  <span className="text-[11px] uppercase tracking-wider text-stone-500 font-sans font-semibold">
                    Coupon Available
                  </span>
                </div>
              </div>

              {/* Profile Details Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="border border-[#e8dfd1] rounded-xl p-5 space-y-3 bg-[#faf8f5]/50">
                  <h3 className="font-serif font-bold text-base text-[#1a1815] flex items-center justify-between">
                    <span>Personal Information</span>
                    <button
                      onClick={() => setActiveTab('settings')}
                      className="text-xs text-[#8c7355] hover:underline font-sans font-semibold cursor-pointer"
                    >
                      Edit
                    </button>
                  </h3>
                  <div className="space-y-2 text-xs font-sans text-stone-700">
                    <p><strong className="text-stone-900">Name:</strong> {profile?.name || user?.user_metadata?.full_name || 'Not provided'}</p>
                    <p><strong className="text-stone-900">Email:</strong> {user?.email}</p>
                    <p><strong className="text-stone-900">Phone:</strong> {profile?.phone || user?.user_metadata?.phone || 'Not added'}</p>
                    <p><strong className="text-stone-900">Member Since:</strong> {new Date(user?.created_at || Date.now()).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}</p>
                  </div>
                </div>

                <div className="border border-[#e8dfd1] rounded-xl p-5 space-y-3 bg-[#faf8f5]/50">
                  <h3 className="font-serif font-bold text-base text-[#1a1815] flex items-center justify-between">
                    <span>Default Delivery Address</span>
                    <button
                      onClick={() => setActiveTab('addresses')}
                      className="text-xs text-[#8c7355] hover:underline font-sans font-semibold cursor-pointer"
                    >
                      Manage
                    </button>
                  </h3>
                  {addresses.length > 0 ? (
                    <div className="text-xs font-sans text-stone-700 space-y-1">
                      <p className="font-bold text-stone-900">{addresses[0].name}</p>
                      <p>{addresses[0].street}, {addresses[0].apartment ? `${addresses[0].apartment}, ` : ''}{addresses[0].city}</p>
                      <p>{addresses[0].state} - {addresses[0].pincode}</p>
                      <p>Phone: {addresses[0].phone}</p>
                    </div>
                  ) : (
                    <div className="text-xs text-stone-500 font-sans space-y-2 py-2">
                      <p>No saved addresses yet.</p>
                      <button
                        onClick={openAddAddressModal}
                        className="text-xs text-[#8c7355] font-bold uppercase underline cursor-pointer"
                      >
                        + Add Address
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Recent Orders Preview */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-serif font-bold text-lg text-[#1a1815]">Recent Orders</h3>
                  {orders.length > 0 && (
                    <button
                      onClick={() => setActiveTab('orders')}
                      className="text-xs font-semibold text-[#8c7355] hover:text-[#1a1815] flex items-center gap-1 cursor-pointer"
                    >
                      <span>View All ({orders.length})</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {loadingOrders ? (
                  <div className="py-8 flex justify-center text-stone-400">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                ) : orders.length === 0 ? (
                  <div className="p-8 text-center bg-[#faf8f5] rounded-xl border border-[#e8dfd1] space-y-3">
                    <Package className="w-8 h-8 text-stone-400 mx-auto" />
                    <p className="text-xs text-stone-600 font-sans">You haven't placed any orders yet.</p>
                    <button
                      onClick={() => navigate('/gifts')}
                      className="bg-[#1a1815] text-white text-xs uppercase font-bold px-5 py-2.5 rounded-md hover:bg-[#8c7355] transition-colors cursor-pointer"
                    >
                      Discover Hampers
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {orders.slice(0, 2).map((order) => (
                      <div
                        key={order.id}
                        className="p-4 rounded-xl border border-[#e8dfd1] hover:border-[#8c7355] transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#faf8f5]/40"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-serif font-bold text-sm text-[#1a1815]">
                              {order.orderId || `#${order.id.slice(0, 8)}`}
                            </span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                                order.status?.toLowerCase() === 'delivered'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {order.status || 'Confirmed'}
                            </span>
                          </div>
                          <p className="text-[11px] text-stone-500 font-sans">
                            {new Date(order.date).toLocaleDateString('en-IN', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric'
                            })}{' '}
                            • {order.items?.length || 1} item(s) • ₹{order.totalAmount?.toLocaleString('en-IN')}
                          </p>
                        </div>
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="self-start sm:self-center text-xs font-bold text-[#1a1815] hover:text-[#8c7355] border border-stone-300 px-3.5 py-1.5 rounded-md transition-colors cursor-pointer"
                        >
                          View Details
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: MY ORDERS */}
          {activeTab === 'orders' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-[#e8dfd1] pb-4 flex items-center justify-between">
                <div>
                  <h2 className="font-serif text-2xl font-bold text-[#1a1815]">My Orders</h2>
                  <p className="text-xs text-stone-500 font-sans mt-0.5">
                    Track delivery status, review purchases, and download receipts.
                  </p>
                </div>
                <span className="text-xs font-bold text-stone-500 font-sans">
                  {orders.length} Order(s)
                </span>
              </div>

              {loadingOrders ? (
                <div className="py-16 flex flex-col items-center justify-center space-y-2 text-stone-400">
                  <Loader2 className="w-8 h-8 animate-spin text-[#8c7355]" />
                  <span className="text-xs font-sans">Loading your orders...</span>
                </div>
              ) : orders.length === 0 ? (
                <div className="py-16 text-center space-y-4">
                  <Package className="w-12 h-12 text-stone-300 mx-auto" />
                  <h3 className="font-serif text-lg font-bold text-[#1a1815]">No Orders Placed Yet</h3>
                  <p className="text-xs text-stone-500 font-sans max-w-sm mx-auto">
                    Explore our curated artisanal hampers and place your first order.
                  </p>
                  <button
                    onClick={() => navigate('/gifts')}
                    className="bg-[#1a1815] text-white text-xs uppercase font-bold px-6 py-3 rounded-md hover:bg-[#8c7355] transition-colors cursor-pointer"
                  >
                    Explore Hampers
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {orders.map((order) => {
                    const isDelivered = order.status?.toLowerCase() === 'delivered';
                    return (
                      <div
                        key={order.id}
                        className="bg-[#faf8f5]/60 border border-[#e8dfd1] rounded-2xl p-5 sm:p-6 space-y-5 shadow-xs"
                      >
                        {/* Order Header */}
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#eee5d8] gap-3 text-xs font-sans">
                          <div>
                            <span className="font-serif font-bold text-base text-[#1a1815] block">
                              {order.orderId || `#${order.id.slice(0, 8)}`}
                            </span>
                            <span className="text-stone-500 text-[11px]">
                              Placed on{' '}
                              {new Date(order.date).toLocaleDateString('en-IN', {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric'
                              })}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 flex-wrap">
                            <span
                              className={`text-[11px] px-2.5 py-1 rounded-full font-bold uppercase tracking-wider flex items-center gap-1 ${
                                order.paymentStatus === 'paid'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              <CheckCircle2 className="w-3 h-3" />
                              Payment: {order.paymentStatus === 'paid' ? 'Paid' : 'Pending'}
                            </span>

                            <span
                              className={`text-[11px] px-2.5 py-1 rounded-full font-bold uppercase tracking-wider flex items-center gap-1 ${
                                isDelivered
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}
                            >
                              <Truck className="w-3 h-3" />
                              {order.status || 'Confirmed'}
                            </span>
                          </div>
                        </div>

                        {/* Order Items Preview */}
                        <div className="divide-y divide-[#f2ebe0]">
                          {(order.items || []).map((item, idx) => (
                            <div key={item.key || idx} className="py-3 flex items-center justify-between gap-4">
                              <div className="flex items-center gap-3 min-w-0">
                                <img
                                  src={item.product?.images?.[0] || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&q=80&w=400'}
                                  alt={item.product?.name || 'Hamper'}
                                  className="w-14 h-16 object-cover rounded-lg bg-stone-100 shrink-0 border border-[#e8dfd1]"
                                  referrerPolicy="no-referrer"
                                />
                                <div className="min-w-0">
                                  <h4 className="font-serif font-bold text-xs sm:text-sm text-[#1a1815] truncate">
                                    {item.product?.name || 'Luxury Gift Hamper'}
                                  </h4>
                                  <p className="text-[11px] text-stone-500 font-sans">
                                    Qty: {item.quantity} | {item.selectedSize || 'Standard'}
                                  </p>
                                  <span className="font-bold text-xs text-stone-900 font-sans">
                                    ₹{((item.price || item.product?.price || 0) * (item.quantity || 1)).toLocaleString('en-IN')}
                                  </span>
                                </div>
                              </div>

                              <div className="flex items-center gap-2 shrink-0">
                                {isDelivered && (
                                  <button
                                    onClick={() =>
                                      setReviewModalProduct({
                                        productId: item.productId || item.product?.id || 1,
                                        productName: item.product?.name || 'Luxury Hamper',
                                        orderId: order.id,
                                        city: order.shippingAddress?.city
                                      })
                                    }
                                    className="text-[11px] font-bold text-[#8c7355] hover:text-[#1a1815] border border-[#8c7355] hover:bg-[#8c7355]/10 px-3 py-1.5 rounded-md transition-colors flex items-center gap-1 cursor-pointer"
                                  >
                                    <Star className="w-3 h-3 fill-[#8c7355]" />
                                    <span>Rate & Review</span>
                                  </button>
                                )}
                                <button
                                  onClick={() => handleBuyAgain(item)}
                                  className="text-[11px] font-bold text-stone-700 hover:text-stone-900 bg-white border border-stone-300 px-3 py-1.5 rounded-md hover:bg-stone-50 transition-colors cursor-pointer"
                                >
                                  Buy Again
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Order Footer Actions */}
                        <div className="pt-3 border-t border-[#eee5d8] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="text-xs font-sans text-stone-600 space-y-0.5">
                            <div>
                              <strong>Total:</strong> ₹{order.totalAmount?.toLocaleString('en-IN')} • Tracking: <span className="font-mono text-stone-800">{order.trackingNumber || 'NVY94827104'}</span>
                            </div>
                            <div className="flex items-center gap-1.5 text-[11px] text-stone-700">
                              <span>🚚</span>
                              <span className="font-semibold">Est. Delivery: {order.estimatedDelivery || '7–15 Days'}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => setSelectedOrder(order)}
                              className="bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold px-4 py-2 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>View Order & Tracking</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: WISHLIST */}
          {activeTab === 'wishlist' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-[#e8dfd1] pb-4 flex items-center justify-between">
                <div>
                  <h2 className="font-serif text-2xl font-bold text-[#1a1815]">My Wishlist</h2>
                  <p className="text-xs text-stone-500 font-sans mt-0.5">
                    Your saved luxury gifts and artisanal hampers.
                  </p>
                </div>
                <span className="text-xs font-bold text-stone-500 font-sans">
                  {wishlist.length} Item(s)
                </span>
              </div>

              {wishlist.length === 0 ? (
                <div className="py-16 text-center space-y-4">
                  <Heart className="w-12 h-12 text-stone-300 mx-auto" />
                  <h3 className="font-serif text-lg font-bold text-[#1a1815]">Your Wishlist is Empty</h3>
                  <p className="text-xs text-stone-500 font-sans max-w-sm mx-auto">
                    Save items you love by tapping the heart icon on any hamper card.
                  </p>
                  <button
                    onClick={() => navigate('/gifts')}
                    className="bg-[#1a1815] text-white text-xs uppercase font-bold px-6 py-3 rounded-md hover:bg-[#8c7355] transition-colors cursor-pointer"
                  >
                    Discover Gifts
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  {wishlist.map((product) => (
                    <div
                      key={product.id}
                      className="bg-[#faf8f5]/60 border border-[#e8dfd1] rounded-xl overflow-hidden group flex flex-col justify-between"
                    >
                      <div className="relative">
                        <img
                          src={product.images?.[0]}
                          alt={product.name}
                          className="w-full h-48 object-cover bg-stone-100 group-hover:scale-105 transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />
                        <button
                          onClick={() => removeFromWishlist(product.id)}
                          className="absolute top-3 right-3 p-1.5 bg-white/90 rounded-full text-stone-400 hover:text-rose-600 shadow-sm transition-colors"
                          title="Remove from wishlist"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                        <div>
                          <h4 className="font-serif font-bold text-sm text-[#1a1815] truncate">
                            {product.name}
                          </h4>
                          <p className="text-xs text-[#8c7355] font-semibold mt-0.5">
                            ₹{product.price?.toLocaleString('en-IN')}
                          </p>
                        </div>

                        <button
                          onClick={() => {
                            addToCart(product, 1, 'Standard');
                            removeFromWishlist(product.id);
                            addToast(`Moved ${product.name} to your bag!`, 'success');
                            setIsCartOpen(true);
                          }}
                          className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white text-[11px] uppercase tracking-wider font-bold py-2.5 rounded-md transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Move to Bag</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: OFFERS & COUPONS */}
          {activeTab === 'offers' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-[#e8dfd1] pb-4">
                <h2 className="font-serif text-2xl font-bold text-[#1a1815]">Offers & Coupons</h2>
                <p className="text-xs text-stone-500 font-sans mt-0.5">
                  Exclusive celebration discounts and coupon codes for your account.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Coupon 1: NAVYA10 */}
                <div className="border-2 border-dashed border-[#8c7355] bg-[#faf8f5] rounded-2xl p-5 space-y-4 relative overflow-hidden">
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <span className="text-[10px] bg-[#8c7355] text-white font-bold uppercase tracking-widest px-2 py-0.5 rounded-xs inline-block">
                        WELCOME OFFER
                      </span>
                      <h3 className="font-serif text-xl font-bold text-[#1a1815]">10% Instant Discount</h3>
                      <p className="text-xs text-stone-600 font-sans">
                        Enjoy 10% off on all luxury gift hampers with no minimum order value.
                      </p>
                    </div>
                    <Tag className="w-8 h-8 text-[#8c7355]/40 shrink-0" />
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-[#e8dfd1]">
                    <span className="font-mono text-sm font-bold text-[#1a1815] bg-white border border-[#e8dfd1] px-3 py-1.5 rounded-md tracking-wider">
                      NAVYA10
                    </span>
                    <button
                      onClick={() => handleCopyCoupon('NAVYA10')}
                      className="bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-bold uppercase px-4 py-2 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      {copiedCode === 'NAVYA10' ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Code</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Coupon 2: FREESHIP */}
                <div className="border border-[#e8dfd1] bg-[#faf8f5]/60 rounded-2xl p-5 space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <span className="text-[10px] bg-emerald-700 text-white font-bold uppercase tracking-widest px-2 py-0.5 rounded-xs inline-block">
                        AUTOMATIC APPLIED
                      </span>
                      <h3 className="font-serif text-xl font-bold text-[#1a1815]">Complimentary Pan-India Shipping</h3>
                      <p className="text-xs text-stone-600 font-sans">
                        Express air delivery included on all orders with zero hidden delivery charges.
                      </p>
                    </div>
                    <Truck className="w-8 h-8 text-stone-400 shrink-0" />
                  </div>

                  <div className="pt-3 border-t border-[#e8dfd1] text-xs text-emerald-700 font-semibold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Auto-applied on all checkout orders</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: GIFT VOUCHERS */}
          {activeTab === 'vouchers' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-[#e8dfd1] pb-4">
                <h2 className="font-serif text-2xl font-bold text-[#1a1815]">Gift Vouchers</h2>
                <p className="text-xs text-stone-500 font-sans mt-0.5">
                  Manage your bespoke gifting credits, corporate balance, and gift card cards.
                </p>
              </div>

              <div className="bg-[#1a1815] text-[#faf8f5] rounded-2xl p-6 sm:p-8 space-y-6 relative overflow-hidden border border-[#363028]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-[0.2em] text-[#c5a880] block">
                      VOUCHER BALANCE
                    </span>
                    <span className="font-serif text-3xl font-bold text-white">₹0.00</span>
                    <p className="text-xs text-stone-400 font-sans mt-1">
                      No active gift card balance attached to this account.
                    </p>
                  </div>
                  <Gift className="w-12 h-12 text-[#c5a880]/30 shrink-0" />
                </div>

                <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <p className="text-xs text-stone-300 font-sans">
                    Looking for bespoke corporate vouchers or wedding bulk gift cards?
                  </p>
                  <a
                    href="https://wa.me/message/SE4USKU3N2UNE1"
                    target="_blank"
                    rel="noreferrer"
                    className="bg-[#c5a880] hover:bg-[#b0936b] text-[#1a1815] text-xs font-bold uppercase tracking-wider px-5 py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2 shrink-0"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>WhatsApp Concierge</span>
                  </a>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: SAVED ADDRESSES */}
          {activeTab === 'addresses' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-[#e8dfd1] pb-4 flex items-center justify-between">
                <div>
                  <h2 className="font-serif text-2xl font-bold text-[#1a1815]">Saved Addresses</h2>
                  <p className="text-xs text-stone-500 font-sans mt-0.5">
                    Manage your delivery addresses for seamless checkout.
                  </p>
                </div>
                <button
                  onClick={openAddAddressModal}
                  className="bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold px-4 py-2.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Address</span>
                </button>
              </div>

              {loadingAddresses ? (
                <div className="py-12 flex justify-center text-stone-400">
                  <Loader2 className="w-6 h-6 animate-spin" />
                </div>
              ) : addresses.length === 0 ? (
                <div className="py-12 text-center space-y-3 bg-[#faf8f5] rounded-xl border border-[#e8dfd1]">
                  <MapPin className="w-10 h-10 text-stone-300 mx-auto" />
                  <p className="text-xs text-stone-600 font-sans">No saved addresses yet.</p>
                  <button
                    onClick={openAddAddressModal}
                    className="text-xs font-bold text-[#8c7355] underline cursor-pointer"
                  >
                    + Add your first address
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {addresses.map((addr) => (
                    <div
                      key={addr.id}
                      className={`rounded-xl p-5 border transition-all space-y-3 relative ${
                        addr.is_default
                          ? 'border-[#8c7355] bg-[#faf8f5] ring-1 ring-[#8c7355]'
                          : 'border-[#e8dfd1] bg-white'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="font-bold text-sm text-[#1a1815] block">{addr.name}</span>
                          <span className="text-xs text-stone-500 font-sans">{addr.phone}</span>
                        </div>
                        {addr.is_default && (
                          <span className="text-[10px] bg-[#8c7355] text-white font-bold uppercase tracking-wider px-2 py-0.5 rounded-xs">
                            Default
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-stone-600 font-sans leading-relaxed">
                        {addr.street}
                        {addr.apartment ? `, ${addr.apartment}` : ''}
                        <br />
                        {addr.city}, {addr.state} - <strong>{addr.pincode}</strong>
                      </p>

                      <div className="pt-3 border-t border-[#eee5d8] flex items-center justify-between text-xs font-sans">
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => openEditAddressModal(addr)}
                            className="text-[#8c7355] hover:text-[#1a1815] font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                            <span>Edit</span>
                          </button>
                          <button
                            onClick={() => handleDeleteAddress(addr.id)}
                            className="text-stone-400 hover:text-rose-600 font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </button>
                        </div>

                        {!addr.is_default && (
                          <button
                            onClick={() => handleSetDefaultAddress(addr.id)}
                            className="text-xs text-stone-600 hover:text-black font-semibold underline cursor-pointer"
                          >
                            Set Default
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 7: MY REVIEWS */}
          {activeTab === 'reviews' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-[#e8dfd1] pb-4">
                <h2 className="font-serif text-2xl font-bold text-[#1a1815]">My Verified Reviews</h2>
                <p className="text-xs text-stone-500 font-sans mt-0.5">
                  Reviews written by you for verified delivered orders.
                </p>
              </div>

              {loadingReviews ? (
                <div className="py-12 flex justify-center text-stone-400">
                  <Loader2 className="w-6 h-6 animate-spin" />
                </div>
              ) : userReviews.length === 0 ? (
                <div className="py-12 text-center space-y-3 bg-[#faf8f5] rounded-xl border border-[#e8dfd1]">
                  <Star className="w-10 h-10 text-stone-300 mx-auto" />
                  <p className="text-xs text-stone-600 font-sans">
                    You haven't submitted any product reviews yet.
                  </p>
                  <p className="text-[11px] text-stone-400 font-sans">
                    You can rate and review products once your orders are delivered!
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {userReviews.map((rev) => (
                    <div key={rev.id} className="p-4 rounded-xl border border-[#e8dfd1] bg-[#faf8f5]/50 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`w-3.5 h-3.5 ${
                                s <= rev.rating ? 'text-[#c5a880] fill-[#c5a880]' : 'text-stone-300'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full font-bold">
                          ✓ Verified Purchase
                        </span>
                      </div>
                      {rev.title && <h4 className="font-serif font-bold text-sm text-[#1a1815]">{rev.title}</h4>}
                      <p className="text-xs text-stone-700 font-sans leading-relaxed">{rev.comment}</p>
                      <span className="text-[10px] text-stone-400 font-sans block">
                        Reviewed on {new Date(rev.created_at).toLocaleDateString('en-IN')}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 8: NOTIFICATIONS */}
          {activeTab === 'notifications' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-[#e8dfd1] pb-4">
                <h2 className="font-serif text-2xl font-bold text-[#1a1815]">Notifications</h2>
                <p className="text-xs text-stone-500 font-sans mt-0.5">
                  Realtime updates on your orders and exclusive boutique offers.
                </p>
              </div>

              <div className="space-y-3">
                {orders.length > 0 ? (
                  orders.map((order) => (
                    <div
                      key={order.id}
                      className="p-4 rounded-xl border border-[#e8dfd1] bg-[#faf8f5]/60 flex items-start gap-3"
                    >
                      <Package className="w-5 h-5 text-[#8c7355] shrink-0 mt-0.5" />
                      <div className="text-xs font-sans space-y-1">
                        <p className="font-bold text-stone-900">
                          Order {order.orderId} • Status: {order.status}
                        </p>
                        <p className="text-stone-500 text-[11px]">
                          Payment {order.paymentStatus === 'paid' ? 'confirmed' : 'pending'}. Pan-India express dispatch.
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 rounded-xl border border-[#e8dfd1] bg-[#faf8f5]/60 flex items-start gap-3">
                    <Sparkles className="w-5 h-5 text-[#c5a880] shrink-0 mt-0.5" />
                    <div className="text-xs font-sans space-y-1">
                      <p className="font-bold text-stone-900">Welcome to Navya Gift Hamper!</p>
                      <p className="text-stone-500 text-[11px]">
                        Enjoy 10% off your first luxury order using coupon code <strong>NAVYA10</strong>.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 9: ACCOUNT SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              <div className="border-b border-[#e8dfd1] pb-4">
                <h2 className="font-serif text-2xl font-bold text-[#1a1815]">Account Settings</h2>
                <p className="text-xs text-stone-500 font-sans mt-0.5">
                  Update your personal details, password, and communication preferences.
                </p>
              </div>

              {/* Personal Info Form */}
              <form onSubmit={handleProfileUpdate} className="space-y-4 max-w-lg">
                <h3 className="font-serif font-bold text-base text-[#1a1815]">Personal Information</h3>
                <div className="space-y-3 font-sans text-xs">
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Full Name</label>
                    <input
                      type="text"
                      value={profileForm.name}
                      onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                      className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md p-2.5 focus:outline-none focus:border-[#8c7355]"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Email Address</label>
                    <input
                      type="email"
                      value={user?.email || ''}
                      disabled
                      className="w-full bg-stone-100 border border-stone-200 text-stone-500 rounded-md p-2.5 cursor-not-allowed"
                    />
                    <span className="text-[10px] text-stone-400 mt-0.5 block">Managed via InsForge Auth</span>
                  </div>
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Mobile Number</label>
                    <input
                      type="tel"
                      value={profileForm.phone}
                      onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                      placeholder="10-digit mobile number"
                      className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md p-2.5 focus:outline-none focus:border-[#8c7355]"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={isUpdatingProfile}
                  className="bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold px-5 py-2.5 rounded-md transition-colors disabled:opacity-50 cursor-pointer"
                >
                  {isUpdatingProfile ? 'Saving...' : 'Save Profile Changes'}
                </button>
              </form>

              {/* Security / Password Form */}
              <form onSubmit={handlePasswordUpdate} className="space-y-4 max-w-lg pt-6 border-t border-[#e8dfd1]">
                <h3 className="font-serif font-bold text-base text-[#1a1815]">Security & Password</h3>
                <div className="space-y-3 font-sans text-xs">
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">New Password</label>
                    <input
                      type="password"
                      value={passwordForm.newPassword}
                      onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                      placeholder="Minimum 6 characters"
                      className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md p-2.5 focus:outline-none focus:border-[#8c7355]"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-700 font-semibold mb-1">Confirm New Password</label>
                    <input
                      type="password"
                      value={passwordForm.confirmPassword}
                      onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                      placeholder="Re-enter new password"
                      className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md p-2.5 focus:outline-none focus:border-[#8c7355]"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={isUpdatingPassword}
                  className="bg-white border border-[#1a1815] text-[#1a1815] hover:bg-stone-50 text-xs uppercase font-bold px-5 py-2.5 rounded-md transition-colors disabled:opacity-50 cursor-pointer"
                >
                  {isUpdatingPassword ? 'Updating...' : 'Change Password'}
                </button>
              </form>

              {/* Notifications Toggles */}
              <div className="space-y-4 max-w-lg pt-6 border-t border-[#e8dfd1]">
                <h3 className="font-serif font-bold text-base text-[#1a1815]">Notification Preferences</h3>
                <div className="space-y-3 text-xs font-sans">
                  <label className="flex items-center justify-between p-3 rounded-lg bg-[#faf8f5] border border-[#e8dfd1] cursor-pointer">
                    <span className="font-semibold text-stone-800">Order & Tracking Updates</span>
                    <input
                      type="checkbox"
                      checked={notifications.orderUpdates}
                      onChange={(e) => setNotifications({ ...notifications, orderUpdates: e.target.checked })}
                      className="w-4 h-4 accent-[#8c7355]"
                    />
                  </label>
                  <label className="flex items-center justify-between p-3 rounded-lg bg-[#faf8f5] border border-[#e8dfd1] cursor-pointer">
                    <span className="font-semibold text-stone-800">Promotions & Boutique Offers</span>
                    <input
                      type="checkbox"
                      checked={notifications.promotions}
                      onChange={(e) => setNotifications({ ...notifications, promotions: e.target.checked })}
                      className="w-4 h-4 accent-[#8c7355]"
                    />
                  </label>
                </div>
              </div>

              {/* Danger Zone: Log Out / Delete Account */}
              <div className="pt-6 border-t border-[#e8dfd1] space-y-3">
                <h3 className="font-serif font-bold text-base text-rose-700">Account Management</h3>
                <div className="flex items-center gap-3">
                  <button
                    onClick={handleSignOut}
                    className="bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 text-xs font-bold px-4 py-2.5 rounded-md transition-colors cursor-pointer"
                  >
                    Log Out of Account
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 10: HELP & SUPPORT */}
          {activeTab === 'help' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="border-b border-[#e8dfd1] pb-4">
                <h2 className="font-serif text-2xl font-bold text-[#1a1815]">Help & Support</h2>
                <p className="text-xs text-stone-500 font-sans mt-0.5">
                  Get in touch with our concierge team.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <a
                  href="https://wa.me/message/SE4USKU3N2UNE1"
                  target="_blank"
                  rel="noreferrer"
                  className="p-5 rounded-2xl border border-[#25D366]/30 bg-[#25D366]/5 hover:bg-[#25D366]/10 transition-colors flex items-start gap-4"
                >
                  <MessageCircle className="w-6 h-6 text-[#25D366] shrink-0 mt-1" />
                  <div className="space-y-1">
                    <h3 className="font-bold text-sm text-[#1a1815]">WhatsApp Concierge</h3>
                    <p className="text-xs text-stone-600 font-sans">
                      Chat directly with our gifting concierge for custom requests and urgent queries.
                    </p>
                  </div>
                </a>

                <a
                  href="mailto:Supportnavya0@gmail.com"
                  className="p-5 rounded-2xl border border-[#8c7355]/30 bg-[#faf8f5] hover:bg-[#f5f0e6] transition-colors flex items-start gap-4"
                >
                  <Mail className="w-6 h-6 text-[#8c7355] shrink-0 mt-1" />
                  <div className="space-y-1">
                    <h3 className="font-bold text-sm text-[#1a1815]">Email Support</h3>
                    <p className="text-xs text-stone-600 font-sans">
                      Supportnavya0@gmail.com • Quick responses within 2-4 business hours.
                    </p>
                  </div>
                </a>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* ─── MODAL: ORDER DETAILS & TRACKING TIMELINE ───────────────────────── */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#faf8f5] border border-[#e8dfd1] rounded-2xl w-full max-w-2xl p-6 sm:p-8 shadow-2xl max-h-[90vh] overflow-y-auto space-y-6 relative">
            <button
              onClick={() => setSelectedOrder(null)}
              className="absolute top-4 right-4 p-2 text-stone-400 hover:text-black rounded-full transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[#8c7355]">
                ORDER SPECIFICATION
              </span>
              <h3 className="font-serif text-2xl font-bold text-[#1a1815]">
                {selectedOrder.orderId || `#${selectedOrder.id}`}
              </h3>
              <p className="text-xs text-stone-500 font-sans">
                Placed on {new Date(selectedOrder.date).toLocaleString('en-IN')}
              </p>
            </div>

            {/* Visual Timeline */}
            <div className="bg-white p-4 rounded-xl border border-[#e8dfd1] space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 font-sans">
                Live Delivery Tracking
              </h4>
              <div className="grid grid-cols-5 gap-1 text-center font-sans">
                {statusProgressSteps.map((step, idx) => {
                  const currentIdx = getStatusStepIndex(selectedOrder.status);
                  const isDone = idx <= currentIdx;
                  return (
                    <div key={step} className="space-y-1">
                      <div
                        className={`h-2 rounded-full transition-colors ${
                          isDone ? 'bg-[#8c7355]' : 'bg-stone-200'
                        }`}
                      />
                      <span
                        className={`text-[10px] font-semibold block ${
                          isDone ? 'text-stone-900 font-bold' : 'text-stone-400'
                        }`}
                      >
                        {step}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Items */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 font-sans">
                Purchased Items ({selectedOrder.items?.length || 0})
              </h4>
              <div className="bg-white rounded-xl border border-[#e8dfd1] divide-y divide-[#eee6d8] p-3">
                {(selectedOrder.items || []).map((it, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between text-xs font-sans">
                    <div className="flex items-center gap-3">
                      <img
                        src={it.product?.images?.[0] || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&q=80&w=400'}
                        alt={it.product?.name}
                        className="w-12 h-14 object-cover rounded-md bg-stone-100"
                      />
                      <div>
                        <p className="font-bold text-stone-900">{it.product?.name}</p>
                        <p className="text-stone-500 text-[11px]">
                          Qty: {it.quantity} | {it.selectedSize || 'Standard'}
                        </p>
                      </div>
                    </div>
                    <span className="font-bold text-stone-900">
                      ₹{((it.price || it.product?.price || 0) * (it.quantity || 1)).toLocaleString('en-IN')}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Summary & Shipping */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
              <div className="bg-white p-4 rounded-xl border border-[#e8dfd1] space-y-1.5">
                <span className="font-bold text-stone-900 block">Shipping Address:</span>
                <p className="text-stone-600 leading-relaxed">
                  {selectedOrder.shippingAddress?.street}
                  {selectedOrder.shippingAddress?.apartment ? `, ${selectedOrder.shippingAddress.apartment}` : ''}
                  <br />
                  {selectedOrder.shippingAddress?.city}, {selectedOrder.shippingAddress?.state} - {selectedOrder.shippingAddress?.pincode}
                </p>
                <p className="text-stone-500 text-[11px]">Phone: {selectedOrder.customer?.phone}</p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#e8dfd1] space-y-1.5">
                <span className="font-bold text-stone-900 block">Payment Summary:</span>
                <div className="flex justify-between text-stone-600">
                  <span>Method:</span>
                  <span className="font-semibold">{selectedOrder.paymentMethod || 'Google Pay / UPI'}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Payment Status:</span>
                  <span className="font-bold text-emerald-700 capitalize">{selectedOrder.paymentStatus}</span>
                </div>
                {selectedOrder.transactionId && (
                  <div className="flex justify-between text-stone-600">
                    <span>Transaction ID:</span>
                    <span className="font-mono text-[10px]">{selectedOrder.transactionId}</span>
                  </div>
                )}
                <div className="flex justify-between font-serif font-bold text-sm text-[#1a1815] pt-1 border-t border-stone-200">
                  <span>Total Amount:</span>
                  <span>₹{selectedOrder.totalAmount?.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>

              {/* Delivery Estimate Card */}
              <div className="flex items-start gap-3 bg-gradient-to-br from-[#f5f0e6] to-[#faf8f5] border border-[#dfc99e] rounded-xl px-4 py-3.5 text-xs font-sans">
                <span className="text-lg shrink-0 mt-0.5">🚚</span>
                <div className="space-y-0.5">
                  <span className="font-serif font-bold text-[#1a1815] text-sm block">
                    Estimated Delivery: {selectedOrder.estimatedDelivery || '7–15 Days'}
                  </span>
                  <span className="text-[11px] text-stone-600 leading-relaxed block">
                    Calculated from order confirmation. May vary due to courier delays, public holidays, weather, or address factors. Not a guaranteed delivery date.
                  </span>
                </div>
              </div>
          </div>
        </div>
      )}

      {/* ─── MODAL: RATE & REVIEW PRODUCT ──────────────────────────────────── */}
      {reviewModalProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#faf8f5] border border-[#e8dfd1] rounded-2xl w-full max-w-md p-6 sm:p-8 shadow-2xl space-y-5 relative">
            <button
              onClick={() => setReviewModalProduct(null)}
              className="absolute top-4 right-4 p-2 text-stone-400 hover:text-black rounded-full"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[#8c7355]">
                VERIFIED PURCHASE REVIEW
              </span>
              <h3 className="font-serif text-xl font-bold text-[#1a1815]">
                Rate & Review
              </h3>
              <p className="text-xs text-stone-600 font-sans mt-0.5 truncate">
                {reviewModalProduct.productName}
              </p>
            </div>

            <form onSubmit={handleReviewSubmit} className="space-y-4 font-sans text-xs">
              {/* Star selector */}
              <div>
                <label className="block text-stone-700 font-semibold mb-1">Your Rating</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setReviewForm({ ...reviewForm, rating: star })}
                      className="p-1 cursor-pointer focus:outline-none"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= reviewForm.rating ? 'text-[#c5a880] fill-[#c5a880]' : 'text-stone-300'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-bold text-stone-800 ml-2">
                    {reviewForm.rating} / 5 Stars
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-semibold mb-1">Headline / Title</label>
                <input
                  type="text"
                  value={reviewForm.title}
                  onChange={(e) => setReviewForm({ ...reviewForm, title: e.target.value })}
                  placeholder="e.g. Exquisite gift packaging and fresh sweets!"
                  className="w-full bg-white border border-[#e8dfd1] rounded-md p-2.5 focus:outline-none focus:border-[#8c7355]"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-semibold mb-1">Detailed Review *</label>
                <textarea
                  rows={4}
                  value={reviewForm.comment}
                  onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                  placeholder="Write your review here..."
                  className="w-full bg-white border border-[#e8dfd1] rounded-md p-2.5 focus:outline-none focus:border-[#8c7355]"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmittingReview}
                className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold py-3 rounded-lg shadow-md transition-colors disabled:opacity-50 cursor-pointer"
              >
                {isSubmittingReview ? 'Submitting...' : 'Publish Verified Review'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ─── MODAL: ADD / EDIT ADDRESS ──────────────────────────────────────── */}
      {addressModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#faf8f5] border border-[#e8dfd1] rounded-2xl w-full max-w-lg p-6 sm:p-8 shadow-2xl space-y-5 relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setAddressModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-stone-400 hover:text-black rounded-full"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[#8c7355]">
                DELIVERY DESTINATION
              </span>
              <h3 className="font-serif text-xl font-bold text-[#1a1815]">
                {editingAddress ? 'Edit Address' : 'Add New Address'}
              </h3>
            </div>

            <form onSubmit={handleSaveAddress} className="space-y-4 font-sans text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-700 font-semibold mb-1">Recipient Name *</label>
                  <input
                    type="text"
                    required
                    value={addressForm.name}
                    onChange={(e) => setAddressForm({ ...addressForm, name: e.target.value })}
                    className="w-full bg-white border border-[#e8dfd1] rounded-md p-2.5"
                  />
                </div>
                <div>
                  <label className="block text-stone-700 font-semibold mb-1">Contact Phone *</label>
                  <input
                    type="tel"
                    required
                    value={addressForm.phone}
                    onChange={(e) => setAddressForm({ ...addressForm, phone: e.target.value })}
                    className="w-full bg-white border border-[#e8dfd1] rounded-md p-2.5"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-semibold mb-1">Street Address / House No. *</label>
                <input
                  type="text"
                  required
                  value={addressForm.street}
                  onChange={(e) => setAddressForm({ ...addressForm, street: e.target.value })}
                  placeholder="House/Flat No., Road"
                  className="w-full bg-white border border-[#e8dfd1] rounded-md p-2.5"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-semibold mb-1">Landmark / Apartment (optional)</label>
                <input
                  type="text"
                  value={addressForm.apartment}
                  onChange={(e) => setAddressForm({ ...addressForm, apartment: e.target.value })}
                  className="w-full bg-white border border-[#e8dfd1] rounded-md p-2.5"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-stone-700 font-semibold mb-1">City *</label>
                  <input
                    type="text"
                    required
                    value={addressForm.city}
                    onChange={(e) => setAddressForm({ ...addressForm, city: e.target.value })}
                    className="w-full bg-white border border-[#e8dfd1] rounded-md p-2.5"
                  />
                </div>
                <div>
                  <label className="block text-stone-700 font-semibold mb-1">State *</label>
                  <input
                    type="text"
                    required
                    value={addressForm.state}
                    onChange={(e) => setAddressForm({ ...addressForm, state: e.target.value })}
                    className="w-full bg-white border border-[#e8dfd1] rounded-md p-2.5"
                  />
                </div>
                <div>
                  <label className="block text-stone-700 font-semibold mb-1">PIN Code *</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={addressForm.pincode}
                    onChange={(e) => setAddressForm({ ...addressForm, pincode: e.target.value.replace(/\D/g, '') })}
                    className="w-full bg-white border border-[#e8dfd1] rounded-md p-2.5"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 pt-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={addressForm.is_default}
                  onChange={(e) => setAddressForm({ ...addressForm, is_default: e.target.checked })}
                  className="w-4 h-4 accent-[#8c7355]"
                />
                <span className="text-stone-700 font-semibold">Set as default delivery address</span>
              </label>

              <button
                type="submit"
                disabled={isSavingAddress}
                className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold py-3 rounded-lg shadow-md transition-colors disabled:opacity-50 cursor-pointer"
              >
                {isSavingAddress ? 'Saving Address...' : 'Save Address'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
