import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Trash2, ShoppingBag, ArrowRight, ChevronRight } from 'lucide-react';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { ProductCard } from '../components/ProductCard';

export const Wishlist = () => {
  const { wishlist, removeFromWishlist } = useWishlist();
  const { addToCart } = useCart();

  if (wishlist.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center space-y-6">
        <div className="w-20 h-20 bg-[#f4efe6] rounded-full flex items-center justify-center text-[#8c7355] mx-auto">
          <Heart className="w-10 h-10 stroke-[1.5]" />
        </div>
        <div className="space-y-2">
          <h1 className="font-serif text-3xl font-bold text-[#1a1815]">
            YOUR WISHLIST IS EMPTY
          </h1>
          <p className="font-serif italic text-[#8c7a65]">
            “Save your favorite hampers and personalized gifts to review later.”
          </p>
        </div>
        <div className="pt-2">
          <Link
            to="/gifts"
            className="inline-flex items-center gap-2 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest px-8 py-4 rounded-md transition-colors shadow-lg"
          >
            <span>EXPLORE HAMPERS</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs text-stone-500 font-sans">
        <Link to="/" className="hover:text-black">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <span className="font-semibold text-[#1a1815]">Saved Items</span>
      </nav>

      <div className="flex justify-between items-baseline border-b border-[#e8dfd1] pb-4">
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#1a1815] uppercase tracking-wide">
          YOUR WISHLIST ({wishlist.length})
        </h1>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {wishlist.map((item) => (
          <div key={item.id} className="flex flex-col h-full">
            <ProductCard product={item} />
            <div className="mt-2 flex gap-2">
              <button
                onClick={() => {
                  addToCart(item, 1);
                  removeFromWishlist(item.id);
                }}
                className="flex-1 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-semibold py-2.5 rounded-md flex items-center justify-center gap-1.5 transition-colors"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Move to Bag</span>
              </button>
              <button
                onClick={() => removeFromWishlist(item.id)}
                className="p-2.5 bg-white border border-[#e8dfd1] text-stone-500 hover:text-rose-600 rounded-md transition-colors"
                title="Remove"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
