import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Heart, Gift, Award, ArrowRight } from 'lucide-react';
import { PromoBanner } from '../components/PromoBanner';

export const About = () => {
  return (
    <div className="space-y-16 sm:space-y-20 pb-16">
      {/* Editorial Header */}
      <section className="relative py-20 bg-[#1a1815] text-[#faf8f5] text-center overflow-hidden">
        <div
          className="absolute inset-0 opacity-20 bg-cover bg-center"
          style={{
            backgroundImage:
              'url(https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&q=80&w=1600)'
          }}
        />
        <div className="relative z-10 max-w-3xl mx-auto px-4 space-y-6">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.3em] text-[#c5a880] px-4 py-1.5 rounded-full bg-[#2a241e] border border-[#4a3d30]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>OUR BRAND MANIFESTO</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl font-bold uppercase tracking-tight text-white leading-tight">
            GIFTING IS MORE THAN A PRESENT.{' '}
            <span className="italic font-normal text-[#c5a880] block">IT'S A FEELING.</span>
          </h1>

          <p className="font-serif italic text-lg sm:text-xl text-stone-300">
            “Navya Gift Hamper — Curated with Love, Gifted with Emotion.”
          </p>
        </div>
      </section>

      {/* Story & Heritage */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-4">
            <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#8c7a65]">
              OUR ORIGIN STORY
            </span>
            <h2 className="font-serif text-3xl font-bold text-[#1a1815] leading-tight">
              CRAFTED WITH BESPOKE PASSION
            </h2>
            <div className="w-12 h-0.5 bg-[#8c7355]" />
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed font-sans">
              Founded with a dedication to artisanal elegance, <strong>Navya Gift Hamper</strong> was born out of a passion to transform ordinary gifting into unforgettable emotional experiences.
            </p>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed font-sans">
              We believe that a gift should speak directly to the heart. Every element inside a Navya hamper—from hand-poured soy wax candles and engraved Italian leather wallets to preserved Ecuadorian roses and artisanal chocolates—is selected with meticulous attention to detail.
            </p>
          </div>

          <div className="relative aspect-4/3 rounded-xl overflow-hidden shadow-xl border border-[#e8dfd1]">
            <img
              src="https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&q=80&w=1000"
              alt="Craftsmanship"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* What We Offer Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#8c7a65]">
            EXCELLENCE IN EVERY BOX
          </span>
          <h2 className="font-serif text-3xl font-bold text-[#1a1815] uppercase tracking-wide">
            WHAT WE OFFER
          </h2>
          <div className="w-12 h-0.5 bg-[#8c7355] mx-auto mt-2" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 bg-white rounded-xl border border-[#e8dfd1] shadow-xs space-y-3">
            <Gift className="w-8 h-8 text-[#8c7355]" />
            <h3 className="font-serif text-lg font-bold text-[#1a1815]">🎁 Personalized Gift Hampers</h3>
            <p className="text-xs text-stone-600 font-sans leading-relaxed">
              Custom engraved names, custom polaroid frames, photo keychains, and parchment scrolls.
            </p>
          </div>

          <div className="p-6 bg-white rounded-xl border border-[#e8dfd1] shadow-xs space-y-3">
            <Award className="w-8 h-8 text-[#8c7355]" />
            <h3 className="font-serif text-lg font-bold text-[#1a1815]">👕 Fashion & Lifestyle</h3>
            <p className="text-xs text-stone-600 font-sans leading-relaxed">
              Silk scarves, leather wallets, ties, lapel pins, laptop backpacks, and pearl jewelry.
            </p>
          </div>

          <div className="p-6 bg-white rounded-xl border border-[#e8dfd1] shadow-xs space-y-3">
            <Heart className="w-8 h-8 text-[#8c7355]" />
            <h3 className="font-serif text-lg font-bold text-[#1a1815]">🍫 Artisanal Chocolates</h3>
            <p className="text-xs text-stone-600 font-sans leading-relaxed">
              Rich Belgian pralines, cocoa dark truffles, and gold foil-wrapped gift jars.
            </p>
          </div>

          <div className="p-6 bg-white rounded-xl border border-[#e8dfd1] shadow-xs space-y-3">
            <Sparkles className="w-8 h-8 text-[#8c7355]" />
            <h3 className="font-serif text-lg font-bold text-[#1a1815]">🌸 Perfumes & Self-Care</h3>
            <p className="text-xs text-stone-600 font-sans leading-relaxed">
              French Eau De Parfum, mulberry silk eye masks, bath salts, and botanical body mists.
            </p>
          </div>
        </div>
      </section>

      {/* Packaging Banner */}
      <PromoBanner variant="packaging" />

      {/* CTA */}
      <section className="text-center space-y-4">
        <h3 className="font-serif text-2xl font-bold text-[#1a1815]">
          READY TO CREATE A BEAUTIFUL MEMORY?
        </h3>
        <Link
          to="/gifts"
          className="inline-flex items-center gap-2 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest px-8 py-4 rounded-md shadow-lg transition-colors"
        >
          <span>EXPLORE OUR CURATED GIFTS</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </section>
    </div>
  );
};
