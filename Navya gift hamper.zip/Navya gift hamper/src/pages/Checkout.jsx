import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Truck,
  QrCode,
  ChevronRight,
  Lock,
  Upload,
  FileCheck,
  AlertCircle
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { orderService } from '../services/orderService';
import { addressService } from '../services/addressService';
import { useToast } from '../context/ToastContext';
import { useStore } from '../context/StoreContext';

// ─── Validation helpers ──────────────────────────────────────────────────────

const INDIAN_PHONE_RE = /^[6-9]\d{9}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PIN_RE = /^\d{6}$/;

function validate(customer, address) {
  const errors = {};

  if (!customer.name.trim()) {
    errors.name = 'Please enter your full name.';
  }
  if (!customer.email.trim()) {
    errors.email = 'Please enter your email address.';
  } else if (!EMAIL_RE.test(customer.email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }
  if (!customer.phone.trim()) {
    errors.phone = 'Please enter your mobile number.';
  } else if (!INDIAN_PHONE_RE.test(customer.phone.trim())) {
    errors.phone = 'Please enter a valid 10-digit Indian mobile number.';
  }

  if (!address.street.trim()) {
    errors.street = 'Please enter your delivery address.';
  }
  if (!address.city.trim()) {
    errors.city = 'Please enter your city.';
  }
  if (!address.state.trim()) {
    errors.state = 'Please enter your state.';
  }
  if (!address.pincode.trim()) {
    errors.pincode = 'Please enter your PIN code.';
  } else if (!PIN_RE.test(address.pincode.trim())) {
    errors.pincode = 'Please enter a valid 6-digit PIN code.';
  }

  return errors;
}

// ─── Inline error message component ─────────────────────────────────────────

const FieldError = ({ msg }) =>
  msg ? (
    <span className="flex items-center gap-1 text-[11px] text-red-600 font-sans mt-1">
      <AlertCircle className="w-3 h-3 shrink-0" />
      {msg}
    </span>
  ) : null;

// ─── Checkout page ────────────────────────────────────────────────────────────

export const Checkout = () => {
  const { cart, cartSubtotal, clearCart } = useCart();
  const { user, profile } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();

  // ── Customer fields: populated from authenticated profile
  const [customer, setCustomer] = useState({
    name: '',
    email: '',
    phone: ''
  });

  // ── Address fields
  const [address, setAddress] = useState({
    street: '',
    apartment: '',
    city: '',
    state: '',
    pincode: ''
  });

  const [savedAddresses, setSavedAddresses] = useState([]);
  const [selectedAddressId, setSelectedAddressId] = useState(null);

  // ── Sync user profile & fetch saved addresses
  useEffect(() => {
    if (!user) {
      setCustomer({ name: '', email: '', phone: '' });
      setSavedAddresses([]);
      return;
    }
    setCustomer({
      name: profile?.name || user?.user_metadata?.full_name || '',
      email: user.email || '',
      phone: profile?.phone || user?.user_metadata?.phone || ''
    });

    async function loadAddresses() {
      const list = await addressService.getUserAddresses(user.id);
      setSavedAddresses(list);
      if (list && list.length > 0) {
        const defaultAddr = list.find((a) => a.is_default) || list[0];
        setSelectedAddressId(defaultAddr.id);
        setAddress({
          street: defaultAddr.street || '',
          apartment: defaultAddr.apartment || '',
          city: defaultAddr.city || '',
          state: defaultAddr.state || '',
          pincode: defaultAddr.pincode || ''
        });
      }
    }
    loadAddresses();
  }, [user, profile]);

  const handleSelectSavedAddress = (addr) => {
    setSelectedAddressId(addr.id);
    setAddress({
      street: addr.street || '',
      apartment: addr.apartment || '',
      city: addr.city || '',
      state: addr.state || '',
      pincode: addr.pincode || ''
    });
    if (addr.name && !customer.name) {
      setCustomer((prev) => ({ ...prev, name: addr.name }));
    }
    if (addr.phone && !customer.phone) {
      setCustomer((prev) => ({ ...prev, phone: addr.phone }));
    }
  };

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [paymentProofFile, setPaymentProofFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [termsError, setTermsError] = useState(false);

  const { delivery } = useStore();
  const deliveryMethod = 'Standard';
  const paymentMethod = 'UPI';
  const standardFee = Number(delivery?.standard_fee) || 0;
  const freeThreshold = Number(delivery?.free_shipping_threshold) || 999;
  const isFreeDelivery = cartSubtotal >= freeThreshold || standardFee === 0;
  const shippingFee = isFreeDelivery ? 0 : standardFee;
  const totalAmount = cartSubtotal + shippingFee;

  // ── Mark a field as touched so its error shows after first blur
  const touch = (field) => setTouched((prev) => ({ ...prev, [field]: true }));

  // ── Re-validate whenever form state changes (after first touch)
  useEffect(() => {
    if (Object.keys(touched).length === 0) return;
    setErrors(validate(customer, address));
  }, [customer, address, touched]);

  // ── Empty cart guard
  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="font-serif text-2xl font-bold text-[#1a1815]">No Items to Checkout</h2>
        <p className="text-xs text-stone-500 font-sans">
          Your gift bag is empty. Add items before checking out.
        </p>
        <Link
          to="/gifts"
          className="inline-block bg-[#1a1815] text-white text-xs uppercase font-semibold px-6 py-3 rounded-md"
        >
          Discover Hampers
        </Link>
      </div>
    );
  }

  // ── Submit handler — validate everything first
  const handlePlaceOrder = async (e) => {
    e.preventDefault();

    // Touch all fields to reveal all errors
    setTouched({
      name: true, email: true, phone: true,
      street: true, city: true, state: true, pincode: true
    });

    const validationErrors = validate(customer, address);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      addToast('Please fill in all required fields correctly.', 'error');
      return;
    }

    if (!acceptedTerms) {
      setTermsError(true);
      addToast('Please accept the Terms & Conditions to place your order.', 'error');
      return;
    }
    setTermsError(false);

    setIsProcessing(true);

    const orderPayload = {
      userId: user?.id || null,
      items: cart,
      shippingAddress: address,
      customer: {
        name: customer.name.trim(),
        email: customer.email.trim(),
        phone: customer.phone.trim()
      },
      deliveryMethod,
      paymentMethod,
      subtotal: cartSubtotal,
      shippingFee,
      totalAmount
    };

    const res = await orderService.createOrder(orderPayload, paymentProofFile);
    setIsProcessing(false);

    if (res.success) {
      clearCart();
      const targetOrderId = res.order?.id || res.order?.orderId;
      addToast('Order created! Redirecting to secure payment page...', 'success');
      navigate(`/payment/${targetOrderId}`);
    } else {
      addToast(res.error || 'Failed to create order. Please try again.', 'error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs text-stone-500 font-sans">
        <Link to="/" className="hover:text-black">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <Link to="/cart" className="hover:text-black">Bag</Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <span className="font-semibold text-[#1a1815]">Checkout</span>
      </nav>

      <div className="flex items-center justify-between border-b border-[#e8dfd1] pb-4">
        <h1 className="font-serif text-3xl font-bold text-[#1a1815] uppercase tracking-wide">
          CHECKOUT
        </h1>
        <div className="flex items-center gap-1 text-xs text-stone-500 font-sans">
          <Lock className="w-4 h-4 text-emerald-600" />
          <span>256-Bit SSL Encrypted</span>
        </div>
      </div>

      {/* Guest notice */}
      {!user && (
        <div className="bg-[#faf8f5] border border-[#e8dfd1] rounded-xl px-4 py-3 text-xs font-sans text-stone-600 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-[#8c7355] shrink-0 mt-0.5" />
          <span>
            You are checking out as a <strong>guest</strong>. Please enter your details below.
            {' '}
            <Link to="/login" className="text-[#8c7355] font-semibold underline underline-offset-2">
              Sign in
            </Link>
            {' '}to auto-fill your saved information.
          </span>
        </div>
      )}

      <form onSubmit={handlePlaceOrder} noValidate className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left Column */}
        <div className="lg:col-span-7 space-y-8">

          {/* 1. Customer Information */}
          <div className="bg-white rounded-xl p-6 border border-[#e8dfd1] shadow-xs space-y-4">
            <h3 className="font-serif text-base font-bold text-[#1a1815] uppercase tracking-wider flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#1a1815] text-white text-xs flex items-center justify-center font-sans font-bold">1</span>
              CUSTOMER INFORMATION
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans text-xs">
              <div>
                <label className="block text-stone-700 font-semibold mb-1">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  id="checkout-name"
                  type="text"
                  value={customer.name}
                  placeholder="Enter your full name"
                  autoComplete="name"
                  onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
                  onBlur={() => touch('name')}
                  className={`w-full bg-[#faf8f5] border rounded-md p-2.5 focus:outline-none focus:border-[#8c7355] transition-colors ${
                    touched.name && errors.name ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                  }`}
                />
                <FieldError msg={touched.name && errors.name} />
              </div>

              <div>
                <label className="block text-stone-700 font-semibold mb-1">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  id="checkout-email"
                  type="email"
                  value={customer.email}
                  placeholder="your@email.com"
                  autoComplete="email"
                  onChange={(e) => setCustomer({ ...customer, email: e.target.value })}
                  onBlur={() => touch('email')}
                  className={`w-full bg-[#faf8f5] border rounded-md p-2.5 focus:outline-none focus:border-[#8c7355] transition-colors ${
                    touched.email && errors.email ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                  }`}
                />
                <FieldError msg={touched.email && errors.email} />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-stone-700 font-semibold mb-1">
                  Mobile Number <span className="text-red-500">*</span>
                  <span className="font-normal text-stone-400 ml-1">(for delivery updates)</span>
                </label>
                <input
                  id="checkout-phone"
                  type="tel"
                  value={customer.phone}
                  placeholder="10-digit mobile number"
                  autoComplete="tel"
                  maxLength={10}
                  onChange={(e) => setCustomer({ ...customer, phone: e.target.value.replace(/\D/g, '') })}
                  onBlur={() => touch('phone')}
                  className={`w-full bg-[#faf8f5] border rounded-md p-2.5 focus:outline-none focus:border-[#8c7355] transition-colors ${
                    touched.phone && errors.phone ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                  }`}
                />
                <FieldError msg={touched.phone && errors.phone} />
              </div>
            </div>
          </div>

          {/* 2. Delivery Address */}
          <div className="bg-white rounded-xl p-6 border border-[#e8dfd1] shadow-xs space-y-4">
            <h3 className="font-serif text-base font-bold text-[#1a1815] uppercase tracking-wider flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#1a1815] text-white text-xs flex items-center justify-center font-sans font-bold">2</span>
              DELIVERY ADDRESS (PAN-INDIA)
            </h3>

            {savedAddresses && savedAddresses.length > 0 && (
              <div className="space-y-2 pb-3 border-b border-[#e8dfd1]">
                <span className="text-[11px] font-bold text-stone-600 uppercase tracking-wider block">
                  Select From Saved Addresses:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {savedAddresses.map((addr) => (
                    <button
                      key={addr.id}
                      type="button"
                      onClick={() => handleSelectSavedAddress(addr)}
                      className={`text-left p-3 rounded-lg border text-xs transition-all cursor-pointer ${
                        selectedAddressId === addr.id
                          ? 'border-[#8c7355] bg-[#f5f0e6] ring-1 ring-[#8c7355]'
                          : 'border-[#e8dfd1] bg-[#faf8f5] hover:border-stone-400'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-stone-900 truncate">{addr.name || 'Saved Address'}</span>
                        {addr.is_default && (
                          <span className="text-[10px] bg-[#8c7355] text-white px-1.5 py-0.5 rounded-xs font-semibold">
                            Default
                          </span>
                        )}
                      </div>
                      <p className="text-stone-600 text-[11px] truncate mt-0.5">
                        {addr.street}, {addr.city} ({addr.pincode})
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans text-xs">
              <div className="sm:col-span-2">
                <label className="block text-stone-700 font-semibold mb-1">
                  Street Address / House No. <span className="text-red-500">*</span>
                </label>
                <input
                  id="checkout-street"
                  type="text"
                  value={address.street}
                  placeholder="House / Flat no., Street name"
                  autoComplete="address-line1"
                  onChange={(e) => setAddress({ ...address, street: e.target.value })}
                  onBlur={() => touch('street')}
                  className={`w-full bg-[#faf8f5] border rounded-md p-2.5 focus:outline-none focus:border-[#8c7355] transition-colors ${
                    touched.street && errors.street ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                  }`}
                />
                <FieldError msg={touched.street && errors.street} />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-stone-700 font-semibold mb-1">
                  Landmark / Apartment
                  <span className="font-normal text-stone-400 ml-1">(optional)</span>
                </label>
                <input
                  id="checkout-apartment"
                  type="text"
                  value={address.apartment}
                  placeholder="Landmark, apartment, floor, etc."
                  autoComplete="address-line2"
                  onChange={(e) => setAddress({ ...address, apartment: e.target.value })}
                  className="w-full bg-[#faf8f5] border border-[#e8dfd1] rounded-md p-2.5 focus:outline-none focus:border-[#8c7355] transition-colors"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-semibold mb-1">
                  City <span className="text-red-500">*</span>
                </label>
                <input
                  id="checkout-city"
                  type="text"
                  value={address.city}
                  placeholder="Your city"
                  autoComplete="address-level2"
                  onChange={(e) => setAddress({ ...address, city: e.target.value })}
                  onBlur={() => touch('city')}
                  className={`w-full bg-[#faf8f5] border rounded-md p-2.5 focus:outline-none focus:border-[#8c7355] transition-colors ${
                    touched.city && errors.city ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                  }`}
                />
                <FieldError msg={touched.city && errors.city} />
              </div>

              <div>
                <label className="block text-stone-700 font-semibold mb-1">
                  State <span className="text-red-500">*</span>
                </label>
                <input
                  id="checkout-state"
                  type="text"
                  value={address.state}
                  placeholder="Your state"
                  autoComplete="address-level1"
                  onChange={(e) => setAddress({ ...address, state: e.target.value })}
                  onBlur={() => touch('state')}
                  className={`w-full bg-[#faf8f5] border rounded-md p-2.5 focus:outline-none focus:border-[#8c7355] transition-colors ${
                    touched.state && errors.state ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                  }`}
                />
                <FieldError msg={touched.state && errors.state} />
              </div>

              <div>
                <label className="block text-stone-700 font-semibold mb-1">
                  PIN Code <span className="text-red-500">*</span>
                </label>
                <input
                  id="checkout-pincode"
                  type="text"
                  value={address.pincode}
                  placeholder="6-digit PIN code"
                  autoComplete="postal-code"
                  maxLength={6}
                  onChange={(e) => setAddress({ ...address, pincode: e.target.value.replace(/\D/g, '') })}
                  onBlur={() => touch('pincode')}
                  className={`w-full bg-[#faf8f5] border rounded-md p-2.5 focus:outline-none focus:border-[#8c7355] transition-colors ${
                    touched.pincode && errors.pincode ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                  }`}
                />
                <FieldError msg={touched.pincode && errors.pincode} />
              </div>
            </div>
          </div>

          {/* 3. Delivery Method */}
          <div className="bg-white rounded-xl p-6 border border-[#e8dfd1] shadow-xs space-y-4">
            <h3 className="font-serif text-base font-bold text-[#1a1815] uppercase tracking-wider flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#1a1815] text-white text-xs flex items-center justify-center font-sans font-bold">3</span>
              DELIVERY SPEED
            </h3>
            <div className="space-y-3 font-sans text-xs">
              <div className="flex items-center justify-between p-4 rounded-lg border border-[#8c7355] bg-[#f5f0e6] ring-1 ring-[#8c7355]">
                <div className="flex items-center gap-3">
                  <Truck className="w-5 h-5 text-[#8c7355]" />
                  <div>
                    <span className="font-bold text-stone-900 block">Standard Express Shipping</span>
                    <span className="text-stone-500 text-[11px]">Complimentary pan-India delivery with live SMS tracking</span>
                  </div>
                </div>
                <span className="font-bold text-emerald-700 uppercase tracking-wider text-xs">FREE</span>
              </div>
            </div>
          </div>

          {/* 4. Payment Method & Proof Upload */}
          <div className="bg-white rounded-xl p-6 border border-[#e8dfd1] shadow-xs space-y-4">
            <h3 className="font-serif text-base font-bold text-[#1a1815] uppercase tracking-wider flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#1a1815] text-white text-xs flex items-center justify-center font-sans font-bold">4</span>
              PAYMENT METHOD
            </h3>
            <div className="space-y-3 font-sans text-xs">
              <div className="flex items-center justify-between p-4 rounded-lg border border-[#8c7355] bg-[#f5f0e6] ring-1 ring-[#8c7355]">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded-full bg-[#8c7355] flex items-center justify-center text-white text-[10px]">✓</div>
                  <div className="flex items-center gap-2">
                    <QrCode className="w-5 h-5 text-[#8c7355]" />
                    <div>
                      <span className="font-bold text-stone-900 block">Google Pay / UPI Instant Payment</span>
                      <span className="text-[11px] text-stone-500 font-mono">vishualk375-2@okaxis</span>
                    </div>
                  </div>
                </div>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-xs">Instant</span>
              </div>
            </div>

            {/* Optional receipt upload */}
            <div className="pt-3 border-t border-[#e8dfd1] space-y-2">
              <label className="block text-stone-700 font-semibold text-xs">
                Upload Payment Screenshot / Receipt
                <span className="font-normal text-stone-400 ml-1">(optional — attach after paying)</span>
              </label>
              <div className="flex items-center gap-3">
                <label className="cursor-pointer bg-[#faf8f5] hover:bg-[#f5f0e6] border border-dashed border-[#8c7355] rounded-lg px-4 py-3 flex items-center gap-2 text-stone-700 font-semibold text-xs transition-colors">
                  <Upload className="w-4 h-4 text-[#8c7355]" />
                  <span>{paymentProofFile ? paymentProofFile.name : 'Choose Payment Receipt Image'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setPaymentProofFile(e.target.files[0] || null)}
                    className="hidden"
                  />
                </label>
                {paymentProofFile && (
                  <span className="text-emerald-700 text-xs font-semibold flex items-center gap-1">
                    <FileCheck className="w-4 h-4" /> Attached
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Order Summary */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-[#e8dfd1] p-6 shadow-sm space-y-6 h-fit sticky top-24">
          <h3 className="font-serif text-lg font-bold text-[#1a1815] uppercase tracking-wider pb-3 border-b border-[#e8dfd1]">
            ORDER SUMMARY
          </h3>

          <div className="max-h-60 overflow-y-auto space-y-3 pr-1">
            {cart.map((item) => (
              <div key={item.key} className="flex gap-3 text-xs font-sans">
                <img
                  src={item.product.images[0]}
                  alt={item.product.name}
                  className="w-14 h-16 object-cover rounded-md bg-stone-100 shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="font-serif font-bold text-stone-900 truncate">{item.product.name}</h4>
                  <p className="text-stone-500">Qty: {item.quantity} | {item.selectedSize}</p>
                  <span className="font-bold text-stone-900">
                    ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-2 text-xs font-sans border-t border-b border-[#e8dfd1] py-4">
            <div className="flex justify-between text-stone-600">
              <span>Items Subtotal</span>
              <span>₹{cartSubtotal.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>Delivery Fee</span>
              <span>{shippingFee === 0 ? 'FREE' : `₹${shippingFee}`}</span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>Luxury Gift Box</span>
              <span className="text-emerald-700 font-bold">Included</span>
            </div>
            <div className="flex justify-between font-serif font-bold text-lg text-[#1a1815] pt-3 border-t border-[#e8dfd1]">
              <span>Total Amount</span>
              <span>₹{totalAmount.toLocaleString('en-IN')}</span>
            </div>
          </div>

          {/* Terms & Conditions Checkbox */}
          <div className="space-y-1">
            <label
              htmlFor="checkout-terms"
              className={`flex items-start gap-2.5 cursor-pointer select-none font-sans text-xs ${
                termsError ? 'text-red-600' : 'text-stone-600'
              }`}
            >
              <input
                id="checkout-terms"
                type="checkbox"
                checked={acceptedTerms}
                onChange={(e) => {
                  setAcceptedTerms(e.target.checked);
                  if (e.target.checked) setTermsError(false);
                }}
                className="mt-0.5 w-4 h-4 rounded border-stone-400 accent-[#8c7355] cursor-pointer shrink-0"
              />
              <span>
                I have read and agree to the{' '}
                <Link
                  to="/terms-and-conditions"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#8c7355] font-semibold underline underline-offset-2 hover:text-[#1a1815] transition-colors"
                >
                  Terms &amp; Conditions
                </Link>
                {' '}of Navya Gift Hamper. I confirm that my details are accurate and I understand the order, payment, and return policies.
              </span>
            </label>
            {termsError && (
              <span className="flex items-center gap-1 text-[11px] text-red-600 font-sans pl-6">
                <AlertCircle className="w-3 h-3 shrink-0" />
                You must accept the Terms &amp; Conditions to proceed.
              </span>
            )}
          </div>

          <button
            type="submit"
            id="checkout-submit"
            disabled={isProcessing}
            className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest py-4 rounded-md shadow-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            {isProcessing ? (
              <span>Creating your order...</span>
            ) : (
              <>
                <span>PROCEED TO PAYMENT • ₹{totalAmount.toLocaleString('en-IN')}</span>
                <Lock className="w-4 h-4 text-[#c5a880]" />
              </>
            )}
          </button>
          <p className="text-[11px] text-stone-500 text-center font-sans">
            You will be redirected to the secure Google Pay / UPI page to complete payment.
          </p>
        </div>
      </form>
    </div>
  );
};
