import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowRight,
  Gift,
  Heart,
  ChevronRight,
  Tag
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useToast } from '../context/ToastContext';
import { useAuth } from '../context/AuthContext';
import { AuthPromptModal } from '../components/AuthPromptModal';

export const Cart = () => {
  const {
    cart,
    updateQuantity,
    removeFromCart,
    cartSubtotal,
    cartItemCount,
    includeGiftWrap,
    setIncludeGiftWrap
  } = useCart();
  const { toggleWishlist } = useWishlist();
  const { addToast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [coupon, setCoupon] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [appliedCoupon, setAppliedCoupon] = useState('');
  const [showAuthPrompt, setShowAuthPrompt] = useState(false);

  const handleProceedCheckout = () => {
    if (!user) {
      setShowAuthPrompt(true);
    } else {
      navigate('/checkout');
    }
  };

  const handleApplyCoupon = (e) => {
    e.preventDefault();
    if (coupon.trim().toUpperCase() === 'NAVYA10') {
      setDiscountPercent(10);
      setAppliedCoupon('NAVYA10 (10% OFF)');
      addToast('Coupon "NAVYA10" applied! 10% discount added.', 'success');
      setCoupon('');
    } else if (coupon.trim().toUpperCase() === 'FIRSTGIFT') {
      setDiscountPercent(15);
      setAppliedCoupon('FIRSTGIFT (15% OFF)');
      addToast('Welcome offer applied! 15% discount added.', 'success');
      setCoupon('');
    } else {
      addToast('Invalid coupon code. Try "NAVYA10"', 'error');
    }
  };

  const discountAmount = Math.round((cartSubtotal * discountPercent) / 100);
  const finalTotal = Math.max(0, cartSubtotal - discountAmount);

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center space-y-6">
        <div className="w-20 h-20 bg-[#f4efe6] rounded-full flex items-center justify-center text-[#8c7355] mx-auto">
          <ShoppingBag className="w-10 h-10 stroke-[1.5]" />
        </div>
        <div className="space-y-2">
          <h1 className="font-serif text-3xl font-bold text-[#1a1815]">
            YOUR GIFT BAG IS EMPTY
          </h1>
          <p className="font-serif italic text-[#8c7a65]">
            “Discover something beautiful for someone special.”
          </p>
        </div>
        <div className="pt-2">
          <Link
            to="/gifts"
            className="inline-flex items-center gap-2 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest px-8 py-4 rounded-md transition-colors shadow-lg"
          >
            <span>CONTINUE SHOPPING</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs text-stone-500 font-sans">
        <Link to="/" className="hover:text-black">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <span className="font-semibold text-[#1a1815]">Shopping Bag</span>
      </nav>

      <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#1a1815] uppercase tracking-wide">
        YOUR GIFT BAG ({cartItemCount})
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Items List */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white rounded-xl border border-[#e8dfd1] shadow-xs divide-y divide-[#eee6d8]">
            {cart.map((item) => (
              <div key={item.key} className="p-4 sm:p-6 flex flex-col sm:flex-row gap-5">
                <img
                  src={item.product.images[0]}
                  alt={item.product.name}
                  className="w-24 h-28 sm:w-28 sm:h-32 object-cover rounded-lg bg-stone-100 shrink-0"
                  referrerPolicy="no-referrer"
                />

                <div className="flex-1 flex flex-col justify-between space-y-2">
                  <div>
                    <div className="flex justify-between items-start">
                      <Link
                        to={`/product/${item.product.id}`}
                        className="font-serif text-base sm:text-lg font-bold text-[#1a1815] hover:text-[#8c7355] transition-colors"
                      >
                        {item.product.name}
                      </Link>
                      <button
                        onClick={() => removeFromCart(item.key)}
                        className="text-stone-400 hover:text-rose-600 transition-colors p-1"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-xs text-stone-500 font-sans">
                      Category: {item.product.subcategory || item.product.category}
                    </p>
                    <p className="text-xs text-stone-500 font-sans">
                      Edition: {item.selectedSize}
                    </p>
                    {item.giftNote && (
                      <p className="text-xs text-[#8c7355] italic mt-1 font-serif">
                        Gift note: "{item.giftNote}"
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-[#f4efe6]">
                    <div className="flex items-center gap-4">
                      {/* Quantity Selector */}
                      <div className="flex items-center border border-[#d8cbb8] rounded-md bg-[#faf8f5]">
                        <button
                          onClick={() => updateQuantity(item.key, item.quantity - 1)}
                          className="p-1.5 text-stone-600 hover:text-black"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-3 text-xs font-bold font-sans text-[#1a1815]">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.key, item.quantity + 1)}
                          className="p-1.5 text-stone-600 hover:text-black"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Save to Wishlist */}
                      <button
                        onClick={() => toggleWishlist(item.product)}
                        className="text-xs text-stone-500 hover:text-[#8c7355] flex items-center gap-1 font-sans"
                      >
                        <Heart className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Save for later</span>
                      </button>
                    </div>

                    <span className="font-sans font-bold text-base text-[#1a1815]">
                      ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Complimentary Packaging Option */}
          <div className="bg-[#f5f0e6] rounded-xl p-5 border border-[#e5dccb] flex items-center gap-4">
            <Gift className="w-8 h-8 text-[#8c7355] shrink-0" />
            <div className="flex-1">
              <h4 className="font-serif font-bold text-sm text-[#1a1815]">
                Complimentary Navya Gift Packaging & Ribbon
              </h4>
              <p className="text-xs text-stone-600 font-sans">
                Every hamper is packed in our signature rigid luxury box with satin ribbon and personalized gift card.
              </p>
            </div>
            <label className="flex items-center gap-2 cursor-pointer font-sans text-xs font-bold text-[#1a1815]">
              <input
                type="checkbox"
                checked={includeGiftWrap}
                onChange={(e) => setIncludeGiftWrap(e.target.checked)}
                className="accent-[#8c7355] w-4 h-4 rounded-xs"
              />
              <span>Include</span>
            </label>
          </div>
        </div>

        {/* Order Summary Sidebar */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-[#e8dfd1] p-6 shadow-sm space-y-6">
          <h3 className="font-serif text-lg font-bold text-[#1a1815] uppercase tracking-wider pb-3 border-b border-[#e8dfd1]">
            ORDER SUMMARY
          </h3>

          {/* Coupon Code Input */}
          <form onSubmit={handleApplyCoupon} className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-700">
              Promo Code / Coupon
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={coupon}
                onChange={(e) => setCoupon(e.target.value)}
                placeholder="Try 'NAVYA10'"
                className="w-full bg-[#faf8f5] text-xs px-3 py-2.5 rounded-md border border-[#e8dfd1] uppercase focus:outline-none focus:border-[#8c7355]"
              />
              <button
                type="submit"
                className="bg-[#1a1815] text-white text-xs uppercase font-bold px-4 py-2.5 rounded-md hover:bg-[#8c7355] transition-colors"
              >
                Apply
              </button>
            </div>
            {appliedCoupon && (
              <p className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
                <Tag className="w-3.5 h-3.5" />
                <span>Applied: {appliedCoupon}</span>
              </p>
            )}
          </form>

          {/* Calculation */}
          <div className="space-y-3 text-xs font-sans border-t border-b border-[#e8dfd1] py-4">
            <div className="flex justify-between text-stone-600">
              <span>Subtotal ({cartItemCount} items)</span>
              <span>₹{cartSubtotal.toLocaleString('en-IN')}</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-700 font-semibold">
                <span>Coupon Discount</span>
                <span>- ₹{discountAmount.toLocaleString('en-IN')}</span>
              </div>
            )}
            <div className="flex justify-between text-stone-600">
              <span>Pan-India Shipping</span>
              <span className="text-emerald-700 font-bold">FREE</span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>Gift Box & Packaging</span>
              <span className="text-emerald-700 font-bold">FREE</span>
            </div>
            <div className="flex justify-between font-serif font-bold text-lg text-[#1a1815] pt-3 border-t border-[#e8dfd1]">
              <span>Total Payable</span>
              <span>₹{finalTotal.toLocaleString('en-IN')}</span>
            </div>
          </div>

          <button
            onClick={handleProceedCheckout}
            className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-bold tracking-widest py-4 rounded-md shadow-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>PROCEED TO CHECKOUT</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <AuthPromptModal
        isOpen={showAuthPrompt}
        onClose={() => setShowAuthPrompt(false)}
        returnTo="/checkout"
      />
    </div>
  );
};
