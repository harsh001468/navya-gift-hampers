import React, { useState, useEffect } from 'react';
import {
  Plus,
  Edit3,
  Trash2,
  Power,
  RefreshCw,
  Tags,
  X,
  AlertTriangle
} from 'lucide-react';
import { adminService } from '../../services/adminService';
import { useToast } from '../../context/ToastContext';

export const AdminCategories = () => {
  const { addToast } = useToast();
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  // Modal states
  const [modalOpen, setModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [categoryForm, setCategoryForm] = useState({
    name: '',
    description: '',
    image: '',
    is_active: true
  });
  const [deleteModal, setDeleteModal] = useState({ open: false, category: null });
  const [saving, setSaving] = useState(false);

  const loadCategories = async () => {
    try {
      setLoading(true);
      const data = await adminService.getAllCategories();
      setCategories(data || []);
    } catch (err) {
      console.error('Error loading categories:', err);
      addToast('Failed to load categories', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCategories();
  }, []);

  const openAddModal = () => {
    setEditingCategory(null);
    setCategoryForm({
      name: '',
      description: '',
      image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&q=80',
      is_active: true
    });
    setModalOpen(true);
  };

  const openEditModal = (cat) => {
    setEditingCategory(cat);
    setCategoryForm({
      name: cat.name || '',
      description: cat.description || '',
      image: cat.image || '',
      is_active: cat.is_active !== false
    });
    setModalOpen(true);
  };

  const handleSaveCategory = async (e) => {
    e.preventDefault();
    if (!categoryForm.name.trim()) {
      addToast('Category name is required.', 'error');
      return;
    }

    try {
      setSaving(true);
      if (editingCategory) {
        const res = await adminService.updateCategory(editingCategory.id, categoryForm);
        if (res.success) {
          addToast(`Category "${categoryForm.name}" updated.`, 'success');
          setModalOpen(false);
          loadCategories();
        } else {
          addToast(res.error || 'Failed to update category', 'error');
        }
      } else {
        const res = await adminService.createCategory(categoryForm);
        if (res.success) {
          addToast(`Category "${categoryForm.name}" created successfully.`, 'success');
          setModalOpen(false);
          loadCategories();
        } else {
          addToast(res.error || 'Failed to create category', 'error');
        }
      }
    } catch (err) {
      addToast(err.message || 'Error saving category', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleActive = async (cat) => {
    try {
      const res = await adminService.updateCategory(cat.id, { is_active: !cat.is_active });
      if (res.success) {
        addToast(`Category ${!cat.is_active ? 'enabled' : 'disabled'}.`, 'info');
        setCategories((prev) =>
          prev.map((c) => (c.id === cat.id ? { ...c, is_active: !cat.is_active } : c))
        );
      } else {
        addToast(res.error || 'Failed to toggle status', 'error');
      }
    } catch (err) {
      addToast(err.message, 'error');
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteModal.category) return;
    try {
      setSaving(true);
      const res = await adminService.deleteCategory(deleteModal.category.id);
      if (res.success) {
        addToast('Category deleted successfully.', 'success');
        setCategories((prev) => prev.filter((c) => c.id !== deleteModal.category.id));
        setDeleteModal({ open: false, category: null });
      } else {
        addToast(res.error || 'Failed to delete category', 'error');
      }
    } catch (err) {
      addToast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* ─── HEADER BAR ────────────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#1a1815]">Categories</h2>
          <p className="text-xs text-[#7a6f64] mt-0.5">
            Organize gift hampers into curated collections and festive categories.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={loadCategories}
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-[#e8dfd1] text-xs text-[#4a423b] hover:text-[#1a1815] hover:bg-[#faf8f5] transition-colors"
            title="Refresh Categories"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#8c7355]' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            onClick={openAddModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium rounded-xl transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Add Category</span>
          </button>
        </div>
      </div>

      {/* ─── CATEGORIES GRID ───────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          [...Array(6)].map((_, i) => (
            <div key={i} className="h-44 bg-white border border-[#e8dfd1] rounded-2xl animate-pulse" />
          ))
        ) : categories.length === 0 ? (
          <div className="col-span-full py-16 text-center text-[#7a6f64] bg-white border border-[#e8dfd1] rounded-2xl">
            <Tags className="w-8 h-8 mx-auto text-[#c5a880] mb-2 opacity-50" />
            <p className="font-medium text-[#1a1815]">No categories defined yet</p>
            <p className="text-xs text-[#7a6f64] mt-0.5">
              Click "Add Category" above to create your first collection.
            </p>
          </div>
        ) : (
          categories.map((cat) => (
            <div
              key={cat.id}
              className={`rounded-2xl border p-5 transition-all flex flex-col justify-between ${
                cat.is_active
                  ? 'bg-white border-[#e8dfd1] shadow-sm hover:border-[#c5a880]'
                  : 'bg-[#faf8f5] border-[#e8dfd1] opacity-60'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={cat.image || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&q=80'}
                      alt={cat.name}
                      className="w-11 h-11 rounded-xl object-cover border border-[#e8dfd1] bg-[#faf8f5] shrink-0"
                      onError={(e) => {
                        e.currentTarget.src =
                          'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&q=80';
                      }}
                    />
                    <div>
                      <h3 className="font-serif text-base font-bold text-[#1a1815]">
                        {cat.name}
                      </h3>
                      <span className="text-[10px] font-mono text-[#7a6f64] block">
                        /{cat.slug}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                      cat.is_active
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : 'bg-stone-100 text-[#7a6f64] border-[#e8dfd1]'
                    }`}
                  >
                    {cat.is_active ? 'Active' : 'Disabled'}
                  </span>
                </div>

                <p className="text-[#7a6f64] text-xs line-clamp-2 leading-relaxed mb-4">
                  {cat.description || 'Curated luxury hampers collection for special gifting moments.'}
                </p>
              </div>

              {/* Actions Footer */}
              <div className="pt-3 border-t border-[#f0e9df] flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => handleToggleActive(cat)}
                  className={`inline-flex items-center gap-1.5 text-[11px] font-mono transition-colors ${
                    cat.is_active
                      ? 'text-[#7a6f64] hover:text-rose-600'
                      : 'text-[#7a6f64] hover:text-emerald-700'
                  }`}
                  title={cat.is_active ? 'Click to disable' : 'Click to enable'}
                >
                  <Power className="w-3.5 h-3.5" />
                  <span>{cat.is_active ? 'Disable' : 'Enable'}</span>
                </button>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => openEditModal(cat)}
                    className="p-1.5 rounded-lg text-[#7a6f64] hover:text-[#1a1815] hover:bg-[#faf8f5] transition-colors"
                    title="Edit category"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeleteModal({ open: true, category: cat })}
                    className="p-1.5 rounded-lg text-[#7a6f64] hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Delete category"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* ─── ADD / EDIT CATEGORY MODAL ────────────────────────────────────── */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className="bg-white border border-[#e8dfd1] rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#e8dfd1]">
              <div className="flex items-center gap-2">
                <Tags className="w-4 h-4 text-[#8c7355]" />
                <h3 className="font-serif text-lg text-[#1a1815] font-semibold">
                  {editingCategory ? 'Edit Category' : 'Create Category'}
                </h3>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="text-[#7a6f64] hover:text-[#1a1815]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCategory} className="space-y-4">
              <div>
                <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                  Category Name *
                </label>
                <input
                  type="text"
                  required
                  value={categoryForm.name}
                  onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                  placeholder="e.g. Wedding Hampers, Corporate Gifts"
                  className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={categoryForm.description}
                  onChange={(e) => setCategoryForm({ ...categoryForm, description: e.target.value })}
                  placeholder="Short tagline or description for collection cards..."
                  className="w-full bg-white border border-[#e8dfd1] rounded-xl p-3 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                  Cover Image URL
                </label>
                <input
                  type="url"
                  value={categoryForm.image}
                  onChange={(e) => setCategoryForm({ ...categoryForm, image: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="cat_active"
                  checked={categoryForm.is_active}
                  onChange={(e) => setCategoryForm({ ...categoryForm, is_active: e.target.checked })}
                  className="rounded border-[#e8dfd1] text-[#8c7355] focus:ring-0"
                />
                <label htmlFor="cat_active" className="text-xs text-[#4a423b] cursor-pointer">
                  Category is Active & Visible in Navigation
                </label>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-[#e8dfd1]">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] text-[#4a423b] text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 rounded-xl bg-[#1a1815] hover:bg-[#8c7355] text-white font-medium text-xs transition-colors"
                >
                  {saving ? 'Saving...' : editingCategory ? 'Save Changes' : 'Create Category'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ─── DELETE CONFIRMATION MODAL ────────────────────────────────────── */}
      {deleteModal.open && deleteModal.category && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className="bg-white border border-[#e8dfd1] rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-xl">
            <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>

            <div>
              <h3 className="font-serif text-lg text-[#1a1815] font-semibold">
                Delete Category
              </h3>
              <p className="text-xs text-[#7a6f64] mt-1 leading-relaxed">
                Are you sure you want to remove the category <strong className="text-[#1a1815]">"{deleteModal.category.name}"</strong>? Products in this category will become uncategorized.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteModal({ open: false, category: null })}
                className="px-3.5 py-1.5 rounded-xl bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] text-[#4a423b] text-xs font-medium"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={saving}
                className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-medium tracking-wide disabled:opacity-50"
              >
                {saving ? 'Deleting...' : 'Delete Category'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
