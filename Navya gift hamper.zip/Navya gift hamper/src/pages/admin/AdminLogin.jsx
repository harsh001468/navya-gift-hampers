import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { Eye, EyeOff, Lock, Mail, Crown, ShieldAlert, ArrowRight, Loader2, Sparkles } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export const AdminLogin = () => {
  const { user, profile, isOwner, signIn, signOut, verifyOwner, loading: authLoading } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const returnTo = new URLSearchParams(location.search).get('returnTo') || '/admin/dashboard';

  // If already authenticated as the official owner (supportnavya0@gmail.com), redirect to dashboard
  useEffect(() => {
    if (!authLoading && user) {
      const isOfficialEmail = user.email?.toLowerCase().trim() === 'supportnavya0@gmail.com';
      if (isOfficialEmail && (profile?.role === 'owner' || isOwner)) {
        navigate('/admin/dashboard', { replace: true });
      }
    }
  }, [user, profile?.role, isOwner, authLoading, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage('');

    const inputEmail = email.trim().toLowerCase();

    if (!inputEmail || !password) {
      setErrorMessage('Please provide both email and password.');
      return;
    }

    try {
      setSubmitting(true);

      // 1. Authenticate user using InsForge Authentication
      const res = await signIn({ email: inputEmail, password });

      if (!res.success) {
        setErrorMessage(res.error?.message || 'Invalid email or password.');
        return;
      }

      // 2. Verify the authenticated email is strictly: supportnavya0@gmail.com
      const authEmail = (res.user?.email || user?.email || inputEmail).toLowerCase().trim();
      if (authEmail !== 'supportnavya0@gmail.com') {
        setErrorMessage('Access Denied: Only supportnavya0@gmail.com is authorized to access the Owner Admin Panel.');
        addToast('Access Denied: Only store owner can access admin portal.', 'error');
        // Clear session and redirect to customer website
        await signOut();
        navigate('/', { replace: true });
        return;
      }

      // 3. Verify that the user's role/authorization is 'owner'
      const confirmedOwner = await verifyOwner();
      if (!confirmedOwner) {
        setErrorMessage('Access Denied: Account does not have owner role authorization.');
        addToast('Access Denied: Owner role required.', 'error');
        // Clear session and redirect to customer website
        await signOut();
        navigate('/', { replace: true });
        return;
      }

      // 4. Only if both checks pass, allow access to: /admin/dashboard
      addToast('Owner authenticated successfully. Welcome to Navya Gift Hamper Dashboard.', 'success');
      navigate('/admin/dashboard', { replace: true });
    } catch (err) {
      console.error('Admin login error:', err);
      setErrorMessage(err.message || 'An unexpected error occurred during admin sign-in.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-950 flex flex-col justify-center items-center p-4 relative overflow-hidden antialiased">
      {/* Ambient background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-amber-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-amber-800/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-md w-full relative z-10">
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center text-stone-950 mx-auto shadow-2xl shadow-amber-950/50 mb-4 border border-amber-400/30">
            <Crown className="w-9 h-9" />
          </div>

          <h1 className="font-serif tracking-widest text-2xl font-bold uppercase text-stone-100">
            NAVYA GIFT HAMPER
          </h1>
          <div className="flex items-center justify-center gap-2 mt-1">
            <span className="h-px w-6 bg-amber-500/40" />
            <span className="text-[11px] font-mono tracking-widest uppercase text-amber-400 font-semibold">
              Owner Admin Portal
            </span>
            <span className="h-px w-6 bg-amber-500/40" />
          </div>
          <p className="text-stone-400 text-xs mt-2">
            Secure administrative login for store owner (<span className="text-amber-400/90 font-mono">supportnavya0@gmail.com</span>)
          </p>
        </div>

        {/* Card */}
        <div className="bg-stone-900/90 border border-stone-800/90 rounded-2xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl">
          {/* Error Message */}
          {errorMessage && (
            <div className="mb-6 p-4 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div className="leading-relaxed">{errorMessage}</div>
            </div>
          )}

          {user && (!isOwner || user.email?.toLowerCase().trim() !== 'supportnavya0@gmail.com') && (
            <div className="mb-6 p-4 rounded-xl bg-amber-950/30 border border-amber-800/50 text-amber-300 text-xs">
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-semibold">Logged in as customer</span>
                <span className="font-mono text-[10px] bg-stone-900 px-2 py-0.5 rounded text-stone-400">
                  {user.email}
                </span>
              </div>
              <p className="text-stone-400 mb-3">
                This account does not have owner privileges. Please log in with your store owner credentials.
              </p>
              <button
                type="button"
                onClick={() => signOut()}
                className="text-xs text-amber-400 underline hover:text-amber-300"
              >
                Sign out of current account
              </button>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email Field */}
            <div>
              <label className="block text-xs font-mono uppercase tracking-wider text-stone-400 mb-2">
                Owner Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-500">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="supportnavya0@gmail.com"
                  autoComplete="username"
                  className="w-full bg-stone-950/70 border border-stone-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-stone-100 placeholder-stone-600 focus:outline-none focus:border-amber-500/80 focus:ring-1 focus:ring-amber-500/50 transition-colors"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-xs font-mono uppercase tracking-wider text-stone-400">
                  Password
                </label>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  autoComplete="current-password"
                  className="w-full bg-stone-950/70 border border-stone-800 rounded-xl pl-10 pr-11 py-2.5 text-sm text-stone-100 placeholder-stone-600 focus:outline-none focus:border-amber-500/80 focus:ring-1 focus:ring-amber-500/50 transition-colors"
                />
                {/* Show / Hide Password Button */}
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-stone-500 hover:text-stone-300"
                  tabIndex={-1}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Login Button with Loading State */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-bold text-xs font-mono uppercase tracking-wider transition-all duration-200 shadow-lg shadow-amber-900/30 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-2"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <span>Login to Dashboard</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-5 border-t border-stone-800/80 flex items-center justify-between text-xs text-stone-500">
            <Link
              to="/"
              className="hover:text-amber-400 transition-colors flex items-center gap-1 font-sans"
            >
              ← Back to Customer Website
            </Link>
            <span className="font-mono text-[10px] text-amber-500/80">
              Owner: supportnavya0@gmail.com
            </span>
          </div>
        </div>

        {/* Security watermark */}
        <div className="text-center mt-6 text-[11px] text-stone-500 flex items-center justify-center gap-1.5 font-mono">
          <Sparkles className="w-3 h-3 text-amber-500/60" />
          <span>Navya Gift Hamper · Production InsForge Auth Security</span>
        </div>
      </div>
    </div>
  );
};
