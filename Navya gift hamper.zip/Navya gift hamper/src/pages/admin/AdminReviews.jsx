import React, { useState, useEffect } from 'react';
import {
  MessageSquare,
  Star,
  CheckCircle,
  XCircle,
  Trash2,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Check,
  X,
  AlertTriangle
} from 'lucide-react';
import { adminService } from '../../services/adminService';
import { useToast } from '../../context/ToastContext';

export const AdminReviews = () => {
  const { addToast } = useToast();
  const [reviews, setReviews] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const [statusFilter, setStatusFilter] = useState('all'); // 'all' | 'pending' | 'approved' | 'rejected'
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const [actionLoading, setActionLoading] = useState(false);
  const [deleteModal, setDeleteModal] = useState({ open: false, review: null });

  const loadReviews = async () => {
    try {
      setLoading(true);
      const res = await adminService.getReviews({
        status: statusFilter === 'all' ? '' : statusFilter,
        page,
        pageSize
      });
      setReviews(res.reviews || []);
      setTotalCount(res.total || 0);
    } catch (err) {
      console.error('Error loading reviews:', err);
      addToast('Failed to load reviews', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReviews();
  }, [statusFilter, page]);

  const handleUpdateStatus = async (reviewId, newStatus) => {
    try {
      setActionLoading(true);
      const res = await adminService.updateReviewStatus(reviewId, newStatus);
      if (res.success) {
        addToast(`Review marked as ${newStatus}.`, 'success');
        setReviews((prev) =>
          prev.map((r) => (r.id === reviewId ? { ...r, status: newStatus } : r))
        );
      } else {
        addToast(res.error || 'Failed to update review status', 'error');
      }
    } catch (err) {
      addToast(err.message, 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteModal.review) return;
    try {
      setActionLoading(true);
      const res = await adminService.deleteReview(deleteModal.review.id);
      if (res.success) {
        addToast('Review deleted permanently.', 'success');
        setReviews((prev) => prev.filter((r) => r.id !== deleteModal.review.id));
        setTotalCount((c) => Math.max(0, c - 1));
        setDeleteModal({ open: false, review: null });
      } else {
        addToast(res.error || 'Failed to delete review', 'error');
      }
    } catch (err) {
      addToast(err.message, 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const totalPages = Math.ceil(totalCount / pageSize) || 1;

  const renderStars = (rating) => {
    const num = Math.round(Number(rating) || 5);
    return (
      <div className="flex items-center gap-0.5 text-[#c5a880]">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`w-3.5 h-3.5 ${
              i < num ? 'fill-[#c5a880] text-[#c5a880]' : 'text-[#e8dfd1]'
            }`}
          />
        ))}
      </div>
    );
  };

  const getStatusBadge = (status) => {
    const s = (status || '').toLowerCase();
    if (s === 'approved') return 'bg-emerald-50 text-emerald-800 border-emerald-200';
    if (s === 'rejected') return 'bg-rose-50 text-rose-800 border-rose-200';
    return 'bg-amber-50 text-amber-800 border-amber-200';
  };

  return (
    <div className="space-y-6">
      {/* ─── HEADER BAR ────────────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#1a1815]">Reviews</h2>
          <p className="text-xs text-[#7a6f64] mt-0.5">
            Moderate customer feedback and testimonials across your gift collections.
          </p>
        </div>

        <button
          onClick={loadReviews}
          disabled={loading}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-[#e8dfd1] text-xs text-[#4a423b] hover:text-[#1a1815] hover:bg-[#faf8f5] transition-colors self-start sm:self-auto"
          title="Refresh Reviews"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#8c7355]' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* ─── STATUS FILTER TABS ────────────────────────────────────────────── */}
      <div className="flex items-center gap-1.5 bg-white border border-[#e8dfd1] rounded-2xl p-1.5 shadow-sm overflow-x-auto text-xs font-mono">
        {[
          { key: 'all', label: 'All Reviews' },
          { key: 'pending', label: 'Pending Moderation' },
          { key: 'approved', label: 'Approved' },
          { key: 'rejected', label: 'Rejected' }
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => {
              setStatusFilter(tab.key);
              setPage(1);
            }}
            className={`px-3.5 py-1.5 rounded-xl transition-colors font-medium ${
              statusFilter === tab.key
                ? 'bg-[#1a1815] text-white shadow-sm'
                : 'text-[#7a6f64] hover:text-[#1a1815] hover:bg-[#faf8f5]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* ─── REVIEWS LIST ──────────────────────────────────────────────────── */}
      <div className="space-y-3">
        {loading ? (
          [...Array(3)].map((_, i) => (
            <div key={i} className="h-32 bg-white border border-[#e8dfd1] rounded-2xl animate-pulse" />
          ))
        ) : reviews.length === 0 ? (
          <div className="py-16 text-center text-[#7a6f64] bg-white border border-[#e8dfd1] rounded-2xl shadow-sm">
            <MessageSquare className="w-8 h-8 mx-auto text-[#c5a880] mb-2 opacity-50" />
            <p className="font-medium text-[#1a1815]">No reviews in this view</p>
            <p className="text-xs text-[#7a6f64] mt-0.5">
              Customer reviews for your gift hampers will be displayed here for moderation.
            </p>
          </div>
        ) : (
          reviews.map((rev) => {
            const dateStr = rev.created_at
              ? new Date(rev.created_at).toLocaleDateString('en-IN', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric'
                })
              : 'Recent';

            const status = rev.status || 'approved';

            return (
              <div
                key={rev.id}
                className="p-5 rounded-2xl bg-white border border-[#e8dfd1] shadow-sm space-y-3 transition-colors hover:border-[#c5a880]"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#f0e9df] text-[#1a1815] font-serif font-bold text-xs flex items-center justify-center border border-[#e8dfd1]">
                      {rev.author_name ? rev.author_name.charAt(0).toUpperCase() : 'C'}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-[#1a1815] text-sm">
                          {rev.author_name}
                        </span>
                        {rev.is_verified_buyer && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                            <ShieldCheck className="w-3 h-3 text-emerald-600" />
                            Verified Buyer
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-[#7a6f64] font-mono">
                        {rev.author_location || 'Customer'} · {dateStr}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {renderStars(rev.rating)}
                    <span
                      className={`text-[10px] font-mono uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${getStatusBadge(
                        status
                      )}`}
                    >
                      {status}
                    </span>
                  </div>
                </div>

                {/* Product Tag */}
                <div className="text-xs font-mono text-[#8c7355] bg-[#faf8f5] border border-[#e8dfd1] px-3 py-1.5 rounded-xl inline-block">
                  Product: <strong className="text-[#1a1815]">{rev.product_name}</strong>
                </div>

                {/* Review Text */}
                <div className="space-y-1">
                  {rev.title && (
                    <h4 className="font-serif font-semibold text-[#1a1815] text-sm">
                      {rev.title}
                    </h4>
                  )}
                  <p className="text-[#4a423b] text-xs leading-relaxed">
                    "{rev.comment}"
                  </p>
                </div>

                {/* Actions Footer */}
                <div className="pt-3 border-t border-[#f0e9df] flex items-center justify-between text-xs font-mono">
                  <div className="text-[#7a6f64] text-[11px]">
                    ID: {rev.id.slice(0, 8)}
                  </div>

                  <div className="flex items-center gap-2">
                    {status !== 'approved' && (
                      <button
                        type="button"
                        onClick={() => handleUpdateStatus(rev.id, 'approved')}
                        disabled={actionLoading}
                        className="inline-flex items-center gap-1 px-3 py-1 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs transition-colors"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve</span>
                      </button>
                    )}

                    {status !== 'rejected' && (
                      <button
                        type="button"
                        onClick={() => handleUpdateStatus(rev.id, 'rejected')}
                        disabled={actionLoading}
                        className="inline-flex items-center gap-1 px-3 py-1 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 text-xs transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => setDeleteModal({ open: true, review: rev })}
                      disabled={actionLoading}
                      className="p-1 rounded-xl text-[#7a6f64] hover:text-rose-600 hover:bg-rose-50 transition-colors"
                      title="Delete review"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* ─── PAGINATION ────────────────────────────────────────────────────── */}
      <div className="p-3.5 bg-white border border-[#e8dfd1] rounded-2xl shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#7a6f64] font-mono">
        <div>
          Showing {reviews.length > 0 ? (page - 1) * pageSize + 1 : 0} to{' '}
          {Math.min(page * pageSize, totalCount)} of {totalCount} reviews
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
            className="px-2.5 py-1 rounded-lg bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] disabled:opacity-40 disabled:pointer-events-none flex items-center gap-1 text-[#4a423b]"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Previous</span>
          </button>
          <span className="px-2 text-[#1a1815] font-medium">
            {page} / {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            className="px-2.5 py-1 rounded-lg bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] disabled:opacity-40 disabled:pointer-events-none flex items-center gap-1 text-[#4a423b]"
          >
            <span>Next</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ─── DELETE CONFIRMATION DIALOG ───────────────────────────────────── */}
      {deleteModal.open && deleteModal.review && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className="bg-white border border-[#e8dfd1] rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-xl">
            <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>

            <div>
              <h3 className="font-serif text-lg text-[#1a1815] font-semibold">
                Delete Review
              </h3>
              <p className="text-xs text-[#7a6f64] mt-1 leading-relaxed">
                Are you sure you want to permanently delete this customer review from{' '}
                <strong className="text-[#1a1815]">{deleteModal.review.author_name}</strong>? This action cannot be undone.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteModal({ open: false, review: null })}
                className="px-3.5 py-1.5 rounded-xl bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] text-[#4a423b] text-xs font-medium"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={actionLoading}
                className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-medium tracking-wide disabled:opacity-50"
              >
                {actionLoading ? 'Deleting...' : 'Delete Review'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
