import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  ShoppingBag,
  Search,
  Eye,
  Truck,
  MapPin,
  Phone,
  Mail,
  User,
  CreditCard,
  X,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Calendar,
  CheckCircle2,
  Clock,
  Package,
  AlertCircle
} from 'lucide-react';
import { adminService } from '../../services/adminService';
import { useToast } from '../../context/ToastContext';

export const AdminOrders = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { addToast } = useToast();

  const [orders, setOrders] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState(searchParams.get('orderId') || searchParams.get('q') || '');
  const [status, setStatus] = useState(searchParams.get('status') || 'all');
  const [paymentStatus, setPaymentStatus] = useState(searchParams.get('payment') || 'all');
  const [dateRange, setDateRange] = useState('all'); // all, today, this_month
  const [page, setPage] = useState(1);
  const pageSize = 12;

  // Selected order for Details Modal
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [statusUpdating, setStatusUpdating] = useState(false);
  const [newTrackingNumber, setNewTrackingNumber] = useState('');

  const loadOrders = async () => {
    try {
      setLoading(true);
      const res = await adminService.getOrders({
        search,
        status,
        paymentStatus,
        page,
        pageSize
      });
      let fetched = res.orders || [];

      // Filter date range client-side if selected
      if (dateRange === 'today') {
        const todayStr = new Date().toISOString().split('T')[0];
        fetched = fetched.filter(
          (o) => o.created_at && o.created_at.startsWith(todayStr)
        );
      } else if (dateRange === 'this_month') {
        const monthPrefix = new Date().toISOString().slice(0, 7);
        fetched = fetched.filter(
          (o) => o.created_at && o.created_at.startsWith(monthPrefix)
        );
      }

      setOrders(fetched);
      setTotalCount(res.total || 0);

      // Auto-open order details if query param orderId is specified
      const targetId = searchParams.get('orderId');
      if (targetId && fetched.length > 0) {
        const found = fetched.find(
          (o) => o.order_number === targetId || o.id === targetId
        );
        if (found) {
          setSelectedOrder(found);
          setNewTrackingNumber(found.tracking_number || '');
          setDetailsModalOpen(true);
        }
      }
    } catch (err) {
      console.error('Error loading orders:', err);
      addToast('Failed to load orders', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, [status, paymentStatus, dateRange, page]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setPage(1);
    loadOrders();
  };

  const handleOpenDetails = (order) => {
    setSelectedOrder(order);
    setNewTrackingNumber(order.tracking_number || '');
    setDetailsModalOpen(true);
  };

  const handleUpdateStatus = async (newStatus) => {
    if (!selectedOrder) return;
    try {
      setStatusUpdating(true);
      const res = await adminService.updateOrderStatus(
        selectedOrder.id,
        newStatus,
        newTrackingNumber
      );
      if (res.success) {
        addToast(`Order status updated to "${newStatus}".`, 'success');
        setSelectedOrder((prev) => ({
          ...prev,
          status: newStatus,
          tracking_number: newTrackingNumber || prev.tracking_number
        }));
        setOrders((prev) =>
          prev.map((o) =>
            o.id === selectedOrder.id
              ? {
                  ...o,
                  status: newStatus,
                  tracking_number: newTrackingNumber || o.tracking_number
                }
              : o
          )
        );
      } else {
        addToast(res.error || 'Failed to update order status', 'error');
      }
    } catch (err) {
      addToast(err.message, 'error');
    } finally {
      setStatusUpdating(false);
    }
  };

  const handleUpdatePaymentStatus = async (newPaymentStatus) => {
    if (!selectedOrder) return;
    try {
      setStatusUpdating(true);
      const res = await adminService.updateOrderPaymentStatus(
        selectedOrder.id,
        newPaymentStatus
      );
      if (res.success) {
        addToast(`Payment marked as "${newPaymentStatus}".`, 'success');
        setSelectedOrder((prev) => ({
          ...prev,
          payment_status: newPaymentStatus
        }));
        setOrders((prev) =>
          prev.map((o) =>
            o.id === selectedOrder.id ? { ...o, payment_status: newPaymentStatus } : o
          )
        );
      } else {
        addToast(res.error || 'Failed to update payment status', 'error');
      }
    } catch (err) {
      addToast(err.message, 'error');
    } finally {
      setStatusUpdating(false);
    }
  };

  const formatINR = (num) =>
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(num || 0);

  // Exact 6-stage operational timeline specified in instructions
  const timelineStages = [
    'Order placed',
    'Confirmed',
    'Processing',
    'Packed',
    'Shipped',
    'Delivered'
  ];

  const getStageIndex = (currentStatus) => {
    const s = (currentStatus || '').toLowerCase();
    if (s.includes('place') || s === 'pending') return 0;
    if (s.includes('confirm')) return 1;
    if (s.includes('process')) return 2;
    if (s.includes('pack')) return 3;
    if (s.includes('ship') || s.includes('out for delivery')) return 4;
    if (s.includes('deliver')) return 5;
    return 0;
  };

  const totalPages = Math.ceil(totalCount / pageSize) || 1;

  const getStatusBadge = (statusVal) => {
    const s = (statusVal || '').toLowerCase();
    if (s.includes('deliver')) return 'bg-emerald-50 text-emerald-800 border-emerald-200';
    if (s.includes('ship') || s.includes('out for delivery')) return 'bg-purple-50 text-purple-800 border-purple-200';
    if (s.includes('process') || s.includes('confirm') || s.includes('pack')) return 'bg-blue-50 text-blue-800 border-blue-200';
    if (s.includes('cancel')) return 'bg-rose-50 text-rose-800 border-rose-200';
    return 'bg-amber-50 text-amber-800 border-amber-200';
  };

  const getPaymentBadge = (payVal) => {
    const p = (payVal || '').toLowerCase();
    if (p === 'paid') return 'bg-emerald-50 text-emerald-800 border-emerald-200';
    if (p === 'failed') return 'bg-rose-50 text-rose-800 border-rose-200';
    return 'bg-amber-50 text-amber-800 border-amber-200';
  };

  return (
    <div className="space-y-6">
      {/* ─── PAGE HEADER ────────────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#1a1815]">Orders</h2>
          <p className="text-xs text-[#7a6f64] mt-0.5">Manage and track customer orders.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={loadOrders}
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-[#e8dfd1] text-xs text-[#4a423b] hover:text-[#1a1815] hover:bg-[#faf8f5] transition-colors"
            title="Refresh Orders"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#8c7355]' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* ─── FILTERS BAR ────────────────────────────────────────────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-2xl p-4 shadow-sm">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search */}
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 text-[#9c9184] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by order ID, customer name, email..."
              className="w-full pl-9 pr-8 py-2 rounded-xl border border-[#e8dfd1] bg-white text-xs text-[#1a1815] placeholder-[#9c9184] focus:outline-none focus:border-[#8c7355] transition-colors"
            />
            {search && (
              <button
                type="button"
                onClick={() => {
                  setSearch('');
                  setPage(1);
                }}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#9c9184] hover:text-[#1a1815]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Order Status */}
          <div>
            <select
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 rounded-xl border border-[#e8dfd1] bg-white text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] transition-colors"
            >
              <option value="all">All Order Statuses</option>
              {timelineStages.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          {/* Payment Status */}
          <div>
            <select
              value={paymentStatus}
              onChange={(e) => {
                setPaymentStatus(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 rounded-xl border border-[#e8dfd1] bg-white text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] transition-colors"
            >
              <option value="all">All Payments</option>
              <option value="paid">Paid</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
            </select>
          </div>

          {/* Date Range */}
          <div className="flex gap-2">
            <select
              value={dateRange}
              onChange={(e) => {
                setDateRange(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 rounded-xl border border-[#e8dfd1] bg-white text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] transition-colors"
            >
              <option value="all">All Dates</option>
              <option value="today">Today</option>
              <option value="this_month">This Month</option>
            </select>
            <button
              type="submit"
              className="px-3 py-2 bg-[#1a1815] hover:bg-[#8c7355] text-white rounded-xl text-xs font-medium transition-colors"
            >
              Filter
            </button>
          </div>
        </form>
      </div>

      {/* ─── ORDERS TABLE ──────────────────────────────────────────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#faf8f5] border-b border-[#e8dfd1] text-[11px] font-mono uppercase tracking-wider text-[#7a6f64]">
                <th className="py-3 px-4 font-semibold">Order ID</th>
                <th className="py-3 px-4 font-semibold">Customer</th>
                <th className="py-3 px-4 font-semibold">Items</th>
                <th className="py-3 px-4 font-semibold">Date</th>
                <th className="py-3 px-4 font-semibold">Amount</th>
                <th className="py-3 px-4 font-semibold">Payment</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f0e9df]">
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-[#7a6f64] font-mono">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto text-[#8c7355] mb-2" />
                    Loading orders...
                  </td>
                </tr>
              ) : orders.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-16 text-center text-[#7a6f64]">
                    <ShoppingBag className="w-8 h-8 mx-auto text-[#c5a880] mb-2 opacity-50" />
                    <p className="font-medium text-[#1a1815]">No orders found</p>
                    <p className="text-xs text-[#7a6f64] mt-0.5">
                      When customers place orders, they will appear here.
                    </p>
                  </td>
                </tr>
              ) : (
                orders.map((order) => {
                  const dateStr = order.created_at
                    ? new Date(order.created_at).toLocaleDateString('en-IN', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })
                    : '—';

                  const itemCount = order.items
                    ? order.items.reduce((s, i) => s + (i.quantity || 1), 0)
                    : 1;

                  return (
                    <tr
                      key={order.id}
                      onClick={() => handleOpenDetails(order)}
                      className="hover:bg-[#faf8f5]/80 cursor-pointer transition-colors"
                    >
                      <td className="py-3 px-4 font-mono font-medium text-[#1a1815]">
                        {order.order_number || order.id?.slice(0, 8)}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#1a1815]">
                          {order.customer_name || 'Customer'}
                        </div>
                        <div className="text-[11px] text-[#7a6f64] truncate max-w-[180px]">
                          {order.customer_email || order.customer_phone || ''}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-[#4a423b] font-mono">
                        {itemCount} {itemCount === 1 ? 'item' : 'items'}
                      </td>
                      <td className="py-3 px-4 text-[#7a6f64] font-mono">
                        {dateStr}
                      </td>
                      <td className="py-3 px-4 font-serif font-semibold text-[#1a1815]">
                        {formatINR(order.total_amount)}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-mono uppercase tracking-wider border ${getPaymentBadge(
                            order.payment_status
                          )}`}
                        >
                          {order.payment_status || 'Pending'}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-wider border ${getStatusBadge(
                            order.status
                          )}`}
                        >
                          {order.status || 'Pending'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => handleOpenDetails(order)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-[#e8dfd1] bg-white hover:bg-[#faf8f5] text-xs text-[#4a423b] hover:text-[#1a1815] transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="p-3.5 border-t border-[#e8dfd1] bg-[#faf8f5] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#7a6f64] font-mono">
          <div>
            Showing {orders.length > 0 ? (page - 1) * pageSize + 1 : 0} to{' '}
            {Math.min(page * pageSize, totalCount)} of {totalCount} orders
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-2.5 py-1 rounded-lg bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] disabled:opacity-40 disabled:pointer-events-none flex items-center gap-1 text-[#4a423b]"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>
            <span className="px-2 text-[#1a1815] font-medium">
              {page} / {totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="px-2.5 py-1 rounded-lg bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] disabled:opacity-40 disabled:pointer-events-none flex items-center gap-1 text-[#4a423b]"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* ─── ORDER DETAILS MODAL ───────────────────────────────────────────── */}
      {detailsModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-[2px] flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white border border-[#e8dfd1] rounded-2xl max-w-3xl w-full p-6 space-y-6 shadow-xl relative max-h-[92vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-4 border-b border-[#e8dfd1]">
              <div>
                <div className="flex items-center gap-3">
                  <h3 className="text-xl font-serif font-bold text-[#1a1815]">
                    Order {selectedOrder.order_number || selectedOrder.id?.slice(0, 8)}
                  </h3>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-mono border ${getStatusBadge(
                      selectedOrder.status
                    )}`}
                  >
                    {selectedOrder.status || 'Pending'}
                  </span>
                </div>
                <p className="text-xs text-[#7a6f64] font-mono mt-1">
                  Placed on {new Date(selectedOrder.created_at).toLocaleString('en-IN')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDetailsModalOpen(false)}
                className="p-1.5 rounded-lg text-[#7a6f64] hover:text-[#1a1815] hover:bg-[#faf8f5] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* ─── ORDER TIMELINE (EXACT SPECIFICATION) ────────────────────── */}
            <div className="p-4 bg-[#faf8f5] border border-[#e8dfd1] rounded-xl space-y-3">
              <span className="text-[11px] font-mono uppercase tracking-wider text-[#8c7355] font-semibold block">
                Order Timeline
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 pt-1">
                {timelineStages.map((stageName, idx) => {
                  const currentIdx = getStageIndex(selectedOrder.status);
                  const isCompleted = idx <= currentIdx;
                  const isCurrent = idx === currentIdx;

                  return (
                    <button
                      key={stageName}
                      type="button"
                      onClick={() => handleUpdateStatus(stageName)}
                      disabled={statusUpdating}
                      className={`flex flex-col items-center text-center p-2.5 rounded-xl border text-[11px] transition-all ${
                        isCurrent
                          ? 'bg-[#1a1815] text-white border-[#1a1815] shadow-sm'
                          : isCompleted
                          ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                          : 'bg-white text-[#7a6f64] border-[#e8dfd1] hover:border-[#8c7355] hover:text-[#1a1815]'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center mb-1 text-[10px] font-mono ${
                          isCurrent
                            ? 'bg-[#8c7355] text-white font-bold'
                            : isCompleted
                            ? 'bg-emerald-600 text-white font-bold'
                            : 'bg-[#faf8f5] text-[#7a6f64] border border-[#e8dfd1]'
                        }`}
                      >
                        {isCompleted ? '✓' : idx + 1}
                      </div>
                      <span className="font-medium leading-tight">{stageName}</span>
                    </button>
                  );
                })}
              </div>

              {/* Tracking input */}
              <div className="flex flex-col sm:flex-row items-center gap-2 pt-2 border-t border-[#e8dfd1]/60">
                <div className="flex-1 w-full flex items-center gap-2 bg-white border border-[#e8dfd1] rounded-xl px-3 py-1.5">
                  <Truck className="w-4 h-4 text-[#8c7355] shrink-0" />
                  <input
                    type="text"
                    value={newTrackingNumber}
                    onChange={(e) => setNewTrackingNumber(e.target.value)}
                    placeholder="Courier Tracking Number (e.g. DELHIVERY-129384)"
                    className="w-full bg-transparent text-xs text-[#1a1815] placeholder-[#9c9184] focus:outline-none font-mono"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => handleUpdateStatus(selectedOrder.status)}
                  disabled={statusUpdating}
                  className="w-full sm:w-auto px-4 py-2 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium rounded-xl transition-colors shrink-0"
                >
                  Save Tracking
                </button>
              </div>
            </div>

            {/* Customer & Shipping Address Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {/* Customer Info */}
              <div className="p-4 bg-white border border-[#e8dfd1] rounded-xl space-y-2">
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#8c7355] font-semibold flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5" />
                  <span>Customer Information</span>
                </span>
                <div className="pt-1 text-[#1a1815] font-medium text-sm">
                  {selectedOrder.customer_name || 'Guest Customer'}
                </div>
                <div className="flex items-center gap-2 text-[#4a423b]">
                  <Mail className="w-3.5 h-3.5 text-[#9c9184]" />
                  <span>{selectedOrder.customer_email || 'No email provided'}</span>
                </div>
                <div className="flex items-center gap-2 text-[#4a423b]">
                  <Phone className="w-3.5 h-3.5 text-[#9c9184]" />
                  <span>{selectedOrder.customer_phone || 'No phone provided'}</span>
                </div>
              </div>

              {/* Shipping Address */}
              <div className="p-4 bg-white border border-[#e8dfd1] rounded-xl space-y-2">
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#8c7355] font-semibold flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>Shipping Address</span>
                </span>
                {selectedOrder.shipping_address ? (
                  <div className="text-[#4a423b] leading-relaxed pt-1">
                    {typeof selectedOrder.shipping_address === 'object' ? (
                      <>
                        <div>
                          {selectedOrder.shipping_address.street ||
                            selectedOrder.shipping_address.address}
                        </div>
                        {selectedOrder.shipping_address.apartment && (
                          <div>{selectedOrder.shipping_address.apartment}</div>
                        )}
                        <div>
                          {selectedOrder.shipping_address.city},{' '}
                          {selectedOrder.shipping_address.state}{' '}
                          {selectedOrder.shipping_address.pincode}
                        </div>
                      </>
                    ) : (
                      <div>{String(selectedOrder.shipping_address)}</div>
                    )}
                  </div>
                ) : (
                  <div className="text-[#9c9184]">No shipping address provided</div>
                )}
                <div className="text-[11px] font-mono text-[#7a6f64] pt-1">
                  Delivery Method:{' '}
                  <strong className="text-[#1a1815]">
                    {selectedOrder.delivery_method || 'Standard Delivery'}
                  </strong>
                </div>
              </div>
            </div>

            {/* Payment Status Bar */}
            <div className="p-3.5 bg-[#faf8f5] border border-[#e8dfd1] rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5">
                <CreditCard className="w-4 h-4 text-[#8c7355]" />
                <div>
                  <span className="text-[#1a1815] font-medium">
                    Payment Method: {selectedOrder.payment_method || 'UPI / Online'}
                  </span>
                  {selectedOrder.transaction_id && (
                    <div className="text-[11px] font-mono text-[#7a6f64]">
                      Txn: {selectedOrder.transaction_id}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-[#7a6f64]">Payment Status:</span>
                <select
                  value={selectedOrder.payment_status || 'pending'}
                  onChange={(e) => handleUpdatePaymentStatus(e.target.value)}
                  disabled={statusUpdating}
                  className="bg-white border border-[#e8dfd1] rounded-lg px-2.5 py-1 text-xs font-medium text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
                >
                  <option value="pending">Pending</option>
                  <option value="paid">Paid</option>
                  <option value="failed">Failed</option>
                </select>
              </div>
            </div>

            {/* Products Table */}
            <div className="space-y-2">
              <span className="text-xs font-mono uppercase tracking-wider text-[#8c7355] font-semibold block">
                Products in Hamper Package
              </span>
              <div className="border border-[#e8dfd1] rounded-xl overflow-hidden bg-white">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#faf8f5] border-b border-[#e8dfd1] text-[10px] font-mono uppercase text-[#7a6f64]">
                      <th className="py-2.5 px-3">Product</th>
                      <th className="py-2.5 px-3">Options</th>
                      <th className="py-2.5 px-3">Quantity</th>
                      <th className="py-2.5 px-3">Price</th>
                      <th className="py-2.5 px-3 text-right">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#f0e9df]">
                    {selectedOrder.items && selectedOrder.items.length > 0 ? (
                      selectedOrder.items.map((it, idx) => (
                        <tr key={idx}>
                          <td className="py-2.5 px-3">
                            <div className="flex items-center gap-2.5">
                              {it.product_image && (
                                <img
                                  src={it.product_image}
                                  alt={it.product_name}
                                  className="w-9 h-9 rounded-lg object-cover border border-[#e8dfd1] shrink-0"
                                />
                              )}
                              <div>
                                <div className="font-medium text-[#1a1815]">
                                  {it.product_name || 'Gift Hamper'}
                                </div>
                                {it.gift_note && (
                                  <div className="text-[10px] text-[#8c7355] italic max-w-xs truncate">
                                    "{it.gift_note}"
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="py-2.5 px-3 font-mono text-[#7a6f64] text-[11px]">
                            {it.selected_size && it.selected_size !== 'Standard' && (
                              <span>{it.selected_size} </span>
                            )}
                            {it.selected_color && it.selected_color !== 'Default' && (
                              <span>{it.selected_color}</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-[#4a423b]">
                            {it.quantity}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-[#4a423b]">
                            {formatINR(it.price)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-serif font-semibold text-[#1a1815]">
                            {formatINR(Number(it.price) * (it.quantity || 1))}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="py-4 text-center text-[#7a6f64] font-mono">
                          Single Hamper Item recorded on order total.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Financial Breakdown (Subtotal, Discount, Delivery charge, Total) */}
            <div className="p-4 bg-[#faf8f5] border border-[#e8dfd1] rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-[#7a6f64] font-mono space-y-1 w-full sm:w-auto">
                <div className="flex justify-between sm:justify-start sm:gap-6">
                  <span>Subtotal:</span>
                  <span className="text-[#1a1815]">
                    {formatINR(selectedOrder.subtotal || selectedOrder.total_amount)}
                  </span>
                </div>
                {Number(selectedOrder.discount) > 0 && (
                  <div className="flex justify-between sm:justify-start sm:gap-6 text-emerald-700">
                    <span>Discount:</span>
                    <span>-{formatINR(selectedOrder.discount)}</span>
                  </div>
                )}
                <div className="flex justify-between sm:justify-start sm:gap-6">
                  <span>Delivery Charge:</span>
                  <span className="text-[#1a1815]">
                    {Number(selectedOrder.shipping_fee) > 0
                      ? formatINR(selectedOrder.shipping_fee)
                      : 'Free'}
                  </span>
                </div>
              </div>

              <div className="text-right w-full sm:w-auto border-t sm:border-t-0 pt-2 sm:pt-0 border-[#e8dfd1]">
                <span className="text-[11px] font-mono uppercase text-[#7a6f64] block">
                  Total
                </span>
                <div className="font-serif text-2xl font-bold text-[#1a1815]">
                  {formatINR(selectedOrder.total_amount)}
                </div>
              </div>
            </div>

            {/* Footer Close */}
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setDetailsModalOpen(false)}
                className="px-5 py-2 bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] text-[#1a1815] text-xs font-medium rounded-xl transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
