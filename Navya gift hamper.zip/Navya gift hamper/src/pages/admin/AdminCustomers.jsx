import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Eye,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  X,
  ShieldCheck,
  Mail,
  Phone,
  Calendar,
  ShoppingBag
} from 'lucide-react';
import { adminService } from '../../services/adminService';
import { useToast } from '../../context/ToastContext';

export const AdminCustomers = () => {
  const { addToast } = useToast();
  const [customers, setCustomers] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);

  // Search & Pagination
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const pageSize = 12;

  // Selected customer for history modal
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);

  const loadCustomers = async () => {
    try {
      setLoading(true);
      const res = await adminService.getCustomers({ search, page, pageSize });
      setCustomers(res.customers || []);
      setTotalCount(res.total || 0);
    } catch (err) {
      console.error('Error loading customers:', err);
      addToast('Failed to load customers', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, [page]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setPage(1);
    loadCustomers();
  };

  const handleViewCustomer = (cust) => {
    setSelectedCustomer(cust);
    setModalOpen(true);
  };

  const formatINR = (num) =>
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(num || 0);

  const totalPages = Math.ceil(totalCount / pageSize) || 1;

  return (
    <div className="space-y-6">
      {/* ─── HEADER BAR ────────────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#1a1815]">Customers</h2>
          <p className="text-xs text-[#7a6f64] mt-0.5">
            View customer details, contact records, and order history.
          </p>
        </div>

        <button
          onClick={loadCustomers}
          disabled={loading}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-[#e8dfd1] text-xs text-[#4a423b] hover:text-[#1a1815] hover:bg-[#faf8f5] transition-colors self-start sm:self-auto"
          title="Refresh Customer List"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#8c7355]' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* ─── SEARCH BAR ────────────────────────────────────────────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-2xl p-4 shadow-sm">
        <form onSubmit={handleSearchSubmit} className="flex gap-3">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 text-[#9c9184] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by customer name, email address, or phone number..."
              className="w-full pl-9 pr-8 py-2 rounded-xl border border-[#e8dfd1] bg-white text-xs text-[#1a1815] placeholder-[#9c9184] focus:outline-none focus:border-[#8c7355] transition-colors"
            />
            {search && (
              <button
                type="button"
                onClick={() => {
                  setSearch('');
                  setPage(1);
                }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9c9184] hover:text-[#1a1815]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium rounded-xl transition-colors shrink-0"
          >
            Search
          </button>
        </form>
      </div>

      {/* ─── CUSTOMERS TABLE ───────────────────────────────────────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#faf8f5] border-b border-[#e8dfd1] text-[11px] font-mono uppercase tracking-wider text-[#7a6f64]">
                <th className="py-3 px-4 font-semibold">Customer</th>
                <th className="py-3 px-4 font-semibold">Email</th>
                <th className="py-3 px-4 font-semibold">Phone</th>
                <th className="py-3 px-4 font-semibold">Orders</th>
                <th className="py-3 px-4 font-semibold">Total Spent</th>
                <th className="py-3 px-4 font-semibold">Joined</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f0e9df]">
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-[#7a6f64] font-mono">
                    <RefreshCw className="w-5 h-5 animate-spin mx-auto text-[#8c7355] mb-2" />
                    Loading customers...
                  </td>
                </tr>
              ) : customers.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-16 text-center text-[#7a6f64]">
                    <Users className="w-8 h-8 mx-auto text-[#c5a880] mb-2 opacity-50" />
                    <p className="font-medium text-[#1a1815]">No customers found</p>
                    <p className="text-xs text-[#7a6f64] mt-0.5">
                      Customers will appear here when accounts are registered or guest checkouts are made.
                    </p>
                  </td>
                </tr>
              ) : (
                customers.map((c) => {
                  const joined = c.createdAt
                    ? new Date(c.createdAt).toLocaleDateString('en-IN', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })
                    : '—';

                  const isStoreOwner = c.role === 'owner';

                  return (
                    <tr
                      key={c.id}
                      onClick={() => handleViewCustomer(c)}
                      className="hover:bg-[#faf8f5]/80 cursor-pointer transition-colors"
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-7 h-7 rounded-full bg-[#f0e9df] text-[#1a1815] font-serif font-bold text-xs flex items-center justify-center shrink-0 border border-[#e8dfd1]">
                            {c.name ? c.name.charAt(0).toUpperCase() : 'C'}
                          </div>
                          <div>
                            <span className="font-medium text-[#1a1815] block">
                              {c.name}
                            </span>
                            {isStoreOwner && (
                              <span className="text-[9px] font-mono text-[#8c7355] font-semibold uppercase tracking-wider">
                                Owner
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 text-[#4a423b] font-mono">
                        {c.email || '—'}
                      </td>

                      <td className="py-3 px-4 text-[#7a6f64] font-mono">
                        {c.phone || '—'}
                      </td>

                      <td className="py-3 px-4 font-mono text-[#1a1815]">
                        {c.orderCount} {c.orderCount === 1 ? 'order' : 'orders'}
                      </td>

                      <td className="py-3 px-4 font-serif font-semibold text-[#1a1815]">
                        {formatINR(c.totalSpending)}
                      </td>

                      <td className="py-3 px-4 font-mono text-[#7a6f64]">
                        {joined}
                      </td>

                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-mono uppercase tracking-wider border ${
                            isStoreOwner
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          }`}
                        >
                          {c.role === 'owner' ? 'Owner' : 'Active'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => handleViewCustomer(c)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-[#e8dfd1] bg-white hover:bg-[#faf8f5] text-xs text-[#4a423b] hover:text-[#1a1815] transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Details</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="p-3.5 border-t border-[#e8dfd1] bg-[#faf8f5] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#7a6f64] font-mono">
          <div>
            Showing {customers.length > 0 ? (page - 1) * pageSize + 1 : 0} to{' '}
            {Math.min(page * pageSize, totalCount)} of {totalCount} customers
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-2.5 py-1 rounded-lg bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] disabled:opacity-40 disabled:pointer-events-none flex items-center gap-1 text-[#4a423b]"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>
            <span className="px-2 text-[#1a1815] font-medium">
              {page} / {totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="px-2.5 py-1 rounded-lg bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] disabled:opacity-40 disabled:pointer-events-none flex items-center gap-1 text-[#4a423b]"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* ─── CUSTOMER DETAILS & ORDER HISTORY MODAL ───────────────────────── */}
      {modalOpen && selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className="bg-white border border-[#e8dfd1] rounded-2xl max-w-2xl w-full p-6 space-y-6 shadow-xl relative max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-start justify-between pb-4 border-b border-[#e8dfd1]">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-[#f0e9df] text-[#1a1815] font-serif font-bold text-base flex items-center justify-center border border-[#e8dfd1]">
                  {selectedCustomer.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-xl font-serif font-bold text-[#1a1815]">
                    {selectedCustomer.name}
                  </h3>
                  <div className="flex items-center gap-2 text-xs font-mono text-[#7a6f64] mt-0.5">
                    <span>{selectedCustomer.email}</span>
                    {selectedCustomer.phone && (
                      <>
                        <span>·</span>
                        <span>{selectedCustomer.phone}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 rounded-lg text-[#7a6f64] hover:text-[#1a1815] hover:bg-[#faf8f5] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-3 bg-[#faf8f5] border border-[#e8dfd1] rounded-xl">
                <span className="text-[10px] font-mono uppercase text-[#7a6f64] block mb-0.5">
                  Total Orders
                </span>
                <span className="font-serif text-lg font-bold text-[#1a1815]">
                  {selectedCustomer.orderCount}
                </span>
              </div>

              <div className="p-3 bg-[#faf8f5] border border-[#e8dfd1] rounded-xl">
                <span className="text-[10px] font-mono uppercase text-[#7a6f64] block mb-0.5">
                  Total Spent
                </span>
                <span className="font-serif text-lg font-bold text-[#8c7355]">
                  {formatINR(selectedCustomer.totalSpending)}
                </span>
              </div>

              <div className="p-3 bg-[#faf8f5] border border-[#e8dfd1] rounded-xl">
                <span className="text-[10px] font-mono uppercase text-[#7a6f64] block mb-0.5">
                  Avg. Order Value
                </span>
                <span className="font-serif text-lg font-bold text-[#1a1815]">
                  {selectedCustomer.orderCount > 0
                    ? formatINR(selectedCustomer.totalSpending / selectedCustomer.orderCount)
                    : formatINR(0)}
                </span>
              </div>
            </div>

            {/* Order History */}
            <div className="space-y-2">
              <h4 className="text-xs font-mono uppercase tracking-wider text-[#8c7355] font-semibold">
                Order History ({selectedCustomer.orders?.length || 0})
              </h4>

              <div className="border border-[#e8dfd1] rounded-xl overflow-hidden bg-white">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#faf8f5] border-b border-[#e8dfd1] text-[10px] font-mono uppercase text-[#7a6f64]">
                      <th className="py-2.5 px-3">Order Number</th>
                      <th className="py-2.5 px-3">Date</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3">Payment</th>
                      <th className="py-2.5 px-3 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#f0e9df]">
                    {selectedCustomer.orders && selectedCustomer.orders.length > 0 ? (
                      selectedCustomer.orders.map((ord) => (
                        <tr key={ord.id}>
                          <td className="py-2.5 px-3 font-mono font-medium text-[#1a1815]">
                            {ord.order_number || ord.id?.slice(0, 8)}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-[#7a6f64] text-[11px]">
                            {new Date(ord.created_at).toLocaleDateString('en-IN')}
                          </td>
                          <td className="py-2.5 px-3">
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-stone-100 text-[#4a423b] border border-[#e8dfd1]">
                              {ord.status || 'Pending'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 font-mono text-[11px] uppercase">
                            <span
                              className={
                                ord.payment_status === 'paid'
                                  ? 'text-emerald-700 font-medium'
                                  : 'text-amber-700 font-medium'
                              }
                            >
                              {ord.payment_status || 'pending'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-right font-serif font-semibold text-[#1a1815]">
                            {formatINR(ord.total_amount)}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="py-6 text-center text-[#7a6f64] font-mono">
                          No past orders placed by this customer yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Privacy Notice */}
            <div className="p-3 bg-[#faf8f5] border border-[#e8dfd1] rounded-xl flex items-center gap-2.5 text-[11px] text-[#7a6f64] font-mono">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                Protected Data · Passwords & sensitive credentials are encrypted and never exposed in the admin panel.
              </span>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="px-5 py-2 bg-white border border-[#e8dfd1] hover:bg-[#faf8f5] text-[#1a1815] text-xs font-medium rounded-xl transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
