import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  RotateCcw,
  RefreshCw,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Package,
  X,
  AlertCircle
} from 'lucide-react';
import { adminService } from '../../services/adminService';
import { useToast } from '../../context/ToastContext';

export const AdminProducts = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { addToast } = useToast();

  const [products, setProducts] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState(searchParams.get('q') || '');
  const [category, setCategory] = useState(searchParams.get('category') || 'all');
  const [statusFilter, setStatusFilter] = useState(searchParams.get('status') || 'active');
  const [stockFilter, setStockFilter] = useState(searchParams.get('stock') || 'all');
  const [page, setPage] = useState(1);
  const pageSize = 12;

  // Archive / Delete confirmation modal
  const [archiveModal, setArchiveModal] = useState({ open: false, product: null });
  const [actionLoading, setActionLoading] = useState(false);

  // Load products
  const loadProducts = async () => {
    try {
      setLoading(true);
      const res = await adminService.getProducts({
        search,
        category: category === 'all' ? '' : category,
        status: statusFilter,
        lowStock: stockFilter === 'low',
        page,
        pageSize
      });

      let items = res.products || [];
      if (stockFilter === 'out') {
        items = items.filter((p) => {
          const s = p.stock_quantity ?? (p.in_stock ? 20 : 0);
          return s <= 0 || p.in_stock === false;
        });
      }

      setProducts(items);
      setTotalCount(res.total || items.length);
    } catch (err) {
      console.error('Error loading products:', err);
      addToast('Something went wrong while loading products.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    adminService.getAllCategories().then((cats) => {
      setCategories(cats || []);
    });
  }, []);

  useEffect(() => {
    loadProducts();
  }, [category, statusFilter, stockFilter, page]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    setPage(1);
    loadProducts();
  };

  // Safe Archive Product
  const handleConfirmArchive = async () => {
    if (!archiveModal.product) return;
    try {
      setActionLoading(true);
      const res = await adminService.archiveProduct(archiveModal.product.id);
      if (res.success) {
        addToast('Product archived.', 'success');
        if (statusFilter === 'active') {
          setProducts((prev) => prev.filter((p) => p.id !== archiveModal.product.id));
          setTotalCount((c) => Math.max(0, c - 1));
        } else {
          setProducts((prev) =>
            prev.map((p) =>
              p.id === archiveModal.product.id
                ? { ...p, is_archived: true, status: 'archived', in_stock: false }
                : p
            )
          );
        }
        setArchiveModal({ open: false, product: null });
      } else {
        addToast(res.error || 'Failed to archive product', 'error');
      }
    } catch (e) {
      addToast(e.message || 'Operation failed', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Restore Product
  const handleRestoreProduct = async (product) => {
    try {
      setActionLoading(true);
      const res = await adminService.restoreProduct(product.id);
      if (res.success) {
        addToast('Product restored successfully.', 'success');
        if (statusFilter === 'archived') {
          setProducts((prev) => prev.filter((p) => p.id !== product.id));
          setTotalCount((c) => Math.max(0, c - 1));
        } else {
          setProducts((prev) =>
            prev.map((p) =>
              p.id === product.id
                ? { ...p, is_archived: false, status: 'active', in_stock: true }
                : p
            )
          );
        }
      } else {
        addToast(res.error || 'Failed to restore product', 'error');
      }
    } catch (e) {
      addToast(e.message, 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const totalPages = Math.ceil(totalCount / pageSize) || 1;

  const formatINR = (num) =>
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(num || 0);

  return (
    <div className="space-y-5">
      {/* ─── HEADER BAR ────────────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-[#e8dfd1]">
        <div>
          <h2 className="font-serif text-xl font-bold text-[#1a1815]">
            Products
          </h2>
          <p className="text-xs text-[#7a6f64] mt-0.5">
            Manage your gift collection and inventory.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={loadProducts}
            disabled={loading}
            className="p-2 rounded-md bg-white border border-[#e8dfd1] text-[#635340] hover:text-[#1a1815] hover:bg-[#faf8f5] transition-colors"
            title="Refresh product list"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <Link
            to="/admin/products/add"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium tracking-wide transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Product</span>
          </Link>
        </div>
      </div>

      {/* ─── FILTERS ROW ───────────────────────────────────────────────────── */}
      {/* Search products, Category filter, Status filter, Stock filter */}
      <div className="bg-white border border-[#e8dfd1] rounded-lg p-3 shadow-xs">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-2.5">
          {/* Search products */}
          <div className="md:col-span-2 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-400">
              <Search className="w-3.5 h-3.5" />
            </div>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search products by name or SKU..."
              className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md pl-9 pr-7 py-1.5 text-xs text-[#1a1815] placeholder-stone-400 focus:outline-none focus:border-[#8c7355] focus:bg-white transition-colors"
            />
            {search && (
              <button
                type="button"
                onClick={() => {
                  setSearch('');
                  setPage(1);
                }}
                className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-stone-400 hover:text-stone-600"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Category filter */}
          <div>
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setPage(1);
              }}
              className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-2.5 py-1.5 text-xs text-[#4a423b] focus:outline-none focus:border-[#8c7355] focus:bg-white"
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
              className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-2.5 py-1.5 text-xs text-[#4a423b] focus:outline-none focus:border-[#8c7355] focus:bg-white"
            >
              <option value="active">Active Only</option>
              <option value="archived">Archived</option>
              <option value="all">All Statuses</option>
            </select>
          </div>

          {/* Stock filter */}
          <div>
            <select
              value={stockFilter}
              onChange={(e) => {
                setStockFilter(e.target.value);
                setPage(1);
              }}
              className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-2.5 py-1.5 text-xs text-[#4a423b] focus:outline-none focus:border-[#8c7355] focus:bg-white"
            >
              <option value="all">All Stock</option>
              <option value="low">Low Stock (≤5)</option>
              <option value="out">Out of Stock (0)</option>
            </select>
          </div>
        </form>
      </div>

      {/* ─── PRODUCTS TABLE ────────────────────────────────────────────────── */}
      {/* Columns: Image | Product | Category | Price | Stock | Status | Updated | Actions */}
      <div className="bg-white border border-[#e8dfd1] rounded-lg overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#e8dfd1] text-[11px] font-mono uppercase tracking-wider text-[#7a6f64] bg-[#fbfaf8]">
                <th className="py-2.5 px-4 font-semibold w-16">Image</th>
                <th className="py-2.5 px-4 font-semibold">Product</th>
                <th className="py-2.5 px-4 font-semibold">Category</th>
                <th className="py-2.5 px-4 font-semibold">Price</th>
                <th className="py-2.5 px-4 font-semibold">Stock</th>
                <th className="py-2.5 px-4 font-semibold">Status</th>
                <th className="py-2.5 px-4 font-semibold">Updated</th>
                <th className="py-2.5 px-4 text-right font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f0e9df]">
              {loading ? (
                [...Array(6)].map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td className="py-3 px-4">
                      <div className="w-10 h-10 bg-stone-100 rounded" />
                    </td>
                    <td className="py-3 px-4">
                      <div className="h-3 w-40 bg-stone-100 rounded mb-1.5" />
                      <div className="h-2 w-20 bg-stone-100 rounded" />
                    </td>
                    <td className="py-3 px-4">
                      <div className="h-3 w-24 bg-stone-100 rounded" />
                    </td>
                    <td className="py-3 px-4">
                      <div className="h-3 w-16 bg-stone-100 rounded" />
                    </td>
                    <td className="py-3 px-4">
                      <div className="h-3 w-12 bg-stone-100 rounded" />
                    </td>
                    <td className="py-3 px-4">
                      <div className="h-4 w-14 bg-stone-100 rounded" />
                    </td>
                    <td className="py-3 px-4">
                      <div className="h-3 w-16 bg-stone-100 rounded" />
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="h-3 w-12 bg-stone-100 rounded ml-auto" />
                    </td>
                  </tr>
                ))
              ) : products.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-[#7a6f64]">
                    <Package className="w-7 h-7 mx-auto text-stone-300 mb-2" />
                    <p className="font-semibold text-stone-900 text-xs">No products found</p>
                    <p className="text-[11px] text-stone-500 mt-0.5">
                      Try changing your search filters or add a new gift hamper.
                    </p>
                  </td>
                </tr>
              ) : (
                products.map((p) => {
                  const stock =
                    p.stock_quantity !== undefined && p.stock_quantity !== null
                      ? Number(p.stock_quantity)
                      : (p.in_stock ? 20 : 0);

                  const isArchived = p.is_archived || p.status === 'archived';
                  const isLow = stock > 0 && stock <= 5;
                  const isOut = stock <= 0 || p.in_stock === false;

                  const updatedDate = p.updated_at || p.created_at
                    ? new Date(p.updated_at || p.created_at).toLocaleDateString('en-IN', {
                        month: 'short',
                        day: 'numeric'
                      })
                    : '—';

                  return (
                    <tr
                      key={p.id}
                      className={`hover:bg-[#fbfaf8] transition-colors ${
                        isArchived ? 'bg-stone-50/60 opacity-70' : ''
                      }`}
                    >
                      {/* 1. Image */}
                      <td className="py-3 px-4">
                        <img
                          src={
                            p.images?.[0] ||
                            'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&q=80'
                          }
                          alt={p.name}
                          className="w-10 h-10 rounded object-cover border border-[#e8dfd1] bg-stone-50 shrink-0"
                          onError={(e) => {
                            e.currentTarget.src =
                              'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&q=80';
                          }}
                        />
                      </td>

                      {/* 2. Product */}
                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-medium text-[#1a1815] truncate" title={p.name}>
                          {p.name}
                        </div>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          {p.sku && (
                            <span className="text-[10px] font-mono text-[#7a6f64]">
                              {p.sku}
                            </span>
                          )}
                          {p.is_featured && (
                            <span className="text-[9px] font-mono text-[#8c7355] bg-[#f5f0e6] px-1 rounded border border-[#e8dfd1]">
                              Featured
                            </span>
                          )}
                        </div>
                      </td>

                      {/* 3. Category */}
                      <td className="py-3 px-4 text-[#635340]">
                        <span>{p.category}</span>
                        {p.subcategory && p.subcategory !== p.category && (
                          <span className="block text-[10px] text-[#7a6f64]">
                            {p.subcategory}
                          </span>
                        )}
                      </td>

                      {/* 4. Price */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#1a1815]">
                          {formatINR(p.price)}
                        </div>
                        {p.original_price && p.original_price > p.price && (
                          <div className="text-[10px] text-[#7a6f64] line-through">
                            {formatINR(p.original_price)}
                          </div>
                        )}
                      </td>

                      {/* 5. Stock */}
                      <td className="py-3 px-4 font-mono">
                        <span
                          className={`inline-block px-1.5 py-0.5 rounded text-[11px] font-medium ${
                            isOut
                              ? 'bg-rose-50 text-rose-800 border border-rose-200'
                              : isLow
                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                              : 'text-[#1a1815]'
                          }`}
                        >
                          {stock} units
                        </span>
                      </td>

                      {/* 6. Status */}
                      <td className="py-3 px-4">
                        {isArchived ? (
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-medium bg-stone-100 text-stone-600 border border-stone-200">
                            Archived
                          </span>
                        ) : p.in_stock ? (
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-50 text-emerald-800 border border-emerald-200">
                            Active
                          </span>
                        ) : (
                          <span className="inline-block px-2 py-0.5 rounded text-[10px] font-medium bg-rose-50 text-rose-800 border border-rose-200">
                            Out of Stock
                          </span>
                        )}
                      </td>

                      {/* 7. Updated */}
                      <td className="py-3 px-4 text-[#7a6f64] font-mono text-[11px]">
                        {updatedDate}
                      </td>

                      {/* 8. Actions: Edit, Archive, Restore */}
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-2">
                          <Link
                            to={`/admin/products/edit/${p.id}`}
                            className="text-xs font-medium text-[#8c7355] hover:text-[#1a1815] underline"
                          >
                            Edit
                          </Link>

                          {isArchived ? (
                            <button
                              type="button"
                              onClick={() => handleRestoreProduct(p)}
                              disabled={actionLoading}
                              className="text-xs font-medium text-emerald-700 hover:text-emerald-900 underline"
                            >
                              Restore
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setArchiveModal({ open: true, product: p })}
                              className="text-xs font-medium text-rose-600 hover:text-rose-800 underline"
                            >
                              Archive
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="p-3 border-t border-[#e8dfd1] bg-[#fbfaf8] flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[#7a6f64] font-mono">
          <div>
            Showing {products.length > 0 ? (page - 1) * pageSize + 1 : 0} to{' '}
            {Math.min(page * pageSize, totalCount)} of {totalCount} products
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-2.5 py-1 rounded bg-white border border-[#e8dfd1] hover:bg-stone-50 disabled:opacity-40 disabled:pointer-events-none flex items-center gap-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>

            <span className="px-2 text-[#1a1815]">
              Page {page} of {totalPages}
            </span>

            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="px-2.5 py-1 rounded bg-white border border-[#e8dfd1] hover:bg-stone-50 disabled:opacity-40 disabled:pointer-events-none flex items-center gap-1"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* ─── ARCHIVE CONFIRMATION DIALOG ──────────────────────────────────── */}
      {archiveModal.open && archiveModal.product && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#e8dfd1] rounded-lg max-w-sm w-full p-5 space-y-4 shadow-xl">
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Are you sure you want to remove this product?
            </h3>
            <p className="text-xs text-[#7a6f64] leading-relaxed">
              "{archiveModal.product.name}" will be archived. It will immediately be hidden from the storefront, but historical order records linking to this hamper will be preserved.
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setArchiveModal({ open: false, product: null })}
                disabled={actionLoading}
                className="px-3.5 py-1.5 rounded-md border border-[#e8dfd1] text-xs font-medium text-[#4a423b] hover:bg-[#faf8f5]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmArchive}
                disabled={actionLoading}
                className="px-3.5 py-1.5 rounded-md bg-rose-700 hover:bg-rose-800 text-white text-xs font-medium tracking-wide shadow-xs disabled:opacity-50"
              >
                {actionLoading ? 'Archiving...' : 'Archive Product'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
