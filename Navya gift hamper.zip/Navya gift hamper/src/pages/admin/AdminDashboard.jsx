import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ShoppingBag,
  Gift,
  Users,
  IndianRupee,
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  RefreshCw,
  ExternalLink,
  CheckCircle2,
  Package,
  Clock
} from 'lucide-react';
import { adminService } from '../../services/adminService';

export const AdminDashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [data, setData] = useState({
    stats: {
      totalOrders: 0,
      pendingOrders: 0,
      processingOrders: 0,
      deliveredOrders: 0,
      totalProducts: 0,
      totalCustomers: 0,
      totalRevenue: 0,
      lowStockThreshold: 5
    },
    recentOrders: [],
    lowStockProducts: [],
    salesTrends: { last7Days: [], last30Days: [], last6Months: [] }
  });
  const [chartRange, setChartRange] = useState('7d'); // '7d' | '30d' | '6m'

  const fetchDashboardData = async () => {
    try {
      setRefreshing(true);
      const res = await adminService.getDashboardMetrics();
      if (res.success) {
        setData(res);
      }
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const formatINR = (num) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(num || 0);
  };

  const getActiveTrendData = () => {
    if (chartRange === '30d') return data.salesTrends.last30Days || [];
    if (chartRange === '6m') return data.salesTrends.last6Months || [];
    return data.salesTrends.last7Days || [];
  };

  const trendData = getActiveTrendData();
  const maxRevenue = Math.max(...trendData.map((d) => d.revenue || 0), 1000);

  // Status badge styling helper — subtle & dignified tones
  const getStatusBadge = (status) => {
    const s = (status || '').toLowerCase();
    if (s === 'delivered') {
      return 'bg-emerald-50 text-emerald-800 border-emerald-200';
    }
    if (['processing', 'confirmed', 'packed'].includes(s)) {
      return 'bg-sky-50 text-sky-800 border-sky-200';
    }
    if (['shipped', 'out for delivery'].includes(s)) {
      return 'bg-amber-50 text-amber-900 border-amber-200';
    }
    if (s === 'cancelled') {
      return 'bg-stone-100 text-stone-600 border-stone-200';
    }
    return 'bg-amber-50 text-amber-800 border-amber-200';
  };

  const getPaymentBadge = (paymentStatus) => {
    const p = (paymentStatus || '').toLowerCase();
    if (p === 'paid') {
      return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    }
    if (p === 'failed') {
      return 'bg-rose-50 text-rose-700 border-rose-200';
    }
    return 'bg-stone-100 text-stone-600 border-stone-200';
  };

  if (loading) {
    return (
      <div className="space-y-6">
        {/* Skeleton Top Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white border border-[#e8dfd1] rounded-lg p-5 h-28 animate-pulse">
              <div className="h-3 w-20 bg-stone-100 rounded mb-3" />
              <div className="h-7 w-28 bg-stone-200 rounded mb-2" />
              <div className="h-3 w-36 bg-stone-100 rounded" />
            </div>
          ))}
        </div>
        {/* Skeleton Charts & Orders */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white border border-[#e8dfd1] rounded-lg p-6 h-80 animate-pulse" />
          <div className="bg-white border border-[#e8dfd1] rounded-lg p-6 h-80 animate-pulse" />
        </div>
      </div>
    );
  }

  const { stats, recentOrders, lowStockProducts } = data;

  // Realistic Business Top Row: Total Sales, Orders, Customers, Products
  const topMetrics = [
    {
      label: 'Total Sales',
      value: formatINR(stats.totalRevenue),
      subtext: 'From verified customer payments',
      icon: IndianRupee
    },
    {
      label: 'Orders',
      value: stats.totalOrders,
      subtext: stats.pendingOrders > 0 ? `${stats.pendingOrders} awaiting fulfillment` : 'All orders processed',
      icon: ShoppingBag
    },
    {
      label: 'Customers',
      value: stats.totalCustomers,
      subtext: 'Registered accounts in store',
      icon: Users
    },
    {
      label: 'Products',
      value: stats.totalProducts,
      subtext: `${lowStockProducts.length} low stock items`,
      icon: Gift
    }
  ];

  return (
    <div className="space-y-6">
      {/* ─── 1. TOP METRICS ROW ───────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {topMetrics.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className="bg-white border border-[#e8dfd1] rounded-lg p-5 hover:border-[#c5a880] transition-colors shadow-xs"
            >
              <div className="flex items-center justify-between text-[#7a6f64] mb-2">
                <span className="text-[11px] font-mono uppercase tracking-wider font-medium">
                  {card.label}
                </span>
                <Icon className="w-4 h-4 text-[#8c7355]" strokeWidth={1.75} />
              </div>
              <div className="font-serif text-2xl font-bold text-[#1a1815] tracking-tight">
                {card.value}
              </div>
              <div className="text-xs text-[#7a6f64] mt-1.5 truncate">
                {card.subtext}
              </div>
            </div>
          );
        })}
      </div>

      {/* ─── 2. SALES OVERVIEW & LOW STOCK ────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sales Overview Chart (2 cols) */}
        <div className="lg:col-span-2 bg-white border border-[#e8dfd1] rounded-lg p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6">
            <div>
              <h3 className="font-serif text-base font-semibold text-[#1a1815]">
                Sales Overview
              </h3>
              <p className="text-xs text-[#7a6f64] mt-0.5">
                Aggregated revenue from completed customer transactions
              </p>
            </div>

            {/* Simple Range Toggles */}
            <div className="inline-flex items-center bg-[#f7f4ef] border border-[#e8dfd1] rounded-md p-0.5 text-xs font-mono">
              <button
                onClick={() => setChartRange('7d')}
                className={`px-3 py-1 rounded transition-colors ${
                  chartRange === '7d'
                    ? 'bg-white text-[#1a1815] font-semibold shadow-xs'
                    : 'text-[#635340] hover:text-[#1a1815]'
                }`}
              >
                7 Days
              </button>
              <button
                onClick={() => setChartRange('30d')}
                className={`px-3 py-1 rounded transition-colors ${
                  chartRange === '30d'
                    ? 'bg-white text-[#1a1815] font-semibold shadow-xs'
                    : 'text-[#635340] hover:text-[#1a1815]'
                }`}
              >
                30 Days
              </button>
              <button
                onClick={() => setChartRange('6m')}
                className={`px-3 py-1 rounded transition-colors ${
                  chartRange === '6m'
                    ? 'bg-white text-[#1a1815] font-semibold shadow-xs'
                    : 'text-[#635340] hover:text-[#1a1815]'
                }`}
              >
                6 Months
              </button>
            </div>
          </div>

          {/* Simple Readable Bar Chart */}
          <div className="h-52 w-full flex items-end gap-2 sm:gap-3 pt-4 border-b border-[#f0e9df] pb-2">
            {trendData.map((item, idx) => {
              const heightPercent = maxRevenue > 0 ? Math.round(((item.revenue || 0) / maxRevenue) * 100) : 0;
              const displayHeight = Math.max(heightPercent, 4);

              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-2 group h-full justify-end">
                  {/* Tooltip on hover */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity text-[10px] font-mono bg-[#1a1815] text-[#f7f4ef] px-2 py-1 rounded shadow-md pointer-events-none whitespace-nowrap mb-1">
                    {formatINR(item.revenue)} ({item.count} orders)
                  </div>

                  {/* Clean Bar */}
                  <div
                    style={{ height: `${displayHeight}%` }}
                    className="w-full max-w-[36px] rounded-t bg-[#8c7355] group-hover:bg-[#1a1815] transition-colors"
                  />

                  {/* Label */}
                  <span className="text-[10px] font-mono text-[#7a6f64] truncate max-w-full text-center">
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="mt-3.5 flex items-center justify-between text-xs text-[#7a6f64] pt-1">
            <span>
              Period Total: <strong className="text-[#1a1815] font-medium">{formatINR(trendData.reduce((s, i) => s + (i.revenue || 0), 0))}</strong>
            </span>
            <span>
              Orders Placed: <strong className="text-[#1a1815] font-mono">{trendData.reduce((s, i) => s + (i.count || 0), 0)}</strong>
            </span>
          </div>
        </div>

        {/* Low Stock Section (1 col) */}
        <div className="bg-white border border-[#e8dfd1] rounded-lg p-5 sm:p-6 shadow-xs flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Low Stock Alerts
            </h3>
            <span className="text-[10px] font-mono text-[#8c7355] bg-[#f7f4ef] border border-[#e8dfd1] px-2 py-0.5 rounded">
              ≤ {stats.lowStockThreshold} units
            </span>
          </div>
          <p className="text-xs text-[#7a6f64] mb-4">
            Items that require restocking to maintain store availability.
          </p>

          <div className="flex-1 overflow-y-auto space-y-2.5 max-h-64 pr-1">
            {lowStockProducts.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 bg-[#faf8f5] rounded-md border border-[#e8dfd1]">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 mb-1.5" />
                <p className="text-xs font-semibold text-[#1a1815]">All Hampers Stocked</p>
                <p className="text-[11px] text-[#7a6f64] mt-0.5">
                  No items currently below the {stats.lowStockThreshold} unit threshold.
                </p>
              </div>
            ) : (
              lowStockProducts.slice(0, 5).map((prod) => {
                const stockQty = prod.stock_quantity ?? 0;
                return (
                  <div
                    key={prod.id}
                    className="flex items-center justify-between p-2.5 rounded-md border border-[#f0e9df] hover:border-[#c5a880] transition-colors bg-[#fdfcfb]"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={prod.images?.[0] || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&q=80'}
                        alt={prod.name}
                        className="w-9 h-9 rounded object-cover border border-[#e8dfd1] shrink-0"
                      />
                      <div className="min-w-0">
                        <h4 className="text-xs font-medium text-[#1a1815] truncate" title={prod.name}>
                          {prod.name}
                        </h4>
                        <span className="text-[10px] text-[#7a6f64] font-mono">
                          {formatINR(prod.price)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pl-2 shrink-0">
                      <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded bg-rose-50 text-rose-800 border border-rose-200">
                        {stockQty} left
                      </span>
                      <Link
                        to={`/admin/products/edit/${prod.id}`}
                        className="text-xs font-medium text-[#8c7355] hover:text-[#1a1815] underline"
                      >
                        Edit
                      </Link>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-[#f0e9df]">
            <Link
              to="/admin/products?filter=low-stock"
              className="text-xs text-[#8c7355] hover:text-[#1a1815] flex items-center justify-between font-medium"
            >
              <span>Manage all inventory</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>

      {/* ─── 3. RECENT ORDERS TABLE (MAIN DASHBOARD AREA) ─────────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-lg p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Recent Orders
            </h3>
            <p className="text-xs text-[#7a6f64] mt-0.5">
              Latest gift orders received from the customer storefront
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchDashboardData}
              disabled={refreshing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-[#635340] hover:text-[#1a1815] border border-[#e8dfd1] rounded-md hover:bg-[#faf8f5] transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
            <Link
              to="/admin/orders"
              className="inline-flex items-center gap-1 text-xs font-medium text-[#8c7355] hover:text-[#1a1815]"
            >
              <span>View All ({stats.totalOrders})</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

        <div className="overflow-x-auto -mx-5 sm:mx-0">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#e8dfd1] text-[11px] font-mono uppercase tracking-wider text-[#7a6f64] bg-[#fbfaf8]">
                <th className="py-2.5 px-4 font-semibold">Order</th>
                <th className="py-2.5 px-4 font-semibold">Customer</th>
                <th className="py-2.5 px-4 font-semibold">Date</th>
                <th className="py-2.5 px-4 font-semibold">Amount</th>
                <th className="py-2.5 px-4 font-semibold">Payment</th>
                <th className="py-2.5 px-4 font-semibold">Status</th>
                <th className="py-2.5 px-4 text-right font-semibold">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f0e9df]">
              {recentOrders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#7a6f64]">
                    <Package className="w-7 h-7 mx-auto text-stone-300 mb-2" />
                    <p className="font-medium text-stone-800 text-xs">No orders recorded yet</p>
                    <p className="text-[11px] text-stone-500 mt-0.5">
                      When customers place orders on the storefront, they will immediately appear here.
                    </p>
                  </td>
                </tr>
              ) : (
                recentOrders.map((order) => {
                  const dateStr = order.created_at
                    ? new Date(order.created_at).toLocaleDateString('en-IN', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })
                    : '—';

                  return (
                    <tr
                      key={order.id}
                      onClick={() => navigate(`/admin/orders?orderId=${order.order_number || order.id}`)}
                      className="hover:bg-[#fbfaf8] cursor-pointer transition-colors"
                    >
                      <td className="py-3 px-4 font-mono font-medium text-[#1a1815]">
                        #{order.order_number || order.id?.slice(0, 8)}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#1a1815]">
                          {order.customer_name || 'Customer'}
                        </div>
                        <div className="text-[11px] text-[#7a6f64] truncate max-w-[170px]">
                          {order.customer_email || order.customer_phone || ''}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-[#7a6f64] font-mono">
                        {dateStr}
                      </td>
                      <td className="py-3 px-4 font-medium text-[#1a1815]">
                        {formatINR(order.total_amount)}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider border ${getPaymentBadge(
                            order.payment_status
                          )}`}
                        >
                          {order.payment_status || 'Pending'}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-medium border ${getStatusBadge(
                            order.status
                          )}`}
                        >
                          {order.status || 'Pending'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Link
                          to={`/admin/orders?orderId=${order.order_number || order.id}`}
                          onClick={(e) => e.stopPropagation()}
                          className="text-xs font-medium text-[#8c7355] hover:text-[#1a1815] underline"
                        >
                          View Details
                        </Link>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
