import React, { useState, useEffect } from 'react';
import {
  Store,
  Truck,
  ShieldCheck,
  AlertTriangle,
  Save,
  Loader2,
  Mail,
  Phone,
  MapPin,
  CheckCircle2,
  Megaphone,
  LayoutTemplate,
  Image as ImageIcon
} from 'lucide-react';
import { adminService } from '../../services/adminService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useStore } from '../../context/StoreContext';

export const AdminSettings = () => {
  const { user, profile, updateProfile } = useAuth();
  const { addToast } = useToast();
  const { notifySettingsUpdated } = useStore();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Settings State
  const [general, setGeneral] = useState({
    store_name: 'Navya Gift Hamper',
    email: 'supportnavya0@gmail.com',
    phone: '+91 97728 48274',
    whatsapp: 'https://wa.me/message/SE4USKU3N2UNE1',
    instagram: 'https://www.instagram.com/navyagift_hamper?stkn=aDl5N3Q1NHZkb2Fv',
    address: 'Jaipur, Rajasthan, India',
    tagline: 'Bespoke Engraving & Luxury Personalized Gifts'
  });

  const [delivery, setDelivery] = useState({
    standard_fee: 0,
    express_fee: 149,
    free_shipping_threshold: 999,
    estimated_days: '7–15 Days'
  });

  const [inventory, setInventory] = useState({
    low_stock_threshold: 5
  });

  const [announcement, setAnnouncement] = useState({
    text: 'Free Premium Gift Packaging & Complimentary Gift Cards',
    email: 'Supportnavya0@gmail.com',
    instagram: '@navyagift_hamper',
    is_active: true
  });

  const [homepage, setHomepage] = useState({
    hero_title: 'Gifts Made Beautiful',
    hero_subtitle: 'Thoughtfully curated hampers for unforgettable moments.',
    hero_tag: 'CURATED WITH LOVE',
    cta_text: 'Shop Now',
    cta_link: '/gifts',
    banner_image: 'https://lh3.googleusercontent.com/d/1iE5cuh0nsMcSwCVcS3o_-TGDTTpLUNif'
  });

  // Owner Profile state
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');

  useEffect(() => {
    let isMounted = true;
    async function load() {
      try {
        const res = await adminService.getSettings();
        if (isMounted && res.success && res.settings) {
          if (res.settings.general) setGeneral((prev) => ({ ...prev, ...res.settings.general }));
          if (res.settings.delivery) setDelivery((prev) => ({ ...prev, ...res.settings.delivery }));
          if (res.settings.inventory) setInventory((prev) => ({ ...prev, ...res.settings.inventory }));
          if (res.settings.announcement) setAnnouncement((prev) => ({ ...prev, ...res.settings.announcement }));
          if (res.settings.homepage) setHomepage((prev) => ({ ...prev, ...res.settings.homepage }));
        }
        if (profile) {
          setOwnerName(profile.name || '');
          setOwnerPhone(profile.phone || '');
        }
      } catch (err) {
        console.error('Error loading settings:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    load();
    return () => {
      isMounted = false;
    };
  }, [profile]);

  const handleSaveGeneral = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const res = await adminService.updateSettings('general', general);
      if (res.success) {
        notifySettingsUpdated('general', general);
        addToast('Store profile details updated successfully.', 'success');
      } else {
        addToast(res.error || 'Failed to save store settings', 'error');
      }
    } catch (err) {
      addToast(err.message || 'Failed to save store settings', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveDelivery = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const payload = {
        ...delivery,
        standard_fee: Number(delivery.standard_fee) || 0,
        express_fee: Number(delivery.express_fee) || 0,
        free_shipping_threshold: Number(delivery.free_shipping_threshold) || 0
      };
      const res = await adminService.updateSettings('delivery', payload);
      if (res.success) {
        notifySettingsUpdated('delivery', payload);
        addToast('Delivery policies saved successfully.', 'success');
      } else {
        addToast(res.error || 'Failed to save delivery settings', 'error');
      }
    } catch (err) {
      addToast(err.message || 'Failed to save delivery settings', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveAnnouncement = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const res = await adminService.updateSettings('announcement', announcement);
      if (res.success) {
        notifySettingsUpdated('announcement', announcement);
        addToast('Announcement bar updated successfully.', 'success');
      } else {
        addToast(res.error || 'Failed to save announcement bar', 'error');
      }
    } catch (err) {
      addToast(err.message || 'Failed to save announcement bar', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveHomepage = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const res = await adminService.updateSettings('homepage', homepage);
      if (res.success) {
        notifySettingsUpdated('homepage', homepage);
        addToast('Homepage hero content updated successfully.', 'success');
      } else {
        addToast(res.error || 'Failed to save homepage content', 'error');
      }
    } catch (err) {
      addToast(err.message || 'Failed to save homepage content', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveInventory = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const payload = {
        low_stock_threshold: Number(inventory.low_stock_threshold) || 5
      };
      const res = await adminService.updateSettings('inventory', payload);
      if (res.success) {
        notifySettingsUpdated('inventory', payload);
        addToast('Inventory threshold updated successfully.', 'success');
      } else {
        addToast(res.error || 'Failed to save inventory settings', 'error');
      }
    } catch (err) {
      addToast(err.message || 'Failed to save inventory settings', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveOwnerProfile = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const res = await updateProfile({
        name: ownerName.trim(),
        phone: ownerPhone.trim()
      });
      if (res.success) {
        addToast('Owner profile details updated.', 'success');
      }
    } catch (err) {
      addToast(err.message || 'Failed to update owner profile', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="py-24 text-center text-[#7a6f64] font-mono">
        <Loader2 className="w-6 h-6 animate-spin mx-auto text-[#8c7355] mb-2" />
        Loading settings...
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* ─── HEADER ────────────────────────────────────────────────────────── */}
      <div>
        <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#1a1815]">Settings</h2>
        <p className="text-xs text-[#7a6f64] mt-0.5">
          Configure store identity, delivery tariffs, announcement bar, homepage hero, and owner security.
        </p>
      </div>

      {/* ─── SECTION 1: STORE BRANDING & CONTACT ───────────────────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-2xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5 pb-3.5 border-b border-[#f0e9df]">
          <Store className="w-4 h-4 text-[#8c7355]" />
          <div>
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Store Information & Brand
            </h3>
            <p className="text-[#7a6f64] text-xs">
              Public contact info displayed on website footer, contact page, and notifications.
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveGeneral} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Store Name
              </label>
              <input
                type="text"
                required
                value={general.store_name}
                onChange={(e) => setGeneral({ ...general, store_name: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Official Support Email
              </label>
              <input
                type="email"
                required
                value={general.email}
                onChange={(e) => setGeneral({ ...general, email: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                WhatsApp / Support Mobile
              </label>
              <input
                type="text"
                value={general.phone}
                onChange={(e) => setGeneral({ ...general, phone: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                WhatsApp Direct Link
              </label>
              <input
                type="text"
                value={general.whatsapp}
                onChange={(e) => setGeneral({ ...general, whatsapp: e.target.value })}
                placeholder="https://wa.me/..."
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Instagram Profile Link
              </label>
              <input
                type="text"
                value={general.instagram}
                onChange={(e) => setGeneral({ ...general, instagram: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Store Tagline
              </label>
              <input
                type="text"
                value={general.tagline}
                onChange={(e) => setGeneral({ ...general, tagline: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Dispatch / Studio Address
              </label>
              <input
                type="text"
                value={general.address}
                onChange={(e) => setGeneral({ ...general, address: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
              />
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Information</span>
            </button>
          </div>
        </form>
      </div>

      {/* ─── SECTION 2: DELIVERY & SHIPPING SETTINGS ───────────────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-2xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5 pb-3.5 border-b border-[#f0e9df]">
          <Truck className="w-4 h-4 text-[#8c7355]" />
          <div>
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Delivery & Shipping Policies
            </h3>
            <p className="text-[#7a6f64] text-xs">
              Configure standard and express courier delivery charges and expected timelines.
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveDelivery} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Standard Shipping (₹)
              </label>
              <input
                type="number"
                min="0"
                value={delivery.standard_fee}
                onChange={(e) => setDelivery({ ...delivery, standard_fee: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
              <span className="text-[10px] text-[#7a6f64] mt-0.5 block">0 for Free Standard Delivery</span>
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Express Shipping (₹)
              </label>
              <input
                type="number"
                min="0"
                value={delivery.express_fee}
                onChange={(e) => setDelivery({ ...delivery, express_fee: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Estimated Delivery Window
              </label>
              <input
                type="text"
                value={delivery.estimated_days}
                onChange={(e) => setDelivery({ ...delivery, estimated_days: e.target.value })}
                placeholder="7–15 Days"
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Delivery Settings</span>
            </button>
          </div>
        </form>
      </div>

      {/* ─── SECTION 3: ANNOUNCEMENT BAR SETTINGS ─────────────────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-2xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5 pb-3.5 border-b border-[#f0e9df]">
          <Megaphone className="w-4 h-4 text-[#8c7355]" />
          <div>
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Announcement Bar
            </h3>
            <p className="text-[#7a6f64] text-xs">
              Top announcement message displayed across all customer-facing store pages.
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveAnnouncement} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Announcement Message Text
              </label>
              <input
                type="text"
                required
                value={announcement.text}
                onChange={(e) => setAnnouncement({ ...announcement, text: e.target.value })}
                placeholder="e.g. Free Premium Gift Packaging & Complimentary Gift Cards"
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Announcement Contact Email
              </label>
              <input
                type="email"
                value={announcement.email}
                onChange={(e) => setAnnouncement({ ...announcement, email: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Instagram Handle Display
              </label>
              <input
                type="text"
                value={announcement.instagram}
                onChange={(e) => setAnnouncement({ ...announcement, instagram: e.target.value })}
                placeholder="@navyagift_hamper"
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Announcement</span>
            </button>
          </div>
        </form>
      </div>

      {/* ─── SECTION 4: HOMEPAGE HERO BANNER & CONTENT ───────────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-2xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5 pb-3.5 border-b border-[#f0e9df]">
          <LayoutTemplate className="w-4 h-4 text-[#8c7355]" />
          <div>
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Homepage Hero Banner
            </h3>
            <p className="text-[#7a6f64] text-xs">
              Primary hero slide, headline, promotional banner image, and call-to-action button.
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveHomepage} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Hero Title Headline
              </label>
              <input
                type="text"
                required
                value={homepage.hero_title}
                onChange={(e) => setHomepage({ ...homepage, hero_title: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Tagline Chip / Badge
              </label>
              <input
                type="text"
                value={homepage.hero_tag}
                onChange={(e) => setHomepage({ ...homepage, hero_tag: e.target.value })}
                placeholder="e.g. CURATED WITH LOVE"
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Hero Subtitle (Inspirational Quote)
              </label>
              <input
                type="text"
                value={homepage.hero_subtitle}
                onChange={(e) => setHomepage({ ...homepage, hero_subtitle: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                CTA Button Text
              </label>
              <input
                type="text"
                value={homepage.cta_text}
                onChange={(e) => setHomepage({ ...homepage, cta_text: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                CTA Button Link
              </label>
              <input
                type="text"
                value={homepage.cta_link}
                onChange={(e) => setHomepage({ ...homepage, cta_link: e.target.value })}
                placeholder="/gifts"
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Banner Image URL
              </label>
              <input
                type="url"
                value={homepage.banner_image}
                onChange={(e) => setHomepage({ ...homepage, banner_image: e.target.value })}
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
              {homepage.banner_image && (
                <div className="mt-2 h-24 w-full rounded-xl overflow-hidden border border-[#e8dfd1] bg-[#faf8f5]">
                  <img
                    src={homepage.banner_image}
                    alt="Hero Preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Hero Content</span>
            </button>
          </div>
        </form>
      </div>

      {/* ─── SECTION 5: INVENTORY ALERT THRESHOLD ─────────────────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-2xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5 pb-3.5 border-b border-[#f0e9df]">
          <AlertTriangle className="w-4 h-4 text-[#8c7355]" />
          <div>
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Low Stock Alert Threshold
            </h3>
            <p className="text-[#7a6f64] text-xs">
              Hamper items with stock at or below this count will appear on the dashboard Low Stock list.
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveInventory} className="flex flex-col sm:flex-row items-center gap-4">
          <div className="w-full sm:w-64">
            <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
              Alert Trigger (Units)
            </label>
            <input
              type="number"
              min="1"
              max="50"
              value={inventory.low_stock_threshold}
              onChange={(e) => setInventory({ ...inventory, low_stock_threshold: e.target.value })}
              className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full sm:w-auto px-4 py-2 mt-auto rounded-xl bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium transition-colors shrink-0"
          >
            Update Threshold
          </button>
        </form>
      </div>

      {/* ─── SECTION 6: OWNER ACCOUNT CREDENTIALS & SECURITY ───────────────── */}
      <div className="bg-white border border-[#e8dfd1] rounded-2xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5 pb-3.5 border-b border-[#f0e9df]">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <div>
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Owner Account & Access
            </h3>
            <p className="text-[#7a6f64] text-xs">
              Verified owner credentials for store management and administration.
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveOwnerProfile} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Owner Name
              </label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                placeholder="e.g. Navya Store Admin"
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#7a6f64] mb-1">
                Owner Direct Contact
              </label>
              <input
                type="text"
                value={ownerPhone}
                onChange={(e) => setOwnerPhone(e.target.value)}
                placeholder="+91..."
                className="w-full bg-white border border-[#e8dfd1] rounded-xl px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] font-mono"
              />
            </div>

            <div className="sm:col-span-2 p-3.5 bg-[#faf8f5] border border-[#e8dfd1] rounded-xl text-xs font-mono space-y-1.5 text-[#7a6f64]">
              <div className="flex items-center justify-between">
                <span>Account Email:</span>
                <span className="text-[#1a1815] font-medium">{user?.email || 'supportnavya0@gmail.com'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Assigned Role:</span>
                <span className="text-[#8c7355] font-bold uppercase">{profile?.role || 'owner'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Security / Password:</span>
                <span className="text-emerald-700 font-medium">Bcrypt Encrypted (Zero Plaintext Exposure)</span>
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Update Owner Profile</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
