import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import {
  ArrowLeft,
  Upload,
  Plus,
  Trash2,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Loader2,
  X,
  Check
} from 'lucide-react';
import { adminService } from '../../services/adminService';
import { useToast } from '../../context/ToastContext';

export const AdminProductForm = () => {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const { addToast } = useToast();
  const fileInputRef = useRef(null);

  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(isEdit);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Form State
  const [form, setForm] = useState({
    name: '',
    description: '',
    full_description: '',
    category: "Men's Hampers",
    subcategory: 'Gift Hamper',
    gender: 'Unisex',
    price: '',
    original_price: '',
    discount_percentage: 0,
    stock_quantity: 20,
    sku: '',
    status: 'active',
    is_featured: false,
    is_new: false,
    is_bestseller: false,
    images: [],
    specifications: [
      'Handcrafted Luxury Keepsake Gift Box with Gold Foil Branding',
      'Personalized Parchment Greeting Card with Wax Seal',
      'Protective Silk Cushioning and Satin Ribbon Finish'
    ],
    weight_size: '1.2 kg • 28 x 22 x 10 cm',
    delivery_info: 'Standard 7–15 days delivery across India. Protective gift hamper packaging.',
    personalization_options: {
      allow_name: true,
      allow_note: true
    }
  });

  const [newImageUrl, setNewImageUrl] = useState('');
  const [newSpec, setNewSpec] = useState('');

  // Load categories and product data
  useEffect(() => {
    let isMounted = true;

    async function init() {
      try {
        const cats = await adminService.getAllCategories();
        if (isMounted) {
          setCategories(cats || []);
          if (cats && cats.length > 0 && !isEdit) {
            setForm((prev) => ({ ...prev, category: cats[0].name }));
          }
        }

        if (isEdit) {
          const product = await adminService.getProductById(id);
          if (isMounted) {
            if (product) {
              const price = product.price ?? '';
              const orig = product.original_price ?? '';
              let discount = product.discount_percentage ?? 0;
              if ((!discount || isNaN(discount)) && orig && Number(orig) > Number(price)) {
                discount = Math.round(((Number(orig) - Number(price)) / Number(orig)) * 100);
              }

              setForm({
                name: product.name || '',
                description: product.description || '',
                full_description: product.full_description || product.description || '',
                category: product.category || "Men's Hampers",
                subcategory: product.subcategory || 'Gift Hamper',
                gender: product.gender || 'Unisex',
                price,
                original_price: orig,
                discount_percentage: discount,
                stock_quantity: product.stock_quantity ?? (product.in_stock ? 20 : 0),
                sku: product.sku || '',
                status: product.status || (product.in_stock ? 'active' : 'disabled'),
                is_featured: !!product.is_featured,
                is_new: !!product.is_new,
                is_bestseller: !!product.is_bestseller,
                images: Array.isArray(product.images) && product.images.length > 0 ? product.images : [],
                specifications:
                  Array.isArray(product.specifications) && product.specifications.length > 0
                    ? product.specifications
                    : [
                        'Handcrafted Luxury Keepsake Gift Box with Gold Foil Branding',
                        'Personalized Parchment Greeting Card with Wax Seal'
                      ],
                weight_size: product.weight_size || '1.2 kg • 28 x 22 x 10 cm',
                delivery_info: product.delivery_info || 'Standard 7–15 days delivery across India. Protective gift hamper packaging.',
                personalization_options: product.personalization_options || {
                  allow_name: true,
                  allow_note: true
                }
              });
            } else {
              addToast('Product not found in database', 'error');
              navigate('/admin/products');
            }
          }
        } else {
          setForm((prev) => ({
            ...prev,
            sku: `NVY-${Date.now().toString().slice(-6)}`
          }));
        }
      } catch (err) {
        console.error('Error initializing product form:', err);
        addToast('Something went wrong while loading product details.', 'error');
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    init();
    return () => {
      isMounted = false;
    };
  }, [id, isEdit]);

  // Interactive price & discount calculations
  const handleSellingPriceChange = (val) => {
    const p = Number(val);
    const orig = Number(form.original_price);
    let newDisc = form.discount_percentage;
    if (orig && orig > p && p > 0) {
      newDisc = Math.round(((orig - p) / orig) * 100);
    } else if (orig && p >= orig) {
      newDisc = 0;
    }
    setForm((prev) => ({ ...prev, price: val, discount_percentage: newDisc }));
  };

  const handleOriginalPriceChange = (val) => {
    const orig = Number(val);
    const p = Number(form.price);
    let newDisc = form.discount_percentage;
    if (orig && orig > p && p > 0) {
      newDisc = Math.round(((orig - p) / orig) * 100);
    } else if (!val || orig <= p) {
      newDisc = 0;
    }
    setForm((prev) => ({ ...prev, original_price: val, discount_percentage: newDisc }));
  };

  const handleDiscountPercentageChange = (val) => {
    const disc = Number(val);
    const orig = Number(form.original_price);
    let newPrice = form.price;
    if (orig && !isNaN(disc) && disc >= 0 && disc <= 100) {
      newPrice = Math.round(orig * (1 - disc / 100));
    }
    setForm((prev) => ({ ...prev, discount_percentage: val, price: newPrice }));
  };

  // Image Upload to InsForge
  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploadingImage(true);
      const res = await adminService.uploadProductImage(file);
      if (res.success && res.url) {
        setForm((prev) => ({
          ...prev,
          images: [...prev.images, res.url]
        }));
        addToast('Image uploaded.', 'success');
      } else {
        addToast(res.error || 'Failed to upload image.', 'error');
      }
    } catch (err) {
      console.error('Upload error:', err);
      addToast('Image upload failed. Please try again.', 'error');
    } finally {
      setUploadingImage(false);
      e.target.value = '';
    }
  };

  const handleAddImageUrl = () => {
    if (!newImageUrl.trim()) return;
    setForm((prev) => ({
      ...prev,
      images: [...prev.images, newImageUrl.trim()]
    }));
    setNewImageUrl('');
  };

  const handleRemoveImage = (index) => {
    setForm((prev) => ({
      ...prev,
      images: prev.images.filter((_, idx) => idx !== index)
    }));
  };

  const handleSetMainImage = (index) => {
    if (index === 0) return;
    setForm((prev) => {
      const copy = [...prev.images];
      const [selected] = copy.splice(index, 1);
      copy.unshift(selected);
      return { ...prev, images: copy };
    });
  };

  // Hamper contents / specifications
  const handleAddSpec = () => {
    if (!newSpec.trim()) return;
    setForm((prev) => ({
      ...prev,
      specifications: [...prev.specifications, newSpec.trim()]
    }));
    setNewSpec('');
  };

  const handleRemoveSpec = (index) => {
    setForm((prev) => ({
      ...prev,
      specifications: prev.specifications.filter((_, i) => i !== index)
    }));
  };

  // Submit Handler
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.name.trim()) {
      addToast('Please enter a product name.', 'error');
      return;
    }
    if (!form.category.trim()) {
      addToast('Please select a category.', 'error');
      return;
    }
    const priceNum = Number(form.price);
    if (isNaN(priceNum) || priceNum < 0) {
      addToast('Please enter a valid price.', 'error');
      return;
    }
    const stockNum = Number(form.stock_quantity);
    if (isNaN(stockNum) || stockNum < 0) {
      addToast('Stock quantity cannot be negative.', 'error');
      return;
    }
    if (form.images.length === 0) {
      addToast('Please provide at least one product image.', 'error');
      return;
    }

    try {
      setSubmitting(true);
      setSavedSuccess(false);

      if (isEdit) {
        const res = await adminService.updateProduct(id, form);
        if (res.success) {
          setSavedSuccess(true);
          addToast('Product updated successfully.', 'success');
          setTimeout(() => navigate('/admin/products'), 600);
        } else {
          addToast(res.error || 'Failed to update product', 'error');
        }
      } else {
        const res = await adminService.createProduct(form);
        if (res.success) {
          setSavedSuccess(true);
          addToast('Product added successfully.', 'success');
          setTimeout(() => navigate('/admin/products'), 600);
        } else {
          addToast(res.error || 'Failed to create product', 'error');
        }
      }
    } catch (err) {
      console.error('Error saving product:', err);
      addToast('Something went wrong while saving changes.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto space-y-4 animate-pulse">
        <div className="h-6 w-36 bg-stone-200 rounded" />
        <div className="h-48 bg-white border border-[#e8dfd1] rounded-lg" />
        <div className="h-36 bg-white border border-[#e8dfd1] rounded-lg" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16">
      {/* ─── TOP ACTION & BREADCRUMB BAR ────────────────────────────────────── */}
      <div className="flex items-center justify-between pb-3 border-b border-[#e8dfd1]">
        <Link
          to="/admin/products"
          className="inline-flex items-center gap-1.5 text-xs text-[#7a6f64] hover:text-[#1a1815] transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Products</span>
        </Link>

        {isEdit && (
          <Link
            to={`/product/${id}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs text-[#8c7355] hover:text-[#1a1815]"
          >
            <span>View on Store</span>
            <ExternalLink className="w-3 h-3" />
          </Link>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* ─── SECTION 1: PRODUCT INFORMATION ──────────────────────────────── */}
        <div className="bg-white border border-[#e8dfd1] rounded-lg p-5 sm:p-6 shadow-xs space-y-4">
          <div className="border-b border-[#f0e9df] pb-3">
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Product Information
            </h3>
            <p className="text-xs text-[#7a6f64] mt-0.5">
              Primary product identifiers and descriptive copy for customers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Product Name *
              </label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. Classic Birthday Celebration Hamper"
                className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Category *
              </label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-2 text-xs text-[#4a423b] focus:outline-none focus:border-[#8c7355] focus:bg-white"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
                <option value="Birthday Hampers">Birthday Hampers</option>
                <option value="Anniversary Hampers">Anniversary Hampers</option>
                <option value="Men's Hampers">Men's Hampers</option>
                <option value="Women's Hampers">Women's Hampers</option>
                <option value="Gifts">Gifts</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Sub-category
              </label>
              <input
                type="text"
                value={form.subcategory}
                onChange={(e) => setForm({ ...form, subcategory: e.target.value })}
                placeholder="e.g. Birthday, Luxury Box"
                className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Short Description *
              </label>
              <textarea
                rows={2}
                required
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Brief summary of what this gift hamper contains..."
                className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md p-2.5 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Detailed Description
              </label>
              <textarea
                rows={3}
                value={form.full_description}
                onChange={(e) => setForm({ ...form, full_description: e.target.value })}
                placeholder="Full packaging, ingredients, craft origin, and styling information..."
                className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md p-2.5 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white"
              />
            </div>
          </div>
        </div>

        {/* ─── SECTION 2: PRICING ───────────────────────────────────────────── */}
        <div className="bg-white border border-[#e8dfd1] rounded-lg p-5 sm:p-6 shadow-xs space-y-4">
          <div className="border-b border-[#f0e9df] pb-3">
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Pricing
            </h3>
            <p className="text-xs text-[#7a6f64] mt-0.5">
              Set customer selling price and optional original reference price.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Selling Price (₹) *
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-400 text-xs font-mono">
                  ₹
                </span>
                <input
                  type="number"
                  required
                  min="0"
                  step="1"
                  value={form.price}
                  onChange={(e) => handleSellingPriceChange(e.target.value)}
                  placeholder="1299"
                  className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md pl-7 pr-3 py-2 text-xs font-medium text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Original Price / MRP (₹)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-400 text-xs font-mono">
                  ₹
                </span>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={form.original_price}
                  onChange={(e) => handleOriginalPriceChange(e.target.value)}
                  placeholder="1799"
                  className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md pl-7 pr-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Discount (%)
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={form.discount_percentage}
                  onChange={(e) => handleDiscountPercentageChange(e.target.value)}
                  placeholder="0"
                  className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-2 text-xs font-medium text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white font-mono"
                />
                <span className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-stone-400 text-xs font-mono">
                  %
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* ─── SECTION 3: INVENTORY ─────────────────────────────────────────── */}
        <div className="bg-white border border-[#e8dfd1] rounded-lg p-5 sm:p-6 shadow-xs space-y-4">
          <div className="border-b border-[#f0e9df] pb-3">
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Inventory & Tracking
            </h3>
            <p className="text-xs text-[#7a6f64] mt-0.5">
              Manage stock level, product identification, and catalog availability.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                SKU / Product Code *
              </label>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  required
                  value={form.sku}
                  onChange={(e) => setForm({ ...form, sku: e.target.value })}
                  placeholder="NVY-HMP-101"
                  className="flex-1 bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white font-mono"
                />
                <button
                  type="button"
                  onClick={() =>
                    setForm({
                      ...form,
                      sku: `NVY-${Date.now().toString().slice(-6)}`
                    })
                  }
                  className="px-2.5 py-1.5 bg-[#f7f4ef] border border-[#e8dfd1] text-xs text-[#635340] rounded-md hover:bg-stone-100 shrink-0 font-mono"
                  title="Generate SKU"
                >
                  Gen
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Stock Quantity *
              </label>
              <input
                type="number"
                required
                min="0"
                value={form.stock_quantity}
                onChange={(e) => setForm({ ...form, stock_quantity: e.target.value })}
                placeholder="20"
                className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-2 text-xs font-medium text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white font-mono"
              />
              <span className="text-[11px] text-stone-500 mt-1 block">
                0 marks product as Out of Stock
              </span>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Availability Status
              </label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
                className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-2 text-xs text-[#4a423b] focus:outline-none focus:border-[#8c7355] focus:bg-white"
              >
                <option value="active">Active (Visible)</option>
                <option value="disabled">Disabled (Hidden)</option>
                <option value="archived">Archived</option>
              </select>
            </div>
          </div>
        </div>

        {/* ─── SECTION 4: MEDIA ─────────────────────────────────────────────── */}
        <div className="bg-white border border-[#e8dfd1] rounded-lg p-5 sm:p-6 shadow-xs space-y-4">
          <div className="border-b border-[#f0e9df] pb-3 flex items-center justify-between">
            <div>
              <h3 className="font-serif text-base font-semibold text-[#1a1815]">
                Media & Photography
              </h3>
              <p className="text-xs text-[#7a6f64] mt-0.5">
                The first image is the main cover. Click "Set as Main" on any image to change.
              </p>
            </div>
            <span className="text-xs font-mono text-[#7a6f64]">
              {form.images.length} image{form.images.length !== 1 ? 's' : ''}
            </span>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            disabled={uploadingImage}
            className="hidden"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Upload file button */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center justify-center p-4 border border-dashed border-[#d8cbb8] hover:border-[#8c7355] rounded-md cursor-pointer bg-[#fbfaf8] hover:bg-white transition-colors text-center"
            >
              <div className="flex items-center gap-2 text-xs font-medium text-[#1a1815]">
                {uploadingImage ? (
                  <Loader2 className="w-4 h-4 animate-spin text-[#8c7355]" />
                ) : (
                  <Upload className="w-4 h-4 text-[#8c7355]" />
                )}
                <span>{uploadingImage ? 'Uploading image...' : 'Upload Image File'}</span>
              </div>
            </div>

            {/* Paste URL */}
            <div className="flex gap-2">
              <input
                type="url"
                value={newImageUrl}
                onChange={(e) => setNewImageUrl(e.target.value)}
                placeholder="Or paste direct image URL..."
                className="flex-1 bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white"
              />
              <button
                type="button"
                onClick={handleAddImageUrl}
                className="px-3.5 py-2 bg-[#f7f4ef] hover:bg-stone-200 border border-[#e8dfd1] rounded-md text-xs font-medium text-[#1a1815] shrink-0"
              >
                + Add
              </button>
            </div>
          </div>

          {/* Images Grid */}
          {form.images.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3 pt-2">
              {form.images.map((imgUrl, idx) => (
                <div
                  key={idx}
                  className={`relative rounded-md overflow-hidden border bg-stone-50 aspect-square group ${
                    idx === 0 ? 'border-[#8c7355] ring-1 ring-[#8c7355]' : 'border-[#e8dfd1]'
                  }`}
                >
                  <img
                    src={imgUrl}
                    alt={`Product photo ${idx + 1}`}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src =
                        'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&q=80';
                    }}
                  />

                  {idx === 0 && (
                    <span className="absolute top-1.5 left-1.5 text-[9px] font-mono font-bold bg-[#1a1815] text-[#f7f4ef] px-1.5 py-0.5 rounded shadow-xs">
                      Main
                    </span>
                  )}

                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 p-2">
                    {idx !== 0 && (
                      <button
                        type="button"
                        onClick={() => handleSetMainImage(idx)}
                        className="px-2 py-1 bg-white text-[#1a1815] rounded text-[10px] font-medium shadow-xs hover:bg-[#faf8f5]"
                      >
                        Set Main
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(idx)}
                      className="p-1 bg-rose-700 text-white rounded text-[10px] shadow-xs hover:bg-rose-800"
                      title="Remove image"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ─── SECTION 5: SPECIFICATIONS & STORE SETTINGS ───────────────────── */}
        <div className="bg-white border border-[#e8dfd1] rounded-lg p-5 sm:p-6 shadow-xs space-y-4">
          <div className="border-b border-[#f0e9df] pb-3">
            <h3 className="font-serif text-base font-semibold text-[#1a1815]">
              Hamper Contents & Store Settings
            </h3>
            <p className="text-xs text-[#7a6f64] mt-0.5">
              Specific inclusions and catalog tags.
            </p>
          </div>

          {/* Hamper inclusions */}
          <div>
            <label className="block text-xs font-medium text-[#1a1815] mb-1.5">
              Hamper Contents / Inclusions
            </label>
            <div className="flex gap-2 mb-2.5">
              <input
                type="text"
                value={newSpec}
                onChange={(e) => setNewSpec(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSpec();
                  }
                }}
                placeholder="e.g. Scented Soy Candle in Amber Jar (120g)"
                className="flex-1 bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-1.5 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white"
              />
              <button
                type="button"
                onClick={handleAddSpec}
                className="px-3.5 py-1.5 bg-[#f7f4ef] hover:bg-stone-200 border border-[#e8dfd1] rounded-md text-xs font-medium text-[#1a1815] shrink-0"
              >
                + Add Item
              </button>
            </div>

            <div className="space-y-1.5">
              {form.specifications.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2 rounded bg-[#faf8f5] border border-[#e8dfd1] text-xs text-[#4a423b]"
                >
                  <span className="flex items-center gap-2 truncate">
                    <span className="text-[#8c7355] font-mono text-[10px]">{idx + 1}.</span>
                    {item}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleRemoveSpec(idx)}
                    className="text-stone-400 hover:text-rose-600 p-0.5"
                    title="Remove item"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery & Weight */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Weight & Dimensions
              </label>
              <input
                type="text"
                value={form.weight_size}
                onChange={(e) => setForm({ ...form, weight_size: e.target.value })}
                placeholder="1.2 kg • 28 x 22 x 10 cm"
                className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1a1815] mb-1">
                Delivery Note
              </label>
              <input
                type="text"
                value={form.delivery_info}
                onChange={(e) => setForm({ ...form, delivery_info: e.target.value })}
                placeholder="Standard 7–15 days delivery across India."
                className="w-full bg-[#fbfaf8] border border-[#e8dfd1] rounded-md px-3 py-2 text-xs text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:bg-white"
              />
            </div>
          </div>

          {/* Store Settings: Featured, Bestseller */}
          <div className="flex flex-wrap gap-5 pt-3 border-t border-[#f0e9df]">
            <label className="flex items-center gap-2 cursor-pointer text-xs text-[#4a423b]">
              <input
                type="checkbox"
                checked={form.is_featured}
                onChange={(e) => setForm({ ...form, is_featured: e.target.checked })}
                className="rounded border-[#d8cbb8] text-[#1a1815] focus:ring-0"
              />
              <span>Featured Product on Homepage</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-xs text-[#4a423b]">
              <input
                type="checkbox"
                checked={form.is_bestseller}
                onChange={(e) => setForm({ ...form, is_bestseller: e.target.checked })}
                className="rounded border-[#d8cbb8] text-[#1a1815] focus:ring-0"
              />
              <span>Bestseller Tag</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-xs text-[#4a423b]">
              <input
                type="checkbox"
                checked={form.is_new}
                onChange={(e) => setForm({ ...form, is_new: e.target.checked })}
                className="rounded border-[#d8cbb8] text-[#1a1815] focus:ring-0"
              />
              <span>New Arrival Tag</span>
            </label>
          </div>
        </div>

        {/* ─── STICKY BOTTOM ACTION BAR ─────────────────────────────────────── */}
        <div className="sticky bottom-4 z-20 bg-white/95 backdrop-blur-xs border border-[#e8dfd1] rounded-lg p-3.5 shadow-md flex items-center justify-between">
          <div className="text-xs text-[#7a6f64]">
            {savedSuccess ? (
              <span className="text-emerald-700 font-medium inline-flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                Saved successfully
              </span>
            ) : submitting ? (
              <span className="text-[#8c7355] inline-flex items-center gap-1">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                Saving...
              </span>
            ) : isEdit ? (
              <span>Editing Product #{id}</span>
            ) : (
              <span>New Product Catalog Entry</span>
            )}
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => navigate('/admin/products')}
              disabled={submitting}
              className="px-3.5 py-1.5 rounded-md border border-[#e8dfd1] text-xs font-medium text-[#4a423b] hover:bg-[#faf8f5] transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={submitting || uploadingImage}
              className="px-4 py-1.5 rounded-md bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-medium tracking-wide transition-colors shadow-xs disabled:opacity-50"
            >
              {submitting ? 'Saving...' : isEdit ? 'Save Changes' : 'Add Product'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
