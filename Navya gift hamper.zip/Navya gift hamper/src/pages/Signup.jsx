import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { User, Mail, Phone, Lock, ArrowRight, AlertCircle, ShieldCheck, RotateCcw } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { BrandLogo } from '../components/BrandLogo';

const INDIAN_PHONE_RE = /^[6-9]\d{9}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const FieldError = ({ msg }) =>
  msg ? (
    <span className="flex items-center gap-1 text-[11px] text-red-600 font-sans mt-1">
      <AlertCircle className="w-3 h-3 shrink-0" />
      {msg}
    </span>
  ) : null;

export const Signup = () => {
  // ── Form fields: strictly empty by default — no fake or autofilled data
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // ── OTP Verification step state
  const [pendingEmail, setPendingEmail] = useState(null); // set after signup → triggers OTP view
  const [pendingName, setPendingName] = useState('');
  const [pendingPhone, setPendingPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const [isResending, setIsResending] = useState(false);
  const otpInputRef = useRef(null);
  const cooldownRef = useRef(null);

  const { signUp, verifyOtp, resendOtp } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const returnTo = searchParams.get('returnTo') || '/profile';

  // Start cooldown timer
  const startCooldown = (seconds = 60) => {
    setResendCooldown(seconds);
    if (cooldownRef.current) clearInterval(cooldownRef.current);
    cooldownRef.current = setInterval(() => {
      setResendCooldown((prev) => {
        if (prev <= 1) {
          clearInterval(cooldownRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  useEffect(() => {
    // Focus OTP input when verification step appears
    if (pendingEmail && otpInputRef.current) {
      setTimeout(() => otpInputRef.current?.focus(), 100);
    }
  }, [pendingEmail]);

  useEffect(() => {
    return () => {
      if (cooldownRef.current) clearInterval(cooldownRef.current);
    };
  }, []);

  const validateForm = () => {
    const errs = {};

    if (!formData.name.trim()) {
      errs.name = 'Please enter your full name.';
    }

    if (!formData.email.trim()) {
      errs.email = 'Please enter your email address.';
    } else if (!EMAIL_RE.test(formData.email.trim())) {
      errs.email = 'Please enter a valid email address.';
    }

    if (!formData.phone.trim()) {
      errs.phone = 'Please enter your mobile number.';
    } else if (!INDIAN_PHONE_RE.test(formData.phone.trim())) {
      errs.phone = 'Please enter a valid 10-digit Indian mobile number.';
    }

    if (!formData.password) {
      errs.password = 'Please enter a password.';
    } else if (formData.password.length < 6) {
      errs.password = 'Password must be at least 6 characters long.';
    }

    if (!formData.confirmPassword) {
      errs.confirmPassword = 'Please confirm your password.';
    } else if (formData.password !== formData.confirmPassword) {
      errs.confirmPassword = 'Passwords do not match.';
    }

    return errs;
  };

  const handleBlur = (field) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
    const currentErrors = validateForm();
    setErrors(currentErrors);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setTouched({
      name: true,
      email: true,
      phone: true,
      password: true,
      confirmPassword: true
    });

    const validationErrors = validateForm();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      addToast('Please fill all required fields correctly.', 'error');
      return;
    }

    setIsSubmitting(true);
    const res = await signUp({
      email: formData.email.trim(),
      password: formData.password,
      name: formData.name.trim(),
      phone: formData.phone.trim()
    });
    setIsSubmitting(false);

    if (res.success) {
      if (res.pendingVerification) {
        // Show OTP step
        setPendingEmail(res.email);
        setPendingName(res.name);
        setPendingPhone(res.phone);
        startCooldown(60); // start resend cooldown immediately
        // Clear sensitive fields
        setFormData({ name: '', email: '', phone: '', password: '', confirmPassword: '' });
        setErrors({});
        setTouched({});
      } else {
        // Auto-confirmed — go directly
        addToast('Account created! Welcome to Navya Gift Hamper.', 'success');
        navigate(returnTo);
      }
    }
  };

  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    if (!otp || otp.trim().length < 6) {
      addToast('Please enter the complete 6-digit verification code.', 'error');
      return;
    }

    setIsVerifying(true);
    const res = await verifyOtp({
      email: pendingEmail,
      token: otp.trim(),
      name: pendingName,
      phone: pendingPhone
    });
    setIsVerifying(false);

    if (res.success) {
      navigate(returnTo);
    } else if (res.expired) {
      setOtp('');
      setResendCooldown(0); // allow immediate resend on expiry
    }
  };

  const handleResendOtp = async () => {
    if (resendCooldown > 0 || isResending) return;
    setIsResending(true);
    const res = await resendOtp(pendingEmail);
    setIsResending(false);
    if (res.success) {
      setOtp('');
      startCooldown(60);
    }
  };

  if (pendingEmail) {
    return (
      <div className="max-w-md mx-auto px-4 py-12 sm:py-16 space-y-6">
        <div className="text-center space-y-3">
          <div className="flex justify-center mb-2">
            <BrandLogo height="h-14 sm:h-16" asLink={false} />
          </div>
          <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#8c7a65]">
            EMAIL VERIFICATION
          </span>
          <h1 className="font-serif text-3xl font-bold text-[#1a1815] uppercase tracking-wide">
            VERIFY YOUR EMAIL
          </h1>
          <p className="font-serif italic text-stone-500 text-sm">
            “Enter the 6-digit verification code sent to your email to complete your registration.”
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#e8dfd1] shadow-sm space-y-6">
          <div className="p-4 bg-[#faf8f5] rounded-xl border border-[#e8dfd1] flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-[#8c7355] shrink-0 mt-0.5" />
            <div className="text-xs text-stone-700 space-y-1">
              <p className="font-semibold text-[#1a1815]">Verification code sent to:</p>
              <p className="font-mono text-[#8c7355] font-bold text-sm break-all">{pendingEmail}</p>
              <p className="text-stone-500 text-[11px] pt-1">
                Please check your inbox (and spam/promotions folder).
              </p>
            </div>
          </div>

          <form onSubmit={handleVerifyOtp} className="space-y-4 font-sans text-xs">
            <div>
              <label className="block text-stone-700 font-semibold mb-1 text-center">
                Enter 6-Digit Code
              </label>
              <input
                ref={otpInputRef}
                id="otp-input"
                type="text"
                maxLength={6}
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                placeholder="123456"
                autoComplete="one-time-code"
                className="w-full text-center tracking-[0.4em] font-mono text-2xl font-bold py-3 bg-[#faf8f5] border border-[#e8dfd1] rounded-lg text-[#1a1815] focus:outline-none focus:border-[#8c7355] focus:ring-1 focus:ring-[#8c7355] transition-all"
              />
            </div>

            <button
              type="submit"
              id="verify-otp-btn"
              disabled={isVerifying || otp.length < 6}
              className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white font-semibold py-3.5 rounded-lg uppercase tracking-wider transition-colors shadow-md flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <span>{isVerifying ? 'Verifying...' : 'Verify & Continue'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="space-y-3 pt-2 text-center text-xs font-sans">
            <div className="flex items-center justify-center gap-2">
              <span className="text-stone-500">Didn't receive the code?</span>
              {resendCooldown > 0 ? (
                <span className="text-stone-400 font-medium">
                  Resend in {resendCooldown}s
                </span>
              ) : (
                <button
                  type="button"
                  id="resend-otp-btn"
                  onClick={handleResendOtp}
                  disabled={isResending}
                  className="text-[#8c7355] font-semibold hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className={`w-3 h-3 ${isResending ? 'animate-spin' : ''}`} />
                  {isResending ? 'Sending...' : 'Resend Code'}
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                setPendingEmail(null);
                setOtp('');
              }}
              className="text-stone-500 hover:text-stone-800 text-[11px] underline cursor-pointer"
            >
              ← Edit email or try another address
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-4 py-12 sm:py-16 space-y-6">
      <div className="text-center space-y-3">
        <div className="flex justify-center mb-2">
          <BrandLogo height="h-14 sm:h-16" asLink={false} />
        </div>
        <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#8c7a65]">
          JOIN NAVYA PRIVÉ
        </span>
        <h1 className="font-serif text-3xl font-bold text-[#1a1815] uppercase tracking-wide">
          CREATE ACCOUNT
        </h1>
        <p className="font-serif italic text-stone-500 text-sm">
          “Curated gifting experiences tailored to your personal moments.”
        </p>
      </div>

      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#e8dfd1] shadow-sm">
        <form onSubmit={handleSubmit} noValidate className="space-y-4 font-sans text-xs">
          {/* Full Name */}
          <div>
            <label className="block text-stone-700 font-semibold mb-1">
              Full Name <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                id="signup-name"
                type="text"
                value={formData.name}
                autoComplete="name"
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                onBlur={() => handleBlur('name')}
                placeholder="Enter your full name"
                className={`w-full bg-[#faf8f5] border rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355] transition-colors ${
                  touched.name && errors.name ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                }`}
              />
            </div>
            <FieldError msg={touched.name && errors.name} />
          </div>

          {/* Email Address */}
          <div>
            <label className="block text-stone-700 font-semibold mb-1">
              Email Address <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                id="signup-email"
                type="email"
                value={formData.email}
                autoComplete="email"
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                onBlur={() => handleBlur('email')}
                placeholder="Enter your email address"
                className={`w-full bg-[#faf8f5] border rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355] transition-colors ${
                  touched.email && errors.email ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                }`}
              />
            </div>
            <FieldError msg={touched.email && errors.email} />
          </div>

          {/* Mobile Number */}
          <div>
            <label className="block text-stone-700 font-semibold mb-1">
              Mobile Number <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                id="signup-phone"
                type="tel"
                maxLength={10}
                value={formData.phone}
                autoComplete="tel"
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value.replace(/\D/g, '') })
                }
                onBlur={() => handleBlur('phone')}
                placeholder="10-digit mobile number"
                className={`w-full bg-[#faf8f5] border rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355] transition-colors ${
                  touched.phone && errors.phone ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                }`}
              />
            </div>
            <FieldError msg={touched.phone && errors.phone} />
          </div>

          {/* Password */}
          <div>
            <label className="block text-stone-700 font-semibold mb-1">
              Password <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                id="signup-password"
                type="password"
                value={formData.password}
                autoComplete="new-password"
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                onBlur={() => handleBlur('password')}
                placeholder="Create password (min. 6 characters)"
                className={`w-full bg-[#faf8f5] border rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355] transition-colors ${
                  touched.password && errors.password ? 'border-red-400 bg-red-50' : 'border-[#e8dfd1]'
                }`}
              />
            </div>
            <FieldError msg={touched.password && errors.password} />
          </div>

          {/* Confirm Password */}
          <div>
            <label className="block text-stone-700 font-semibold mb-1">
              Confirm Password <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                id="signup-confirm-password"
                type="password"
                value={formData.confirmPassword}
                autoComplete="new-password"
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                onBlur={() => handleBlur('confirmPassword')}
                placeholder="Re-enter your password"
                className={`w-full bg-[#faf8f5] border rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355] transition-colors ${
                  touched.confirmPassword && errors.confirmPassword
                    ? 'border-red-400 bg-red-50'
                    : 'border-[#e8dfd1]'
                }`}
              />
            </div>
            <FieldError msg={touched.confirmPassword && errors.confirmPassword} />
          </div>

          <button
            type="submit"
            id="signup-submit-btn"
            disabled={isSubmitting}
            className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white font-semibold py-3.5 rounded-lg uppercase tracking-wider transition-colors shadow-md flex items-center justify-center gap-2 mt-2 disabled:opacity-50 cursor-pointer"
          >
            <span>{isSubmitting ? 'Creating Account...' : 'Create Account'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-[#e8dfd1] text-center text-xs text-stone-600 font-sans">
          Already have an account?{' '}
          <Link
            to={`/login?returnTo=${encodeURIComponent(returnTo)}`}
            className="text-[#8c7355] font-bold hover:underline"
          >
            Sign In
          </Link>
        </div>
      </div>
    </div>
  );
};
