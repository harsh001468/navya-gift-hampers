import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { SlidersHorizontal, ChevronRight } from 'lucide-react';
import { productService } from '../services/productService';
import { ProductCard } from '../components/ProductCard';
import { FilterSidebar } from '../components/FilterSidebar';
import { SortDropdown } from '../components/SortDropdown';
import { LoadingSkeleton } from '../components/LoadingSkeleton';

export const Women = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortOption, setSortOption] = useState('featured');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const [filters, setFilters] = useState({
    subcategories: [],
    maxPrice: 8000,
    badges: [],
    inStockOnly: false
  });

  useEffect(() => {
    const loadWomenProducts = async () => {
      setLoading(true);
      const data = await productService.getProductsByCategory('Women');
      setProducts(data);
      setLoading(false);
    };
    loadWomenProducts();

    const handleSync = () => {
      loadWomenProducts();
    };
    window.addEventListener('navya:data_sync', handleSync);
    return () => window.removeEventListener('navya:data_sync', handleSync);
  }, []);

  const availableSubcategories = useMemo(() => {
    const set = new Set();
    products.forEach((p) => {
      if (p.subcategory) set.add(p.subcategory);
    });
    return Array.from(set);
  }, [products]);

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (filters.subcategories.length > 0 && !filters.subcategories.includes(p.subcategory)) {
        return false;
      }
      if (p.price > filters.maxPrice) {
        return false;
      }
      if (filters.badges.length > 0 && !filters.badges.includes(p.badge)) {
        return false;
      }
      if (filters.inStockOnly && p.stock <= 0) {
        return false;
      }
      return true;
    });
  }, [products, filters]);

  const sortedProducts = useMemo(() => {
    const list = [...filteredProducts];
    if (sortOption === 'price-asc') {
      return list.sort((a, b) => a.price - b.price);
    }
    if (sortOption === 'price-desc') {
      return list.sort((a, b) => b.price - a.price);
    }
    if (sortOption === 'rating') {
      return list.sort((a, b) => b.rating - a.rating);
    }
    if (sortOption === 'newest') {
      return list.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
    }
    return list; // featured
  }, [filteredProducts, sortOption]);

  const resetFilters = () => {
    setFilters({
      subcategories: [],
      maxPrice: 8000,
      badges: [],
      inStockOnly: false
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs text-stone-500 font-sans">
        <Link to="/" className="hover:text-black">Home</Link>
        <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
        <span className="font-semibold text-[#1a1815]">Women's Collection</span>
      </nav>

      {/* Header Banner */}
      <div className="bg-[#141210] text-[#faf8f5] rounded-xl p-8 sm:p-12 relative overflow-hidden shadow-xl border border-[#3e352b]">
        <div
          className="absolute inset-0 bg-cover bg-center sm:bg-right opacity-45 scale-105 transition-all duration-700"
          style={{
            backgroundImage:
              'url(https://lh3.googleusercontent.com/d/10grmCxscyvNePDD6GZcjnT72NoUl1N81)'
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#141210] via-[#141210]/85 to-[#141210]/30" />

        <div className="relative z-10 max-w-xl space-y-3">
          <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#c5a880]">
            FOR HER
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl font-bold uppercase tracking-wide text-white">
            WOMEN'S COLLECTION
          </h1>
          <p className="font-serif italic text-base text-stone-300">
            “Elegant gifts, silk scarves, pearl jewelry, rose quartz self-care hampers, and beautiful essentials for her.”
          </p>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-[#e8dfd1] gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileFilterOpen(true)}
            className="lg:hidden flex items-center gap-2 bg-white border border-[#e8dfd1] text-xs font-semibold px-4 py-2 rounded-md"
          >
            <SlidersHorizontal className="w-4 h-4 text-[#8c7355]" />
            <span>Filter</span>
          </button>
          <span className="text-xs text-stone-500 font-sans font-medium">
            Showing <strong className="text-[#1a1815]">{sortedProducts.length}</strong> items
          </span>
        </div>

        <SortDropdown sortOption={sortOption} setSortOption={setSortOption} />
      </div>

      {/* Layout */}
      <div className="flex gap-8">
        <FilterSidebar
          filters={filters}
          setFilters={setFilters}
          resetFilters={resetFilters}
          availableSubcategories={availableSubcategories}
          isMobileOpen={mobileFilterOpen}
          onCloseMobile={() => setMobileFilterOpen(false)}
        />

        {/* Product Grid */}
        <main className="flex-1">
          {loading ? (
            <LoadingSkeleton count={6} />
          ) : sortedProducts.length === 0 ? (
            <div className="py-16 text-center space-y-3 bg-white rounded-lg border border-[#e8dfd1]">
              <h3 className="font-serif text-xl font-semibold text-[#1a1815]">
                No items match your filter criteria
              </h3>
              <p className="text-xs text-stone-500 font-sans">
                Try widening your price limit or clearing active filters.
              </p>
              <button
                onClick={resetFilters}
                className="bg-[#1a1815] text-white text-xs uppercase font-semibold px-6 py-2.5 rounded-md"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedProducts.map((prod) => (
                <ProductCard key={prod.id} product={prod} />
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
