import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

import { productService } from '../services/productService';
import { HeroCarousel } from '../components/HeroCarousel';
import { TrustFeatures } from '../components/TrustFeatures';
import { ProductCarousel } from '../components/ProductCarousel';
import { FloatingWhatsApp } from '../components/FloatingWhatsApp';
import { LoadingSkeleton } from '../components/LoadingSkeleton';
import { useToast } from '../context/ToastContext';


export const Home = () => {
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [newArrivals, setNewArrivals] = useState([]);
  const [giftCategories, setGiftCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  const [newsletterEmail, setNewsletterEmail] = useState('');
  const { addToast } = useToast();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const [allProds, cats] = await Promise.all([
        productService.getProducts(),
        productService.getGiftCategories()
      ]);

      setFeaturedProducts(allProds.filter((p) => p.isFeatured));
      setNewArrivals(allProds.filter((p) => p.isNew));
      setGiftCategories(cats);
      setLoading(false);
    };
    fetchData();

    const handleSync = () => {
      fetchData();
    };
    window.addEventListener('navya:data_sync', handleSync);
    return () => window.removeEventListener('navya:data_sync', handleSync);
  }, []);

  const handleNewsletter = (e) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      addToast('Thank you for subscribing to Navya Privé updates!', 'success');
      setNewsletterEmail('');
    }
  };

  const occasions = [
    { name: "Birthday", emoji: "🎂", link: "/gifts?sub=Birthday Hampers" },
    { name: "Anniversary", emoji: "💍", link: "/gifts?sub=Couple Gifts" },
    { name: "Personalized", emoji: "✨", link: "/gifts?sub=Personalized Hampers" },
    { name: "For Him", emoji: "👔", link: "/men" },
    { name: "For Her", emoji: "🌸", link: "/women" },
    { name: "Romantic", emoji: "❤️", link: "/gifts?sub=Couple Gifts" },
    { name: "Celebration", emoji: "🎉", link: "/gifts" },
    { name: "Surprise", emoji: "🎁", link: "/gifts" }
  ];



  const instagramPosts = [
    "https://lh3.googleusercontent.com/d/10grmCxscyvNePDD6GZcjnT72NoUl1N81",
    "https://lh3.googleusercontent.com/d/1pfwZEh4ESO4mBe3KLqAUXln5VgfUTrsB",
    "https://lh3.googleusercontent.com/d/1XhftF9W_MccsuN8C55SZyjFCB3ypMQfA",
    "https://lh3.googleusercontent.com/d/1iE5cuh0nsMcSwCVcS3o_-TGDTTpLUNif",
    "https://lh3.googleusercontent.com/d/1v7QnjA6NFLURcJ0HETabL0uy_rLMvKNW",
    "https://lh3.googleusercontent.com/d/1wso_GTQv7D-2n8s7ZouJm2uUoTOrlARa"
  ];

  return (
    <div className="space-y-12 sm:space-y-16 pb-16">
      {/* 3. HERO CAROUSEL */}
      <HeroCarousel />

      {/* 4. TRUST & SERVICE FEATURES */}
      <TrustFeatures />

      {/* 5. FEATURED PRODUCTS CAROUSEL */}
      {loading ? (
        <div className="max-w-7xl mx-auto px-4"><LoadingSkeleton count={4} /></div>
      ) : (
        <ProductCarousel
          title="Featured Gifts"
          subtitle="Handpicked favourites for every special moment."
          products={featuredProducts}
          viewAllLink="/gifts"
        />
      )}

      {/* 6. SHOP BY CATEGORY */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#C8A45D]">
            EDITORIAL SELECTION
          </span>
          <h2 className="font-serif text-2xl sm:text-4xl font-bold text-[#171717] uppercase tracking-wide">
            SHOP BY CATEGORY
          </h2>
          <div className="w-10 h-0.5 bg-[#C8A45D] mx-auto mt-2" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {giftCategories.map((cat) => (
            <div
              key={cat.id}
              className="group relative aspect-4/3 rounded-xl overflow-hidden shadow-md border border-[#E7E2DA]"
            >
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-full object-cover img-hover-zoom"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#171717]/90 via-[#171717]/30 to-transparent p-6 flex flex-col justify-end text-white">
                <h3 className="font-serif text-2xl font-bold text-white mb-1 group-hover:text-[#C8A45D] transition-colors">
                  {cat.name}
                </h3>
                <p className="text-xs text-[#E8D7BE] font-sans line-clamp-2 mb-3">
                  {cat.description}
                </p>
                <Link
                  to={cat.link}
                  className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-[#C8A45D] group-hover:text-white transition-colors"
                >
                  <span>Explore Collection</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7. NEW ARRIVALS CAROUSEL */}
      {loading ? (
        <div className="max-w-7xl mx-auto px-4"><LoadingSkeleton count={4} /></div>
      ) : (
        <ProductCarousel
          title="New Arrivals"
          subtitle="Freshly curated gifts you'll love."
          products={newArrivals}
          viewAllLink="/gifts?filter=new"
        />
      )}



      {/* 12. OCCASION GIFTS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#C8A45D]">
            CELEBRATE EVERY MOMENT
          </span>
          <h2 className="font-serif text-2xl sm:text-4xl font-bold text-[#171717] uppercase tracking-wide">
            FIND A GIFT FOR EVERY OCCASION
          </h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {occasions.map((occ, idx) => (
            <Link
              key={idx}
              to={occ.link}
              className="bg-white hover:bg-[#171717] hover:text-white text-[#171717] p-5 rounded-xl border border-[#E7E2DA] shadow-xs text-center transition-all duration-300 group flex flex-col items-center space-y-2"
            >
              <span className="text-2xl group-hover:scale-125 transition-transform duration-300">
                {occ.emoji}
              </span>
              <span className="font-serif text-sm font-bold tracking-wider uppercase">
                {occ.name}
              </span>
            </Link>
          ))}
        </div>
      </section>



      {/* 14. INSTAGRAM GALLERY */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center space-y-1">
          <a
            href="https://www.instagram.com/navyagift_hamper?stkn=aDl5N3Q1NHZkb2Fv"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.25em] text-[#C8A45D] hover:underline"
          >
            <span>@NAVYAGIFT_HAMPER</span>
          </a>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#171717] uppercase tracking-wide">
            MOMENTS MADE BEAUTIFUL
          </h2>
          <p className="text-xs text-stone-500 font-sans">
            Tag us in your celebrations to be featured in our curation studio
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {instagramPosts.map((imgUrl, idx) => (
            <a
              key={idx}
              href="https://www.instagram.com/navyagift_hamper?stkn=aDl5N3Q1NHZkb2Fv"
              target="_blank"
              rel="noreferrer"
              className="group relative aspect-square rounded-lg overflow-hidden border border-[#E7E2DA]"
            >
              <img
                src={imgUrl}
                alt={`Navya Hamper ${idx + 1}`}
                className="w-full h-full object-cover img-hover-zoom"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </div>
            </a>
          ))}
        </div>

        <div className="text-center pt-2">
          <a
            href="https://www.instagram.com/navyagift_hamper?stkn=aDl5N3Q1NHZkb2Fv"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full border border-[#171717] hover:bg-[#171717] hover:text-white text-xs font-semibold uppercase tracking-wider transition-all duration-300"
          >
            <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
            <span>Follow @navyagift_hamper on Instagram</span>
          </a>
        </div>
      </section>

      {/* 15. NEWSLETTER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#171717] text-[#FFFFFF] rounded-xl p-8 sm:p-12 text-center space-y-4 border border-[#363028]">
          <h3 className="font-serif text-2xl sm:text-4xl font-bold tracking-wide uppercase">
            STAY IN THE GIFT LOOP
          </h3>
          <p className="font-serif italic text-xs sm:text-sm text-[#E8D7BE] max-w-md mx-auto">
            “Get new collection updates, gifting inspiration and exclusive Privé offers.”
          </p>
          <form onSubmit={handleNewsletter} className="max-w-md mx-auto flex gap-2 pt-2">
            <input
              type="email"
              required
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder="Enter your email address"
              className="w-full bg-white/10 text-white text-xs px-4 py-3 rounded-md border border-[#C8A45D]/40 focus:outline-none focus:border-[#C8A45D] placeholder-stone-400 font-sans"
            />
            <button
              type="submit"
              className="bg-[#C8A45D] hover:bg-[#d4b472] text-[#171717] text-xs font-bold uppercase tracking-wider px-6 py-3 rounded-md transition-colors"
            >
              Subscribe
            </button>
          </form>
        </div>
      </section>


      {/* 17. FLOATING WHATSAPP BUTTON */}
      <FloatingWhatsApp />
    </div>
  );
};
