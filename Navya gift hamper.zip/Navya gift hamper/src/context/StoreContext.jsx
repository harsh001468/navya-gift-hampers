import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { insforge } from '../lib/insforge';

const StoreContext = createContext(null);

// Default store fallbacks
const DEFAULT_SETTINGS = {
  general: {
    store_name: 'Navya Gift Hamper',
    tagline: 'Curated with Love, Gifted with Emotion.',
    email: 'Supportnavya0@gmail.com',
    phone: '+91 97728 48274',
    whatsapp: 'https://wa.me/message/SE4USKU3N2UNE1',
    instagram: 'https://www.instagram.com/navyagift_hamper?stkn=aDl5N3Q1NHZkb2Fv',
    address: 'Jaipur, Rajasthan, India'
  },
  delivery: {
    standard_fee: 0,
    express_fee: 149,
    free_shipping_threshold: 999,
    estimated_days: '7–15 Days'
  },
  inventory: {
    low_stock_threshold: 5
  },
  announcement: {
    text: 'Free Premium Gift Packaging & Complimentary Gift Cards',
    email: 'Supportnavya0@gmail.com',
    instagram: '@navyagift_hamper',
    is_active: true
  },
  homepage: {
    hero_title: 'Gifts Made Beautiful',
    hero_subtitle: 'Thoughtfully curated hampers for unforgettable moments.',
    hero_tag: 'CURATED WITH LOVE',
    cta_text: 'Shop Now',
    cta_link: '/gifts',
    banner_image: 'https://lh3.googleusercontent.com/d/1iE5cuh0nsMcSwCVcS3o_-TGDTTpLUNif'
  }
};

export const StoreProvider = ({ children }) => {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);

  const fetchSettings = useCallback(async () => {
    try {
      const { data, error } = await insforge.database
        .from('store_settings')
        .select('*');

      if (error) {
        console.warn('[StoreContext] Could not load store_settings from InsForge:', error);
        return;
      }

      if (data && Array.isArray(data)) {
        const merged = { ...DEFAULT_SETTINGS };
        data.forEach((row) => {
          if (row.id && row.data) {
            merged[row.id] = { ...merged[row.id], ...row.data };
          }
        });
        setSettings(merged);
      }
    } catch (err) {
      console.error('[StoreContext] Error fetching store settings:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSettings();

    // Listen to custom window sync events triggered when admin updates settings
    const handleSync = (e) => {
      if (e.detail?.section) {
        fetchSettings();
      } else {
        fetchSettings();
      }
    };

    window.addEventListener('navya:store_settings_updated', handleSync);
    window.addEventListener('navya:data_sync', handleSync);

    return () => {
      window.removeEventListener('navya:store_settings_updated', handleSync);
      window.removeEventListener('navya:data_sync', handleSync);
    };
  }, [fetchSettings]);

  // Global broadcast trigger for when Admin saves changes
  const notifySettingsUpdated = (sectionKey, updatedData) => {
    setSettings((prev) => ({
      ...prev,
      [sectionKey]: { ...prev[sectionKey], ...updatedData }
    }));
    window.dispatchEvent(
      new CustomEvent('navya:store_settings_updated', {
        detail: { section: sectionKey, data: updatedData }
      })
    );
  };

  const storeName = settings.general?.store_name || DEFAULT_SETTINGS.general.store_name;
  const tagline = settings.general?.tagline || DEFAULT_SETTINGS.general.tagline;
  const email = settings.general?.email || DEFAULT_SETTINGS.general.email;
  const phone = settings.general?.phone || DEFAULT_SETTINGS.general.phone;
  const whatsapp = settings.general?.whatsapp || DEFAULT_SETTINGS.general.whatsapp;
  const instagram = settings.general?.instagram || DEFAULT_SETTINGS.general.instagram;
  const address = settings.general?.address || DEFAULT_SETTINGS.general.address;
  const delivery = settings.delivery || DEFAULT_SETTINGS.delivery;
  const announcement = settings.announcement || DEFAULT_SETTINGS.announcement;
  const homepage = settings.homepage || DEFAULT_SETTINGS.homepage;

  return (
    <StoreContext.Provider
      value={{
        settings,
        loading,
        refreshSettings: fetchSettings,
        notifySettingsUpdated,
        storeName,
        tagline,
        email,
        phone,
        whatsapp,
        instagram,
        address,
        delivery,
        announcement,
        homepage
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
