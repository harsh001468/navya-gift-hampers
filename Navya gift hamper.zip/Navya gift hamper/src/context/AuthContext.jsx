import React, { createContext, useContext, useState, useEffect } from 'react';
import { insforge } from '../lib/insforge';
import { useToast } from './ToastContext';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const { addToast } = useToast();

  const fetchProfile = async (userId, userEmail) => {
    try {
      const { data } = await insforge.database
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (data) {
        setProfile(data);
      } else {
        // Fallback profile if not yet created — strictly defaults to customer
        setProfile({
          id: userId,
          email: userEmail,
          name: '',
          phone: '',
          role: 'customer'
        });
      }
    } catch (err) {
      console.error('Error fetching profile:', err);
    }
  };

  // Verify owner status directly from database & verify supportnavya0@gmail.com email
  const verifyOwner = async () => {
    try {
      const { data: currentUserData } = await insforge.auth.getCurrentUser();
      const currentUserId = currentUserData?.user?.id;
      const currentUserEmail = currentUserData?.user?.email?.toLowerCase().trim();
      if (!currentUserId || currentUserEmail !== 'supportnavya0@gmail.com') return false;

      const { data, error } = await insforge.database
        .from('profiles')
        .select('role')
        .eq('id', currentUserId)
        .single();

      if (error || !data) return false;
      const isActuallyOwner = data.role === 'owner';
      if (profile && profile.role !== data.role) {
        setProfile((prev) => ({ ...prev, role: data.role }));
      }
      return isActuallyOwner;
    } catch (err) {
      console.error('Error verifying owner status:', err);
      return false;
    }
  };

  // Upsert profile only if it doesn't already exist
  const ensureProfile = async (userId, email, name, phone) => {
    try {
      const { data: existing } = await insforge.database
        .from('profiles')
        .select('id, role')
        .eq('id', userId)
        .maybeSingle();

      if (!existing) {
        const newProfile = {
          id: userId,
          email,
          name: name || '',
          phone: phone || '',
          role: 'customer',
          updated_at: new Date().toISOString()
        };
        await insforge.database.from('profiles').insert([newProfile]);
        return newProfile;
      }
      return existing;
    } catch (err) {
      console.error('Error ensuring profile:', err);
      return null;
    }
  };

  // Load existing session on mount
  useEffect(() => {
    let mounted = true;

    async function getInitialSession() {
      try {
        const { data } = await insforge.auth.getCurrentUser();
        if (data && data.user) {
          if (mounted) {
            setUser(data.user);
            await fetchProfile(data.user.id, data.user.email);
          }
        }
      } catch (err) {
        console.error('Error fetching initial session:', err);
      } finally {
        if (mounted) setLoading(false);
      }
    }

    getInitialSession();

    return () => {
      mounted = false;
    };
  }, []);

  /**
   * Sign Up — creates the account and triggers the OTP email.
   * Returns { success, pendingVerification, email, name, phone }
   * Does NOT set user/session — that happens only after verifyOtp().
   */
  const signUp = async ({ email, password, name, phone }) => {
    try {
      setLoading(true);
      const { data, error } = await insforge.auth.signUp({
        email,
        password,
        name
      });

      if (error) {
        const msg = error.message?.toLowerCase() || '';
        if (msg.includes('already registered') || msg.includes('already exists') || msg.includes('user already') || msg.includes('duplicate')) {
          addToast('An account with this email already exists. Please sign in.', 'error');
        } else {
          addToast(error.message || 'Signup failed. Please try again.', 'error');
        }
        return { success: false, error };
      }

      const signedUpUser = data?.user;
      const requiresVerification = data?.requireEmailVerification === true;

      // If email verification is not required (or auto-confirmed), log the user in immediately
      if (!requiresVerification && signedUpUser) {
        setUser(signedUpUser);
        const prof = await ensureProfile(signedUpUser.id, email, name, phone);
        if (prof) setProfile({ ...prof, name: name || '', phone: phone || '', email });
        addToast('Account created! Welcome to Navya Gift Hamper.', 'success');
        return { success: true, pendingVerification: false, user: signedUpUser };
      }

      // Verification required flow
      addToast(
        'Verification code sent to your email. Please check your inbox (and spam folder).',
        'success'
      );
      return { success: true, pendingVerification: true, email, name, phone };
    } catch (err) {
      console.error('SignUp error:', err);
      addToast(err.message || 'Failed to sign up. Please try again.', 'error');
      return { success: false, error: err };
    } finally {
      setLoading(false);
    }
  };

  /**
   * Verify OTP / Email code — calls insforge.auth.verifyEmail({ email, otp }).
   * On success: creates profile record and establishes authenticated session.
   */
  const verifyOtp = async ({ email, token, name, phone }) => {
    try {
      setLoading(true);
      const { data, error } = await insforge.auth.verifyEmail({
        email,
        otp: token.trim()
      });

      if (error) {
        const msg = error.message?.toLowerCase() || '';
        if (msg.includes('expired')) {
          addToast('Verification code has expired. Please request a new one.', 'error');
          return { success: false, error, expired: true };
        }
        if (msg.includes('invalid') || msg.includes('incorrect') || msg.includes('wrong') || msg.includes('not match')) {
          addToast('Invalid verification code. Please check and try again.', 'error');
        } else {
          addToast(error.message || 'Verification failed. Please try again.', 'error');
        }
        return { success: false, error };
      }

      const verifiedUser = data?.user;
      if (verifiedUser && verifiedUser.id) {
        setUser(verifiedUser);
        const newProfile = {
          id: verifiedUser.id,
          email,
          name: name || verifiedUser.profile?.name || '',
          phone: phone || '',
          updated_at: new Date().toISOString()
        };
        await ensureProfile(verifiedUser.id, email, newProfile.name, newProfile.phone);
        setProfile(newProfile);
      }

      addToast('Email verified! Welcome to Navya Gift Hamper 🎁', 'success');
      return { success: true, user: verifiedUser };
    } catch (err) {
      console.error('verifyOtp error:', err);
      addToast(err.message || 'Verification failed. Please try again.', 'error');
      return { success: false, error: err };
    } finally {
      setLoading(false);
    }
  };

  /**
   * Resend OTP — calls insforge.auth.resendVerificationEmail({ email }).
   */
  const resendOtp = async (email) => {
    try {
      const { error } = await insforge.auth.resendVerificationEmail({ email });
      if (error) {
        const msg = error.message?.toLowerCase() || '';
        if (msg.includes('rate') || msg.includes('limit') || msg.includes('too many') || msg.includes('interval')) {
          addToast('Please wait 60 seconds before requesting another code.', 'error');
        } else {
          addToast(error.message || 'Failed to resend code. Please try again.', 'error');
        }
        return { success: false, error };
      }
      addToast('New verification code sent! Check your inbox.', 'success');
      return { success: true };
    } catch (err) {
      console.error('resendOtp error:', err);
      addToast('Failed to resend code. Please try again.', 'error');
      return { success: false, error: err };
    }
  };

  /**
   * Sign In — authenticates with email + password.
   * Returns emailNotVerified: true for unverified accounts.
   */
  const signIn = async ({ email, password }) => {
    try {
      setLoading(true);
      const { data, error } = await insforge.auth.signInWithPassword({ email, password });

      if (error) {
        const msg = error.message?.toLowerCase() || '';
        if (msg.includes('email not confirmed') || msg.includes('not verified') || msg.includes('confirm your email')) {
          addToast('Please verify your email first. Check your inbox for the 6-digit code.', 'error');
          return { success: false, emailNotVerified: true, email, error };
        }
        addToast('Incorrect email or password. Please try again.', 'error');
        return { success: false, error };
      }

      const signedInUser = data?.user || data;
      setUser(signedInUser);
      if (signedInUser && signedInUser.id) {
        await fetchProfile(signedInUser.id, signedInUser.email);
      }

      addToast('Welcome back to Navya Gift Hamper!', 'success');
      return { success: true, user: signedInUser };
    } catch (err) {
      console.error('SignIn error:', err);
      addToast(err.message || 'Failed to sign in. Please try again.', 'error');
      return { success: false, error: err };
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      await insforge.auth.signOut();
      setUser(null);
      setProfile(null);
      addToast('Signed out successfully.', 'info');
    } catch (err) {
      console.error('SignOut error:', err);
    }
  };

  const updateProfile = async (updates) => {
    if (!user) return;
    try {
      const updatedRecord = {
        ...profile,
        ...updates,
        updated_at: new Date().toISOString()
      };

      const { error } = await insforge.database
        .from('profiles')
        .upsert([updatedRecord]);

      if (error) {
        addToast('Failed to update profile', 'error');
        return { success: false, error };
      }

      setProfile(updatedRecord);
      addToast('Profile updated successfully!', 'success');
      return { success: true };
    } catch (err) {
      console.error('Update profile error:', err);
      return { success: false, error: err };
    }
  };

  const isOwner = Boolean(
    user &&
    user.email?.toLowerCase().trim() === 'supportnavya0@gmail.com' &&
    profile?.role === 'owner'
  );

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        isOwner,
        loading,
        signUp,
        signIn,
        signOut,
        verifyOtp,
        resendOtp,
        updateProfile,
        verifyOwner
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
