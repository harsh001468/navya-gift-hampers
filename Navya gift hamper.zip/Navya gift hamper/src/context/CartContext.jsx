import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from './ToastContext';

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState(() => {
    try {
      const saved = localStorage.getItem('navya_cart');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error('Error loading cart from localStorage', e);
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [includeGiftWrap, setIncludeGiftWrap] = useState(true);
  const { addToast } = useToast();

  useEffect(() => {
    try {
      localStorage.setItem('navya_cart', JSON.stringify(cart));
    } catch (e) {
      console.error('Error saving cart to localStorage', e);
    }
  }, [cart]);

  const addToCart = (product, quantity = 1, options = {}) => {
    // Prevent adding out-of-stock products
    const stock = product.stockQuantity !== undefined ? product.stockQuantity : product.stock;
    if (product.inStock === false || (stock !== undefined && stock <= 0)) {
      addToast(`"${product.name}" is currently out of stock.`, 'error');
      return;
    }

    const selectedSize = options.size || (product.sizes && product.sizes[0]) || 'Standard';
    const selectedColor = options.color || (product.colors && product.colors[0]) || 'Default';
    const giftNote = options.giftNote || '';

    // Create unique key for item + variant
    const itemKey = `${product.id}-${selectedSize}-${selectedColor}`;

    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex((item) => item.key === itemKey);

      if (existingIndex > -1) {
        const currentQty = prevCart[existingIndex].quantity;
        const requestedTotal = currentQty + quantity;
        if (stock !== undefined && requestedTotal > stock) {
          addToast(`Cannot add more. Only ${stock} units available in stock.`, 'warning');
          return prevCart;
        }
        const updated = [...prevCart];
        updated[existingIndex].quantity = requestedTotal;
        if (giftNote) updated[existingIndex].giftNote = giftNote;
        return updated;
      } else {
        const initialQty = stock !== undefined ? Math.min(quantity, stock) : quantity;
        return [
          ...prevCart,
          {
            key: itemKey,
            productId: product.id,
            product,
            quantity: initialQty,
            selectedSize,
            selectedColor,
            giftNote
          }
        ];
      }
    });

    addToast(`"${product.name}" added to your Gift Bag`, 'success');
    setIsCartOpen(true);
  };

  const updateQuantity = (key, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(key);
      return;
    }

    setCart((prevCart) =>
      prevCart.map((item) => {
        if (item.key === key) {
          const maxStock = item.product?.stockQuantity ?? item.product?.stock;
          if (maxStock !== undefined && newQuantity > maxStock) {
            addToast(`Only ${maxStock} units available in stock.`, 'warning');
            return { ...item, quantity: maxStock };
          }
          return { ...item, quantity: newQuantity };
        }
        return item;
      })
    );
  };

  const removeFromCart = (key) => {
    setCart((prevCart) => {
      const itemToRemove = prevCart.find((item) => item.key === key);
      if (itemToRemove && itemToRemove.product) {
        addToast(`Removed "${itemToRemove.product.name}" from bag`, 'info');
      }
      return prevCart.filter((item) => item.key !== key);
    });
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const giftPackagingFee = includeGiftWrap ? 0 : 0; // Free premium packaging promo as requested!

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        cartSubtotal,
        cartItemCount,
        isCartOpen,
        setIsCartOpen,
        includeGiftWrap,
        setIncludeGiftWrap,
        giftPackagingFee
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
