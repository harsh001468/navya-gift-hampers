import { insforge } from '../lib/insforge';

/**
 * PaymentService — Modular payment handler.
 *
 * Current mode: SIMULATION
 * Future: Replace simulate* methods with real gateway calls + webhook verification.
 *
 * Architecture:
 *   PaymentService.createPayment()   → creates a "pending" payment record
 *   PaymentService.simulateSuccess() → marks payment as "paid" (demo only)
 *   PaymentService.simulateFailure() → marks payment as "failed" (demo only)
 *   PaymentService.getPayment()      → fetches payment by ID
 *   PaymentService.verifyPayment()   → placeholder for real gateway verification
 */

// Generate a simulated transaction ID: SIM-NF-YYYYMMDD-XXXXX
function generateTransactionId() {
  const now = new Date();
  const dateStr = now.getFullYear().toString() +
    String(now.getMonth() + 1).padStart(2, '0') +
    String(now.getDate()).padStart(2, '0');
  const rand = Math.floor(10000 + Math.random() * 90000);
  return `SIM-NF-${dateStr}-${rand}`;
}

export const paymentService = {
  /**
   * Create a pending payment record for an order.
   * Amount must come from the order record — never from frontend input.
   */
  async createPayment({ orderId, amount, userId }) {
    try {
      const transactionId = generateTransactionId();

      const paymentRecord = {
        order_id: orderId,
        user_id: userId || null,
        amount: amount,
        currency: 'INR',
        method: 'UPI',
        provider: 'Google Pay / UPI',
        transaction_id: transactionId,
        status: 'pending',
        is_simulation: true,
        paid_at: null
      };

      // Persist to InsForge database
      const { data, error } = await insforge.database
        .from('payments')
        .insert([paymentRecord])
        .select()
        .single();

      if (error) {
        console.error('Error creating payment record:', error);
        // Fallback: return a local payment object so the flow continues
        return {
          success: true,
          payment: {
            id: 'local-' + Date.now(),
            ...paymentRecord,
            created_at: new Date().toISOString()
          }
        };
      }

      return { success: true, payment: data };
    } catch (e) {
      console.error('PaymentService.createPayment failed:', e);
      // Return a local fallback payment
      const transactionId = generateTransactionId();
      return {
        success: true,
        payment: {
          id: 'local-' + Date.now(),
          order_id: orderId,
          user_id: userId || null,
          amount,
          currency: 'INR',
          method: 'UPI',
          provider: 'Google Pay / UPI',
          transaction_id: transactionId,
          status: 'pending',
          is_simulation: true,
          paid_at: null,
          created_at: new Date().toISOString()
        }
      };
    }
  },

  /**
   * SIMULATED payment success.
   * In production, this would be replaced by a webhook/callback from the real gateway.
   * The frontend should NEVER independently decide a real payment is successful.
   */
  async simulateSuccess(paymentId, transactionId) {
    try {
      const paidAt = new Date().toISOString();

      const { data, error } = await insforge.database
        .from('payments')
        .update({
          status: 'paid',
          paid_at: paidAt
        })
        .eq('id', paymentId)
        .select()
        .single();

      if (error) {
        console.warn('Payment update warning:', error);
        // Return success anyway for demo flow
        return {
          success: true,
          payment: {
            id: paymentId,
            transaction_id: transactionId,
            status: 'paid',
            paid_at: paidAt,
            is_simulation: true
          }
        };
      }

      return { success: true, payment: data };
    } catch (e) {
      console.error('PaymentService.simulateSuccess failed:', e);
      return {
        success: true,
        payment: {
          id: paymentId,
          transaction_id: transactionId,
          status: 'paid',
          paid_at: new Date().toISOString(),
          is_simulation: true
        }
      };
    }
  },

  /**
   * SIMULATED payment failure.
   */
  async simulateFailure(paymentId) {
    try {
      const { data, error } = await insforge.database
        .from('payments')
        .update({ status: 'failed' })
        .eq('id', paymentId)
        .select()
        .single();

      if (error) {
        console.warn('Payment failure update warning:', error);
      }

      return {
        success: true,
        payment: data || { id: paymentId, status: 'failed', is_simulation: true }
      };
    } catch (e) {
      console.error('PaymentService.simulateFailure failed:', e);
      return {
        success: true,
        payment: { id: paymentId, status: 'failed', is_simulation: true }
      };
    }
  },

  /**
   * Fetch a payment record by ID.
   */
  async getPayment(paymentId) {
    try {
      const { data, error } = await insforge.database
        .from('payments')
        .select('*')
        .eq('id', paymentId)
        .single();

      if (error || !data) {
        return null;
      }
      return data;
    } catch (e) {
      console.error('PaymentService.getPayment failed:', e);
      return null;
    }
  },

  /**
   * Get payment by order ID.
   */
  async getPaymentByOrderId(orderId) {
    try {
      const { data, error } = await insforge.database
        .from('payments')
        .select('*')
        .eq('order_id', orderId)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error || !data) {
        return null;
      }
      return data;
    } catch (e) {
      console.error('PaymentService.getPaymentByOrderId failed:', e);
      return null;
    }
  },

  /**
   * PLACEHOLDER: Verify payment with real gateway.
   * In production, this would call the payment provider's API to confirm payment status.
   * The frontend should NEVER call this directly — it should be a backend operation.
   */
  async verifyPayment(transactionId) {
    // Placeholder — always returns the current DB status
    try {
      const { data, error } = await insforge.database
        .from('payments')
        .select('*')
        .eq('transaction_id', transactionId)
        .single();

      if (error || !data) {
        return { verified: false, status: 'unknown' };
      }
      return { verified: data.status === 'paid', status: data.status, payment: data };
    } catch {
      return { verified: false, status: 'error' };
    }
  }
};
