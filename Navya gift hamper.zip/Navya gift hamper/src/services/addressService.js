import { insforge } from '../lib/insforge';

export const addressService = {
  // Fetch all saved addresses for the authenticated user
  async getUserAddresses(userId) {
    if (!userId) return [];
    try {
      const { data, error } = await insforge.database
        .from('addresses')
        .select('*')
        .eq('user_id', userId)
        .order('is_default', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching addresses from InsForge:', error);
        return [];
      }
      return data || [];
    } catch (e) {
      console.error('Failed to fetch addresses:', e);
      return [];
    }
  },

  // Add a new address
  async addAddress(userId, addressData) {
    if (!userId) return { success: false, error: 'Authentication required' };
    try {
      const payload = {
        user_id: userId,
        name: addressData.name?.trim(),
        phone: addressData.phone?.trim(),
        street: addressData.street?.trim(),
        apartment: addressData.apartment?.trim() || null,
        city: addressData.city?.trim(),
        state: addressData.state?.trim(),
        pincode: addressData.pincode?.trim(),
        is_default: Boolean(addressData.is_default)
      };

      // If set as default, reset any previous default for this user
      if (payload.is_default) {
        await insforge.database
          .from('addresses')
          .update({ is_default: false })
          .eq('user_id', userId);
      }

      const { data, error } = await insforge.database
        .from('addresses')
        .insert([payload])
        .select()
        .single();

      if (error) {
        console.error('Error adding address:', error);
        return { success: false, error: error.message };
      }

      return { success: true, address: data };
    } catch (e) {
      console.error('Failed to add address:', e);
      return { success: false, error: e.message };
    }
  },

  // Update an existing address
  async updateAddress(userId, addressId, addressData) {
    if (!userId || !addressId) return { success: false, error: 'Invalid parameters' };
    try {
      const payload = {
        name: addressData.name?.trim(),
        phone: addressData.phone?.trim(),
        street: addressData.street?.trim(),
        apartment: addressData.apartment?.trim() || null,
        city: addressData.city?.trim(),
        state: addressData.state?.trim(),
        pincode: addressData.pincode?.trim(),
        is_default: Boolean(addressData.is_default),
        updated_at: new Date().toISOString()
      };

      if (payload.is_default) {
        await insforge.database
          .from('addresses')
          .update({ is_default: false })
          .eq('user_id', userId);
      }

      const { data, error } = await insforge.database
        .from('addresses')
        .update(payload)
        .eq('id', addressId)
        .eq('user_id', userId)
        .select()
        .single();

      if (error) {
        console.error('Error updating address:', error);
        return { success: false, error: error.message };
      }

      return { success: true, address: data };
    } catch (e) {
      console.error('Failed to update address:', e);
      return { success: false, error: e.message };
    }
  },

  // Delete an address
  async deleteAddress(userId, addressId) {
    if (!userId || !addressId) return { success: false, error: 'Invalid parameters' };
    try {
      const { error } = await insforge.database
        .from('addresses')
        .delete()
        .eq('id', addressId)
        .eq('user_id', userId);

      if (error) {
        console.error('Error deleting address:', error);
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (e) {
      console.error('Failed to delete address:', e);
      return { success: false, error: e.message };
    }
  },

  // Set default address
  async setDefaultAddress(userId, addressId) {
    if (!userId || !addressId) return { success: false, error: 'Invalid parameters' };
    try {
      await insforge.database
        .from('addresses')
        .update({ is_default: false })
        .eq('user_id', userId);

      const { data, error } = await insforge.database
        .from('addresses')
        .update({ is_default: true, updated_at: new Date().toISOString() })
        .eq('id', addressId)
        .eq('user_id', userId)
        .select()
        .single();

      if (error) {
        console.error('Error setting default address:', error);
        return { success: false, error: error.message };
      }

      return { success: true, address: data };
    } catch (e) {
      console.error('Failed to set default address:', e);
      return { success: false, error: e.message };
    }
  }
};
