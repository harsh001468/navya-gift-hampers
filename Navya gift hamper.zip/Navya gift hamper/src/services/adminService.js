import { insforge } from '../lib/insforge';

// Broadcast helper for real-time synchronization across Admin Panel and Customer Website
const broadcastSync = (type, payload = {}) => {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('navya:data_sync', {
        detail: { type, payload, timestamp: Date.now() }
      })
    );
  }
};

export const adminService = {
  // ─── DASHBOARD METRICS ───────────────────────────────────────────────────
  async getDashboardMetrics() {
    try {
      // 1. Fetch Orders summary
      const { data: orders, error: ordersErr } = await insforge.database
        .from('orders')
        .select('id, order_number, total_amount, status, payment_status, created_at, customer_name, customer_email, customer_phone')
        .order('created_at', { ascending: false });

      if (ordersErr) console.error('Error fetching orders for dashboard:', ordersErr);

      const allOrders = orders || [];
      const totalOrders = allOrders.length;
      const pendingOrders = allOrders.filter(
        (o) => (o.status || '').toLowerCase() === 'pending'
      ).length;
      const processingOrders = allOrders.filter((o) =>
        ['processing', 'confirmed', 'packed'].includes((o.status || '').toLowerCase())
      ).length;
      const deliveredOrders = allOrders.filter(
        (o) => (o.status || '').toLowerCase() === 'delivered'
      ).length;

      // Revenue: sum of paid orders (or total if payment_status is 'paid' or 'completed')
      const totalRevenue = allOrders
        .filter((o) => (o.payment_status || '').toLowerCase() === 'paid')
        .reduce((sum, o) => sum + (Number(o.total_amount) || 0), 0);

      // 2. Fetch Products count and low stock
      const { data: products, error: prodErr } = await insforge.database
        .from('products')
        .select('id, name, price, stock_quantity, in_stock, category, images, status, is_archived');

      if (prodErr) console.error('Error fetching products for dashboard:', prodErr);

      const allProducts = (products || []).filter((p) => !p.is_archived);
      const totalProducts = allProducts.length;

      // Get low stock threshold from settings (fallback 5)
      let lowStockThreshold = 5;
      try {
        const { data: invSetting } = await insforge.database
          .from('store_settings')
          .select('data')
          .eq('id', 'inventory')
          .maybeSingle();
        if (invSetting?.data?.low_stock_threshold) {
          lowStockThreshold = Number(invSetting.data.low_stock_threshold);
        }
      } catch (err) {
        console.warn('Could not read low stock setting:', err);
      }

      const lowStockProducts = allProducts.filter((p) => {
        const stock = p.stock_quantity !== undefined && p.stock_quantity !== null
          ? Number(p.stock_quantity)
          : (p.in_stock ? 20 : 0);
        return stock <= lowStockThreshold || p.in_stock === false;
      });

      // 3. Fetch Customers count
      const { count: totalCustomers, error: custErr } = await insforge.database
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      if (custErr) console.error('Error fetching customer count:', custErr);

      // 4. Recent orders (top 6)
      const recentOrders = allOrders.slice(0, 6);

      // 5. Sales chart data calculation (Last 7 days, 30 days, 6 months)
      const now = new Date();

      // Last 7 days buckets
      const last7Days = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(d.getDate() - i);
        const dayStr = d.toISOString().split('T')[0];
        const dayLabel = d.toLocaleDateString('en-US', { weekday: 'short', month: 'numeric', day: 'numeric' });
        const ordersOnDay = allOrders.filter((o) => o.created_at && o.created_at.startsWith(dayStr));
        const rev = ordersOnDay
          .filter((o) => (o.payment_status || '').toLowerCase() === 'paid')
          .reduce((sum, o) => sum + (Number(o.total_amount) || 0), 0);
        last7Days.push({ label: dayLabel, date: dayStr, revenue: rev, count: ordersOnDay.length });
      }

      // Last 30 days buckets (grouped into 6 5-day intervals)
      const last30Days = [];
      for (let i = 29; i >= 0; i -= 5) {
        const dStart = new Date(now);
        dStart.setDate(dStart.getDate() - i);
        const dEnd = new Date(dStart);
        dEnd.setDate(dEnd.getDate() + 4);
        const startStr = dStart.toISOString().split('T')[0];
        const label = `${dStart.getDate()} ${dStart.toLocaleDateString('en-US', { month: 'short' })}`;
        const ordersInSpan = allOrders.filter((o) => {
          if (!o.created_at) return false;
          const oDate = new Date(o.created_at);
          return oDate >= dStart && oDate <= dEnd;
        });
        const rev = ordersInSpan
          .filter((o) => (o.payment_status || '').toLowerCase() === 'paid')
          .reduce((sum, o) => sum + (Number(o.total_amount) || 0), 0);
        last30Days.push({ label, revenue: rev, count: ordersInSpan.length });
      }

      // Last 6 months buckets
      const last6Months = [];
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const monthYear = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        const label = d.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
        const ordersInMonth = allOrders.filter((o) => o.created_at && o.created_at.startsWith(monthYear));
        const rev = ordersInMonth
          .filter((o) => (o.payment_status || '').toLowerCase() === 'paid')
          .reduce((sum, o) => sum + (Number(o.total_amount) || 0), 0);
        last6Months.push({ label, revenue: rev, count: ordersInMonth.length });
      }

      return {
        success: true,
        stats: {
          totalOrders,
          pendingOrders,
          processingOrders,
          deliveredOrders,
          totalProducts,
          totalCustomers: totalCustomers || 0,
          totalRevenue,
          lowStockThreshold
        },
        recentOrders,
        lowStockProducts,
        salesTrends: {
          last7Days,
          last30Days,
          last6Months
        }
      };
    } catch (err) {
      console.error('Failed to get dashboard metrics:', err);
      return {
        success: false,
        error: err.message || 'Failed to aggregate dashboard metrics',
        stats: {
          totalOrders: 0,
          pendingOrders: 0,
          processingOrders: 0,
          deliveredOrders: 0,
          totalProducts: 0,
          totalCustomers: 0,
          totalRevenue: 0,
          lowStockThreshold: 5
        },
        recentOrders: [],
        lowStockProducts: [],
        salesTrends: { last7Days: [], last30Days: [], last6Months: [] }
      };
    }
  },

  // ─── PRODUCTS MANAGEMENT ─────────────────────────────────────────────────
  async getProducts({ search = '', category = '', status = 'all', lowStock = false, page = 1, pageSize = 20 } = {}) {
    try {
      let query = insforge.database
        .from('products')
        .select('*', { count: 'exact' });

      // Exclude archived by default unless specifically requested
      if (status === 'archived') {
        query = query.eq('is_archived', true);
      } else {
        query = query.eq('is_archived', false);
        if (status === 'active') {
          query = query.eq('in_stock', true);
        } else if (status === 'disabled') {
          query = query.eq('in_stock', false);
        }
      }

      if (category && category !== 'all') {
        query = query.ilike('category', `%${category}%`);
      }

      if (search && search.trim()) {
        const q = search.trim();
        query = query.or(`name.ilike.%${q}%,category.ilike.%${q}%,sku.ilike.%${q}%`);
      }

      query = query.order('id', { ascending: false });

      // Pagination
      const from = (page - 1) * pageSize;
      const to = from + pageSize - 1;
      query = query.range(from, to);

      const { data, count, error } = await query;
      if (error) throw error;

      let filtered = data || [];
      if (lowStock) {
        filtered = filtered.filter((p) => {
          const qty = p.stock_quantity !== undefined && p.stock_quantity !== null
            ? Number(p.stock_quantity)
            : (p.in_stock ? 20 : 0);
          return qty <= 5 || p.in_stock === false;
        });
      }

      return {
        products: filtered,
        total: count || filtered.length,
        page,
        pageSize
      };
    } catch (err) {
      console.error('Error fetching admin products:', err);
      return { products: [], total: 0, page: 1, pageSize };
    }
  },

  async getProductById(id) {
    try {
      const { data, error } = await insforge.database
        .from('products')
        .select('*')
        .eq('id', Number(id))
        .single();

      if (error) throw error;
      return data;
    } catch (err) {
      console.error('Error fetching product for edit:', err);
      return null;
    }
  },

  async createProduct(productData) {
    try {
      // Validate non-negative numbers
      const price = Number(productData.price);
      const stock = Number(productData.stock_quantity || 0);
      const originalPrice = productData.original_price ? Number(productData.original_price) : null;
      let discountPercentage = Number(productData.discount_percentage || 0);
      if ((!discountPercentage || isNaN(discountPercentage)) && originalPrice && originalPrice > price) {
        discountPercentage = Math.round(((originalPrice - price) / originalPrice) * 100);
      }

      if (isNaN(price) || price < 0) {
        return { success: false, error: 'Product price must be a non-negative number.' };
      }
      if (isNaN(stock) || stock < 0) {
        return { success: false, error: 'Stock quantity cannot be negative.' };
      }
      if (!productData.name || !productData.name.trim()) {
        return { success: false, error: 'Product name is required.' };
      }

      const payload = {
        name: productData.name.trim(),
        category: productData.category?.trim() || 'Gifts',
        subcategory: productData.subcategory?.trim() || 'Hampers',
        gender: productData.gender || 'Unisex',
        price,
        original_price: originalPrice,
        discount_percentage: discountPercentage,
        description: productData.description?.trim() || '',
        full_description: productData.full_description?.trim() || productData.description?.trim() || '',
        stock_quantity: stock,
        sku: productData.sku?.trim() || `NVY-${Date.now().toString().slice(-6)}`,
        images: Array.isArray(productData.images) && productData.images.length > 0
          ? productData.images
          : ['https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&q=80'],
        is_featured: !!productData.is_featured,
        is_new: !!productData.is_new,
        is_bestseller: !!productData.is_bestseller,
        in_stock: stock > 0 && productData.status !== 'disabled' && productData.status !== 'archived',
        status: productData.status || (stock > 0 ? 'active' : 'disabled'),
        is_archived: productData.status === 'archived',
        sizes: Array.isArray(productData.sizes) ? productData.sizes : ['Standard'],
        colors: Array.isArray(productData.colors) ? productData.colors : ['Default'],
        tags: Array.isArray(productData.tags) ? productData.tags : ['Gift'],
        specifications: Array.isArray(productData.specifications) ? productData.specifications : [],
        weight_size: productData.weight_size || '',
        delivery_info: productData.delivery_info || 'Standard 7–15 days delivery across India. Protective gift hamper packaging.',
        personalization_options: productData.personalization_options || { allow_name: true, allow_note: true }
      };

      const { data, error } = await insforge.database
        .from('products')
        .insert([payload])
        .select()
        .single();

      if (error) throw error;
      broadcastSync('products', { action: 'create', id: data?.id });
      return { success: true, product: data };
    } catch (err) {
      console.error('Error creating product:', err);
      return { success: false, error: err.message || 'Failed to create product' };
    }
  },

  async updateProduct(id, productData) {
    try {
      const price = Number(productData.price);
      const stock = Number(productData.stock_quantity ?? 0);
      const originalPrice = productData.original_price ? Number(productData.original_price) : null;
      let discountPercentage = Number(productData.discount_percentage || 0);
      if ((!discountPercentage || isNaN(discountPercentage)) && originalPrice && originalPrice > price) {
        discountPercentage = Math.round(((originalPrice - price) / originalPrice) * 100);
      }

      if (isNaN(price) || price < 0) {
        return { success: false, error: 'Product price must be a non-negative number.' };
      }
      if (isNaN(stock) || stock < 0) {
        return { success: false, error: 'Stock quantity cannot be negative.' };
      }

      const updatePayload = {
        name: productData.name?.trim(),
        category: productData.category?.trim(),
        subcategory: productData.subcategory?.trim(),
        gender: productData.gender,
        price,
        original_price: originalPrice,
        discount_percentage: discountPercentage,
        description: productData.description?.trim(),
        full_description: productData.full_description?.trim(),
        stock_quantity: stock,
        sku: productData.sku?.trim(),
        images: productData.images,
        is_featured: !!productData.is_featured,
        is_new: !!productData.is_new,
        is_bestseller: !!productData.is_bestseller,
        in_stock: stock > 0 && productData.status !== 'disabled' && productData.status !== 'archived',
        status: productData.status || (stock > 0 ? 'active' : 'disabled'),
        updated_at: new Date().toISOString()
      };

      if (productData.sizes !== undefined) updatePayload.sizes = productData.sizes;
      if (productData.colors !== undefined) updatePayload.colors = productData.colors;
      if (productData.tags !== undefined) updatePayload.tags = productData.tags;
      if (productData.specifications !== undefined) updatePayload.specifications = productData.specifications;
      if (productData.weight_size !== undefined) updatePayload.weight_size = productData.weight_size;
      if (productData.delivery_info !== undefined) updatePayload.delivery_info = productData.delivery_info;
      if (productData.personalization_options !== undefined) updatePayload.personalization_options = productData.personalization_options;
      if (productData.is_archived !== undefined) updatePayload.is_archived = productData.is_archived;

      const { data, error } = await insforge.database
        .from('products')
        .update(updatePayload)
        .eq('id', Number(id))
        .select()
        .single();

      if (error) throw error;
      broadcastSync('products', { action: 'update', id: Number(id) });
      return { success: true, product: data };
    } catch (err) {
      console.error('Error updating product:', err);
      return { success: false, error: err.message || 'Failed to update product' };
    }
  },

  async toggleProductStatus(id, currentlyEnabled) {
    try {
      const newInStock = !currentlyEnabled;
      const { error } = await insforge.database
        .from('products')
        .update({
          in_stock: newInStock,
          status: newInStock ? 'active' : 'disabled',
          updated_at: new Date().toISOString()
        })
        .eq('id', Number(id));

      if (error) throw error;
      broadcastSync('products', { action: 'toggle', id: Number(id), inStock: newInStock });
      return { success: true, inStock: newInStock };
    } catch (err) {
      console.error('Error toggling product status:', err);
      return { success: false, error: err.message };
    }
  },

  async updateStock(id, newStock) {
    try {
      const stock = Number(newStock);
      if (isNaN(stock) || stock < 0) {
        return { success: false, error: 'Stock quantity cannot be negative.' };
      }
      const inStock = stock > 0;
      const { error } = await insforge.database
        .from('products')
        .update({
          stock_quantity: stock,
          in_stock: inStock,
          status: inStock ? 'active' : 'disabled',
          updated_at: new Date().toISOString()
        })
        .eq('id', Number(id));

      if (error) throw error;
      broadcastSync('products', { action: 'stock', id: Number(id), stock, inStock });
      return { success: true, stock, inStock };
    } catch (err) {
      console.error('Error updating stock:', err);
      return { success: false, error: err.message };
    }
  },

  async archiveProduct(id) {
    return this.deleteProduct(id, true);
  },

  async restoreProduct(id) {
    try {
      const { data: current } = await insforge.database
        .from('products')
        .select('stock_quantity')
        .eq('id', Number(id))
        .single();

      const stock = current?.stock_quantity ?? 10;
      const inStock = stock > 0;

      const { error } = await insforge.database
        .from('products')
        .update({
          is_archived: false,
          status: inStock ? 'active' : 'disabled',
          in_stock: inStock,
          updated_at: new Date().toISOString()
        })
        .eq('id', Number(id));

      if (error) throw error;
      broadcastSync('products', { action: 'restore', id: Number(id) });
      return { success: true };
    } catch (err) {
      console.error('Error restoring product:', err);
      return { success: false, error: err.message || 'Failed to restore product' };
    }
  },

  async deleteProduct(id, softDelete = true) {
    try {
      if (softDelete) {
        // Soft delete archives the product so historical orders linking to it don't break
        const { error } = await insforge.database
          .from('products')
          .update({
            is_archived: true,
            in_stock: false,
            status: 'archived',
            updated_at: new Date().toISOString()
          })
          .eq('id', Number(id));

        if (error) throw error;
        broadcastSync('products', { action: 'archive', id: Number(id) });
        return { success: true };
      } else {
        const { error } = await insforge.database
          .from('products')
          .delete()
          .eq('id', Number(id));

        if (error) throw error;
        broadcastSync('products', { action: 'delete', id: Number(id) });
        return { success: true };
      }
    } catch (err) {
      console.error('Error deleting product:', err);
      return { success: false, error: err.message || 'Failed to delete product' };
    }
  },

  async uploadProductImage(file) {
    try {
      if (!file) throw new Error('No file provided');

      const fileExt = file.name.split('.').pop() || 'jpg';
      const fileName = `prod_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${fileExt}`;
      const filePath = `products/${fileName}`;

      const { data, error } = await insforge.storage
        .from('product-images')
        .upload(filePath, file);

      if (error) throw error;

      // Obtain public URL
      const { data: urlData } = insforge.storage
        .from('product-images')
        .getPublicUrl(filePath);

      return {
        success: true,
        url: urlData?.publicUrl || data?.url,
        key: filePath
      };
    } catch (err) {
      console.error('Error uploading product image:', err);
      return { success: false, error: err.message || 'Image upload failed' };
    }
  },

  // ─── CATEGORIES MANAGEMENT ──────────────────────────────────────────────
  async getAllCategories() {
    try {
      const { data, error } = await insforge.database
        .from('categories')
        .select('*')
        .order('display_order', { ascending: true })
        .order('name', { ascending: true });

      if (error) throw error;
      return data || [];
    } catch (err) {
      console.error('Error fetching categories:', err);
      return [];
    }
  },

  async createCategory({ name, description, image, is_active = true }) {
    try {
      if (!name || !name.trim()) {
        return { success: false, error: 'Category name is required.' };
      }
      const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

      // Check if duplicate name or slug exists
      const { data: existing } = await insforge.database
        .from('categories')
        .select('id')
        .or(`name.ilike.${name.trim()},slug.eq.${slug}`)
        .maybeSingle();

      if (existing) {
        return { success: false, error: 'A category with this name or slug already exists.' };
      }

      const payload = {
        name: name.trim(),
        slug,
        description: description?.trim() || '',
        image: image?.trim() || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&q=80',
        is_active: is_active !== false,
        display_order: 10
      };

      const { data, error } = await insforge.database
        .from('categories')
        .insert([payload])
        .select()
        .single();

      if (error) throw error;
      broadcastSync('categories', { action: 'create', category: data });
      return { success: true, category: data };
    } catch (err) {
      console.error('Error creating category:', err);
      return { success: false, error: err.message || 'Failed to create category' };
    }
  },

  async updateCategory(id, updates) {
    try {
      const payload = { ...updates, updated_at: new Date().toISOString() };
      if (updates.name) {
        payload.name = updates.name.trim();
        payload.slug = updates.name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      }

      const { data, error } = await insforge.database
        .from('categories')
        .update(payload)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      broadcastSync('categories', { action: 'update', id, category: data });
      return { success: true, category: data };
    } catch (err) {
      console.error('Error updating category:', err);
      return { success: false, error: err.message || 'Failed to update category' };
    }
  },

  async deleteCategory(id) {
    try {
      const { error } = await insforge.database
        .from('categories')
        .delete()
        .eq('id', id);

      if (error) throw error;
      broadcastSync('categories', { action: 'delete', id });
      return { success: true };
    } catch (err) {
      console.error('Error deleting category:', err);
      return { success: false, error: err.message || 'Failed to delete category' };
    }
  },

  // ─── ORDERS MANAGEMENT ──────────────────────────────────────────────────
  async getOrders({ search = '', status = 'all', paymentStatus = 'all', page = 1, pageSize = 20 } = {}) {
    try {
      let query = insforge.database
        .from('orders')
        .select('*', { count: 'exact' });

      if (status && status !== 'all') {
        query = query.ilike('status', `%${status}%`);
      }

      if (paymentStatus && paymentStatus !== 'all') {
        query = query.ilike('payment_status', `%${paymentStatus}%`);
      }

      if (search && search.trim()) {
        const q = search.trim();
        query = query.or(`order_number.ilike.%${q}%,customer_name.ilike.%${q}%,customer_email.ilike.%${q}%,customer_phone.ilike.%${q}%`);
      }

      query = query.order('created_at', { ascending: false });

      const from = (page - 1) * pageSize;
      const to = from + pageSize - 1;
      query = query.range(from, to);

      const { data: rawOrders, count, error } = await query;
      if (error) throw error;

      // Populate order_items for these orders
      const orders = await Promise.all(
        (rawOrders || []).map(async (order) => {
          const { data: items } = await insforge.database
            .from('order_items')
            .select('*')
            .eq('order_id', order.id);

          return {
            ...order,
            items: items || []
          };
        })
      );

      return {
        orders,
        total: count || orders.length,
        page,
        pageSize
      };
    } catch (err) {
      console.error('Error fetching admin orders:', err);
      return { orders: [], total: 0, page: 1, pageSize };
    }
  },

  async updateOrderStatus(orderId, newStatus, trackingNumber = null) {
    const validStatuses = ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled'];
    const matched = validStatuses.find((s) => s.toLowerCase() === newStatus.toLowerCase());
    if (!matched) {
      return { success: false, error: `Invalid order status. Allowed: ${validStatuses.join(', ')}` };
    }

    try {
      const updatePayload = {
        status: matched
      };

      if (trackingNumber) {
        updatePayload.tracking_number = trackingNumber.trim();
      }

      // If marked delivered, update estimated_delivery
      if (matched === 'Delivered') {
        updatePayload.estimated_delivery = 'Delivered';
      }

      const { error } = await insforge.database
        .from('orders')
        .update(updatePayload)
        .eq('id', orderId);

      if (error) throw error;
      broadcastSync('orders', { action: 'status', orderId, status: matched, trackingNumber });
      return { success: true, status: matched };
    } catch (err) {
      console.error('Error updating order status:', err);
      return { success: false, error: err.message || 'Failed to update order status' };
    }
  },

  async updateOrderPaymentStatus(orderId, paymentStatus) {
    try {
      const updatePayload = {
        payment_status: paymentStatus
      };
      if (paymentStatus === 'paid') {
        updatePayload.paid_at = new Date().toISOString();
      }

      const { error } = await insforge.database
        .from('orders')
        .update(updatePayload)
        .eq('id', orderId);

      if (error) throw error;
      broadcastSync('orders', { action: 'payment', orderId, paymentStatus });
      return { success: true };
    } catch (err) {
      console.error('Error updating payment status:', err);
      return { success: false, error: err.message };
    }
  },

  // ─── CUSTOMERS MANAGEMENT ───────────────────────────────────────────────
  async getCustomers({ search = '', page = 1, pageSize = 20 } = {}) {
    try {
      let query = insforge.database
        .from('profiles')
        .select('*', { count: 'exact' });

      if (search && search.trim()) {
        const q = search.trim();
        query = query.or(`name.ilike.%${q}%,email.ilike.%${q}%,phone.ilike.%${q}%`);
      }

      query = query.order('created_at', { ascending: false });

      const from = (page - 1) * pageSize;
      const to = from + pageSize - 1;
      query = query.range(from, to);

      const { data: profiles, count, error } = await query;
      if (error) throw error;

      // For each customer, aggregate order count & total spending
      const { data: orders } = await insforge.database
        .from('orders')
        .select('id, user_id, customer_email, total_amount, payment_status, created_at');

      const allOrders = orders || [];

      const enriched = (profiles || []).map((prof) => {
        const userOrders = allOrders.filter(
          (o) => (o.user_id && o.user_id === prof.id) || (o.customer_email && o.customer_email.toLowerCase() === (prof.email || '').toLowerCase())
        );
        const orderCount = userOrders.length;
        const totalSpending = userOrders
          .filter((o) => (o.payment_status || '').toLowerCase() === 'paid')
          .reduce((sum, o) => sum + (Number(o.total_amount) || 0), 0);

        return {
          id: prof.id,
          name: prof.name || 'Valued Customer',
          email: prof.email,
          phone: prof.phone || '—',
          role: prof.role || 'customer',
          orderCount,
          totalSpending,
          createdAt: prof.created_at,
          orders: userOrders
        };
      });

      return {
        customers: enriched,
        total: count || enriched.length,
        page,
        pageSize
      };
    } catch (err) {
      console.error('Error fetching customers:', err);
      return { customers: [], total: 0, page: 1, pageSize };
    }
  },

  // ─── REVIEWS MANAGEMENT ──────────────────────────────────────────────────
  async getReviews({ status = 'all', page = 1, pageSize = 20 } = {}) {
    try {
      let query = insforge.database
        .from('reviews')
        .select('*', { count: 'exact' });

      if (status && status !== 'all') {
        query = query.eq('status', status);
      }

      query = query.order('created_at', { ascending: false });

      const from = (page - 1) * pageSize;
      const to = from + pageSize - 1;
      query = query.range(from, to);

      const { data: rawReviews, count, error } = await query;
      if (error) throw error;

      // Enrich with product names
      const productIds = Array.from(new Set((rawReviews || []).map((r) => r.product_id).filter(Boolean)));
      let productMap = {};
      if (productIds.length > 0) {
        const { data: prods } = await insforge.database
          .from('products')
          .select('id, name')
          .in('id', productIds);
        if (prods) {
          prods.forEach((p) => {
            productMap[p.id] = p.name;
          });
        }
      }

      const reviews = (rawReviews || []).map((r) => ({
        ...r,
        product_name: r.product_id ? productMap[r.product_id] || `Product #${r.product_id}` : 'General Store Review'
      }));

      return {
        reviews,
        total: count || reviews.length,
        page,
        pageSize
      };
    } catch (err) {
      console.error('Error fetching reviews:', err);
      return { reviews: [], total: 0, page: 1, pageSize };
    }
  },

  async updateReviewStatus(reviewId, status) {
    const valid = ['approved', 'rejected', 'pending'];
    if (!valid.includes(status)) {
      return { success: false, error: 'Invalid review status' };
    }
    try {
      const { error } = await insforge.database
        .from('reviews')
        .update({ status })
        .eq('id', reviewId);

      if (error) throw error;
      broadcastSync('reviews', { reviewId, status });
      return { success: true, status };
    } catch (err) {
      console.error('Error updating review status:', err);
      return { success: false, error: err.message };
    }
  },

  async deleteReview(reviewId) {
    try {
      const { error } = await insforge.database
        .from('reviews')
        .delete()
        .eq('id', reviewId);

      if (error) throw error;
      broadcastSync('reviews', { reviewId, deleted: true });
      return { success: true };
    } catch (err) {
      console.error('Error deleting review:', err);
      return { success: false, error: err.message };
    }
  },

  // ─── STORE SETTINGS ──────────────────────────────────────────────────────
  async getSettings() {
    try {
      const { data, error } = await insforge.database
        .from('store_settings')
        .select('*');

      if (error) throw error;

      const settingsObj = {
        general: {
          store_name: 'Navya Gift Hamper',
          email: 'Supportnavya0@gmail.com',
          phone: '+91 97728 48274',
          instagram: '@navyagift_hamper',
          address: 'Jaipur, Rajasthan, India',
          tagline: 'Bespoke Engraving & Luxury Personalized Gifts'
        },
        delivery: {
          standard_fee: 0,
          express_fee: 149,
          free_shipping_threshold: 999,
          estimated_days: '7–15 Days'
        },
        inventory: {
          low_stock_threshold: 5
        },
        orders: {
          allow_notes: true,
          auto_invoice: true
        }
      };

      if (data) {
        data.forEach((row) => {
          if (row.id && row.data) {
            settingsObj[row.id] = { ...settingsObj[row.id], ...row.data };
          }
        });
      }

      return { success: true, settings: settingsObj };
    } catch (err) {
      console.error('Error loading settings:', err);
      return { success: false, error: err.message };
    }
  },

  async updateSettings(sectionKey, data) {
    try {
      const { error } = await insforge.database
        .from('store_settings')
        .upsert([
          {
            id: sectionKey,
            data,
            updated_at: new Date().toISOString()
          }
        ]);

      if (error) throw error;
      broadcastSync('store_settings', { sectionKey, data });
      return { success: true };
    } catch (err) {
      console.error('Error saving settings:', err);
      return { success: false, error: err.message };
    }
  }
};
