import { insforge } from '../lib/insforge';

export const orderService = {
  // Create order with database persistence — strictly requires authentication
  async createOrder(orderData) {
    try {
      const orderNumber = 'NAVYA-' + Math.floor(100000 + Math.random() * 900000);

      const orderPayload = {
        order_number: orderNumber,
        user_id: orderData.userId || null,
        customer_name: orderData.customer?.name?.trim(),
        customer_email: orderData.customer?.email?.trim(),
        customer_phone: orderData.customer?.phone?.trim(),
        shipping_address: orderData.shippingAddress,
        delivery_method: orderData.deliveryMethod || 'Standard',
        payment_method: orderData.paymentMethod || 'UPI',
        subtotal: orderData.subtotal,
        discount: orderData.discount || 0,
        shipping_fee: orderData.shippingFee || 0,
        gift_packaging_fee: orderData.giftPackagingFee || 0,
        total_amount: orderData.totalAmount,
        // Payment fields — start as pending, updated after payment
        payment_status: 'pending',
        transaction_id: null,
        paid_at: null,
        status: 'Pending',
        tracking_number: 'NVY' + Math.floor(10000000 + Math.random() * 90000000),
        estimated_delivery: '7–15 Days'
      };

      // 2. Insert order record into database
      const { data: insertedOrder, error: orderError } = await insforge.database
        .from('orders')
        .insert([orderPayload])
        .select()
        .single();

      if (orderError || !insertedOrder) {
        console.error('Error inserting order into InsForge DB:', orderError);
        return {
          success: false,
          error: orderError?.message || 'Failed to initialize order record.'
        };
      }

      const createdOrderId = insertedOrder.id;

      // 3. Insert order items
      if (orderData.items && orderData.items.length > 0) {
        const orderItems = orderData.items.map((item) => ({
          order_id: createdOrderId,
          product_id: item.productId || item.product?.id || null,
          product_name: item.product?.name || 'Luxury Gift Hamper',
          product_image: item.product?.images?.[0] || '',
          quantity: item.quantity || 1,
          selected_size: item.selectedSize || 'Standard',
          selected_color: item.selectedColor || 'Default',
          price: item.product?.price || 0,
          gift_note: item.giftNote || ''
        }));

        const { error: itemsError } = await insforge.database
          .from('order_items')
          .insert(orderItems);

        if (itemsError) {
          console.error('Error inserting order items, performing atomic rollback:', itemsError);
          // Roll back inserted order to prevent orphaned records
          await insforge.database.from('orders').delete().eq('id', createdOrderId);
          return {
            success: false,
            error: 'Failed to record order items. Transaction rolled back safely.'
          };
        }
      }

      const finalOrder = {
        orderId: orderNumber,
        id: createdOrderId,
        date: insertedOrder.created_at || new Date().toISOString(),
        items: orderData.items,
        shippingAddress: orderData.shippingAddress,
        customer: orderData.customer,
        deliveryMethod: orderData.deliveryMethod,
        paymentMethod: orderData.paymentMethod,
        subtotal: orderData.subtotal,
        discount: orderData.discount || 0,
        shippingFee: orderData.shippingFee || 0,
        totalAmount: orderData.totalAmount,
        paymentStatus: 'pending',
        transactionId: null,
        status: 'Pending',
        trackingNumber: orderPayload.tracking_number,
        estimatedDelivery: orderPayload.estimated_delivery
      };

      return { success: true, order: finalOrder };
    } catch (e) {
      console.error('Failed to create order:', e);
      return { success: false, error: e.message };
    }
  },

  /**
   * Update order after successful payment.
   */
  async updateOrderPayment(orderId, paymentData) {
    try {
      const updatePayload = {
        status: 'Confirmed',
        payment_status: 'paid',
        payment_method: paymentData.method || 'Google Pay / UPI',
        transaction_id: paymentData.transactionId,
        paid_at: paymentData.paidAt || new Date().toISOString()
      };

      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(orderId);
      let query = insforge.database.from('orders').update(updatePayload);

      if (isUUID) {
        query = query.eq('id', orderId);
      } else {
        query = query.eq('order_number', orderId);
      }

      const { error } = await query;
      if (error) {
        console.error('Error updating order payment in DB:', error);
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (e) {
      console.error('Failed to update order payment:', e);
      return { success: false, error: e.message };
    }
  },

  /**
   * Mark order payment as failed.
   */
  async markOrderPaymentFailed(orderId) {
    try {
      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(orderId);
      let query = insforge.database.from('orders').update({ payment_status: 'failed' });

      if (isUUID) {
        query = query.eq('id', orderId);
      } else {
        query = query.eq('order_number', orderId);
      }

      const { error } = await query;
      if (error) {
        console.error('Failed to mark payment failed:', error);
        return { success: false };
      }

      return { success: true };
    } catch (e) {
      console.error('Failed to mark order payment failed:', e);
      return { success: false };
    }
  },

  /**
   * Get a single order with its items by ID or order_number.
   */
  async getOrderById(orderId) {
    if (!orderId) return null;
    try {
      let order = null;
      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(orderId);

      if (isUUID) {
        const { data, error } = await insforge.database
          .from('orders')
          .select('*')
          .eq('id', orderId)
          .maybeSingle();
        if (!error && data) order = data;
      } else {
        const { data, error } = await insforge.database
          .from('orders')
          .select('*')
          .eq('order_number', orderId)
          .maybeSingle();
        if (!error && data) order = data;
      }

      if (!order) return null;

      // Fetch items
      const { data: items } = await insforge.database
        .from('order_items')
        .select('*')
        .eq('order_id', order.id);

      return {
        id: order.id,
        orderId: order.order_number,
        date: order.created_at,
        items: (items || []).map((it) => ({
          key: `${it.id}`,
          productId: it.product_id,
          product: {
            id: it.product_id,
            name: it.product_name,
            price: Number(it.price),
            images: [it.product_image]
          },
          quantity: it.quantity,
          selectedSize: it.selected_size,
          selectedColor: it.selected_color,
          giftNote: it.gift_note,
          price: Number(it.price)
        })),
        shippingAddress: order.shipping_address,
        customer: {
          name: order.customer_name,
          email: order.customer_email,
          phone: order.customer_phone
        },
        deliveryMethod: order.delivery_method,
        paymentMethod: order.payment_method,
        subtotal: Number(order.subtotal),
        discount: Number(order.discount || 0),
        shippingFee: Number(order.shipping_fee),
        totalAmount: Number(order.total_amount),
        paymentStatus: order.payment_status,
        status: order.status || 'Pending',
        transactionId: order.transaction_id,
        paidAt: order.paid_at,
        trackingNumber: order.tracking_number,
        estimatedDelivery: order.estimated_delivery
      };
    } catch (e) {
      console.error('Failed to get order by ID:', e);
      return null;
    }
  },

  /**
   * Get orders belonging to a specific authenticated user.
   */
  async getUserOrders(userId) {
    if (!userId) return [];
    try {
      const { data: orders, error } = await insforge.database
        .from('orders')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error || !orders) {
        console.error('Error fetching user orders from DB:', error);
        return [];
      }

      // Fetch items for each order
      const populated = await Promise.all(
        orders.map(async (order) => {
          const { data: items } = await insforge.database
            .from('order_items')
            .select('*')
            .eq('order_id', order.id);

          return {
            id: order.id,
            orderId: order.order_number,
            date: order.created_at,
            items: (items || []).map((it) => ({
              key: `${it.id}`,
              productId: it.product_id,
              product: {
                id: it.product_id,
                name: it.product_name,
                price: Number(it.price),
                images: [it.product_image]
              },
              quantity: it.quantity,
              selectedSize: it.selected_size,
              selectedColor: it.selected_color,
              giftNote: it.gift_note,
              price: Number(it.price)
            })),
            shippingAddress: order.shipping_address,
            customer: {
              name: order.customer_name,
              email: order.customer_email,
              phone: order.customer_phone
            },
            deliveryMethod: order.delivery_method,
            paymentMethod: order.payment_method,
            subtotal: Number(order.subtotal),
            discount: Number(order.discount || 0),
            shippingFee: Number(order.shipping_fee),
            totalAmount: Number(order.total_amount),
            paymentStatus: order.payment_status,
            status: order.status || 'Pending',
            transactionId: order.transaction_id,
            paidAt: order.paid_at,
            trackingNumber: order.tracking_number,
            estimatedDelivery: order.estimated_delivery
          };
        })
      );

      return populated;
    } catch (e) {
      console.error('Failed to get user orders:', e);
      return [];
    }
  },

  /**
   * Get all orders for Admin view.
   */
  async getAllOrders() {
    try {
      const { data: orders, error } = await insforge.database
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (error || !orders) {
        console.error('Error fetching all orders for admin:', error);
        return [];
      }

      const populated = await Promise.all(
        orders.map(async (order) => {
          const { data: items } = await insforge.database
            .from('order_items')
            .select('*')
            .eq('order_id', order.id);

          return {
            id: order.id,
            orderId: order.order_number,
            date: order.created_at,
            items: (items || []).map((it) => ({
              key: `${it.id}`,
              productId: it.product_id,
              product: {
                id: it.product_id,
                name: it.product_name,
                price: Number(it.price),
                images: [it.product_image]
              },
              quantity: it.quantity,
              selectedSize: it.selected_size,
              selectedColor: it.selected_color,
              giftNote: it.gift_note
            })),
            shippingAddress: order.shipping_address,
            customer: {
              name: order.customer_name,
              email: order.customer_email,
              phone: order.customer_phone
            },
            deliveryMethod: order.delivery_method,
            paymentMethod: order.payment_method,
            subtotal: Number(order.subtotal),
            discount: Number(order.discount || 0),
            shippingFee: Number(order.shipping_fee),
            totalAmount: Number(order.total_amount),
            paymentStatus: order.payment_status,
            status: order.status || 'Pending',
            transactionId: order.transaction_id,
            paidAt: order.paid_at,
            trackingNumber: order.tracking_number,
            estimatedDelivery: order.estimated_delivery
          };
        })
      );

      return populated;
    } catch (e) {
      console.error('Failed to get all orders:', e);
      return [];
    }
  },
  /**
   * Get the most recent order for a specific authenticated user.
   * Used by OrderSuccess when no orderId is present in the URL.
   */
  async getRecentOrder(userId) {
    if (!userId) return null;
    try {
      const { data: order, error } = await insforge.database
        .from('orders')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error || !order) return null;

      const { data: items } = await insforge.database
        .from('order_items')
        .select('*')
        .eq('order_id', order.id);

      return {
        id: order.id,
        orderId: order.order_number,
        date: order.created_at,
        items: (items || []).map((it) => ({
          key: `${it.id}`,
          productId: it.product_id,
          product: {
            id: it.product_id,
            name: it.product_name,
            price: Number(it.price),
            images: [it.product_image]
          },
          quantity: it.quantity,
          selectedSize: it.selected_size,
          selectedColor: it.selected_color,
          giftNote: it.gift_note,
          price: Number(it.price)
        })),
        shippingAddress: order.shipping_address,
        customer: {
          name: order.customer_name,
          email: order.customer_email,
          phone: order.customer_phone
        },
        deliveryMethod: order.delivery_method,
        paymentMethod: order.payment_method,
        subtotal: Number(order.subtotal),
        discount: Number(order.discount || 0),
        shippingFee: Number(order.shipping_fee),
        totalAmount: Number(order.total_amount),
        paymentStatus: order.payment_status,
        status: order.status || 'Pending',
        transactionId: order.transaction_id,
        paidAt: order.paid_at,
        trackingNumber: order.tracking_number,
        estimatedDelivery: order.estimated_delivery
      };
    } catch (e) {
      console.error('Failed to get recent order:', e);
      return null;
    }
  }
};
