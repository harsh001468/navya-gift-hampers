import { insforge } from '../lib/insforge';
import { products as fallbackProducts, giftCategories } from '../data/products';

// Helper to check if a product is currently valid and available for customer storefront
const isProductAvailable = (p) => {
  if (!p || !p.id || !p.name || typeof p.name !== 'string') return false;
  if (p.is_archived === true || p.status === 'archived' || p.status === 'disabled') return false;
  if (p.in_stock === false) return false;
  const stock = p.stock_quantity !== undefined && p.stock_quantity !== null ? Number(p.stock_quantity) : 20;
  if (stock <= 0) return false;
  const price = Number(p.price);
  if (!price || isNaN(price) || price <= 0) return false;
  // Image validation: must have at least one non-empty string image URL
  if (
    !Array.isArray(p.images) ||
    p.images.length === 0 ||
    !p.images[0] ||
    typeof p.images[0] !== 'string' ||
    !p.images[0].trim() ||
    p.images[0].includes('placeholder')
  ) {
    return false;
  }
  return true;
};

// Helper to normalize product database schema to app format
const mapDbProduct = (p) => {
  const price = Number(p.price);
  const originalPrice = p.original_price ? Number(p.original_price) : null;
  const discount =
    p.discount_percentage !== undefined && p.discount_percentage !== null
      ? Number(p.discount_percentage)
      : originalPrice && originalPrice > price
      ? Math.round(((originalPrice - price) / originalPrice) * 100)
      : 0;

  const stock =
    p.stock_quantity !== undefined && p.stock_quantity !== null
      ? Number(p.stock_quantity)
      : p.in_stock
      ? 20
      : 0;

  // Filter out any empty, invalid, or placeholder image strings
  const validImages = Array.isArray(p.images)
    ? p.images.filter((img) => img && typeof img === 'string' && img.trim() && !img.includes('placeholder'))
    : [];

  return {
    id: p.id,
    name: p.name,
    category: p.category,
    subcategory: p.subcategory || p.category || 'Hampers',
    gender: p.gender || 'Unisex',
    price,
    originalPrice,
    discount,
    discountPercentage: discount,
    rating: p.rating ? Number(p.rating) : 5.0,
    reviewsCount: p.reviews_count || 0,
    reviews: p.reviews_count || 0,
    description: p.description || '',
    fullDescription: p.full_description || p.description || '',
    isFeatured: !!p.is_featured,
    isNew: !!p.is_new,
    isBestseller: !!p.is_bestseller,
    sizes: Array.isArray(p.sizes) && p.sizes.length > 0 ? p.sizes : ['Standard Box'],
    colors: Array.isArray(p.colors) && p.colors.length > 0 ? p.colors : ['Gold/Rose'],
    tags: Array.isArray(p.tags) && p.tags.length > 0 ? p.tags : ['Luxury'],
    images: validImages.length > 0 ? validImages : ['https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=800&q=80'],
    stockQuantity: stock,
    stock,
    sku: p.sku || '',
    status: p.status || (p.in_stock ? 'active' : 'disabled'),
    isArchived: !!p.is_archived,
    inStock: p.in_stock !== false && !p.is_archived && stock > 0,
    contents:
      Array.isArray(p.specifications) && p.specifications.length > 0
        ? p.specifications
        : p.description
        ? p.description.split(',').map((s) => s.trim()).filter(Boolean)
        : [],
    specifications: Array.isArray(p.specifications) ? p.specifications : [],
    weightSize: p.weight_size || '',
    deliveryInfo:
      p.delivery_info ||
      'Standard 7–15 days delivery across India. Protective gift hamper packaging.',
    personalizationOptions: p.personalization_options || {
      allow_name: true,
      allow_note: true
    }
  };
};

export const productService = {
  // Fetch all active products directly from InsForge Database (Single Source of Truth)
  async getProducts() {
    try {
      const { data, error } = await insforge.database
        .from('products')
        .select('*')
        .eq('is_archived', false)
        .neq('status', 'archived')
        .eq('in_stock', true)
        .order('id', { ascending: false });

      if (error) {
        console.warn('[productService] Database query error, using fallback:', error);
        return fallbackProducts.filter(isProductAvailable).map(mapDbProduct);
      }

      if (Array.isArray(data)) {
        // Enforce strict availability and image validity rules
        const available = data.filter(isProductAvailable);
        return available.map(mapDbProduct);
      }
      return [];
    } catch (e) {
      console.error('[productService] getProducts error:', e);
      return fallbackProducts.filter(isProductAvailable).map(mapDbProduct);
    }
  },

  // Fetch product by ID
  async getProductById(id) {
    try {
      const numId = Number(id);
      const { data, error } = await insforge.database
        .from('products')
        .select('*')
        .eq('id', numId)
        .single();

      if (data) {
        if (!isProductAvailable(data)) {
          return null; // Unavailable/archived products hidden from customer view
        }
        return mapDbProduct(data);
      }

      if (error) {
        const fb = fallbackProducts.find((p) => p.id === numId && isProductAvailable(p));
        return fb ? mapDbProduct(fb) : null;
      }

      return null;
    } catch (e) {
      console.error('[productService] getProductById error:', e);
      const numId = Number(id);
      const fb = fallbackProducts.find((p) => p.id === numId && isProductAvailable(p));
      return fb ? mapDbProduct(fb) : null;
    }
  },

  // Fetch products by category or gender
  async getProductsByCategory(categoryOrGender) {
    try {
      const all = await this.getProducts();
      const query = categoryOrGender.toLowerCase().trim();
      const matched = all.filter((p) => {
        const cat = (p.category || '').toLowerCase();
        const sub = (p.subcategory || '').toLowerCase();
        const gen = (p.gender || '').toLowerCase();

        return (
          cat === query ||
          sub === query ||
          gen === query ||
          (query === 'men' && (cat.includes('men') || gen.includes('men'))) ||
          (query === 'women' && (cat.includes('women') || gen.includes('women')))
        );
      });

      // If requested category yields 0 products (e.g. Wedding/Corporate/Chocolate),
      // return all available products rather than empty results
      return matched.length > 0 ? matched : all;
    } catch {
      return fallbackProducts.filter(isProductAvailable).map(mapDbProduct);
    }
  },

  // Fetch featured items
  async getFeaturedProducts() {
    try {
      const all = await this.getProducts();
      const featured = all.filter((p) => p.isFeatured);
      return featured.length > 0 ? featured : all.slice(0, 8);
    } catch {
      return fallbackProducts.filter(isProductAvailable).filter((p) => p.isFeatured).map(mapDbProduct);
    }
  },

  // Fetch new arrivals
  async getNewArrivals() {
    try {
      const all = await this.getProducts();
      const news = all.filter((p) => p.isNew);
      return news.length > 0 ? news : all.slice(0, 8);
    } catch {
      return fallbackProducts.filter(isProductAvailable).filter((p) => p.isNew).map(mapDbProduct);
    }
  },

  // Search products by keyword
  async searchProducts(query) {
    if (!query || query.trim() === '') return [];
    const q = query.toLowerCase().trim();
    try {
      const all = await this.getProducts();
      return all.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.subcategory.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          (p.sku && p.sku.toLowerCase().includes(q)) ||
          (p.tags && p.tags.some((t) => t.toLowerCase().includes(q)))
      );
    } catch {
      return fallbackProducts
        .filter(isProductAvailable)
        .filter((p) => p.name.toLowerCase().includes(q))
        .map(mapDbProduct);
    }
  },

  // Categories list from InsForge categories table (only active & populated categories)
  async getGiftCategories() {
    try {
      const [catRes, allAvailable] = await Promise.all([
        insforge.database
          .from('categories')
          .select('*')
          .eq('is_active', true)
          .order('display_order', { ascending: true }),
        this.getProducts()
      ]);

      const data = catRes.data;
      if (catRes.error || !data || data.length === 0) {
        return giftCategories;
      }

      // Filter out unavailable, empty, or broken categories
      const activePopulated = data.filter((c) => {
        if (!c.is_active || !c.image) return false;
        const slug = (c.slug || '').toLowerCase();
        const name = (c.name || '').toLowerCase();

        // Strictly exclude categories with zero available products
        if (
          slug.includes('wedding') ||
          name.includes('wedding') ||
          slug.includes('corporate') ||
          name.includes('corporate') ||
          slug.includes('chocolate') ||
          name.includes('chocolate') ||
          slug.includes('hacked') ||
          name.includes('hacked')
        ) {
          // Only show if there are actual products in this category
          const hasProds = allAvailable.some((p) => {
            const pc = (p.category || '').toLowerCase();
            const ps = (p.subcategory || '').toLowerCase();
            return pc.includes(name) || ps.includes(name);
          });
          if (!hasProds) return false;
        }

        return true;
      });

      return activePopulated.map((c) => ({
        id: c.slug || c.id,
        name: c.name,
        slug: c.slug,
        description: c.description || '',
        image: c.image,
        link:
          c.slug === 'mens-hampers'
            ? '/men'
            : c.slug === 'womens-hampers'
            ? '/women'
            : `/gifts?sub=${encodeURIComponent(c.name)}`
      }));
    } catch {
      return giftCategories;
    }
  }
};
