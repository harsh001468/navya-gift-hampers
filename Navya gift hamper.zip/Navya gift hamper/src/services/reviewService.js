import { insforge } from '../lib/insforge';

export const reviewService = {
  // Fetch reviews for a specific product
  async getProductReviews(productId) {
    if (!productId) return [];
    try {
      const { data, error } = await insforge.database
        .from('reviews')
        .select('*')
        .eq('product_id', productId)
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching reviews:', error);
        return [];
      }
      return data || [];
    } catch (e) {
      console.error('Failed to get reviews:', e);
      return [];
    }
  },

  // Fetch reviews written by the authenticated user
  async getUserReviews(userId) {
    if (!userId) return [];
    try {
      const { data, error } = await insforge.database
        .from('reviews')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching user reviews:', error);
        return [];
      }
      return data || [];
    } catch (e) {
      console.error('Failed to get user reviews:', e);
      return [];
    }
  },

  // Check if a user can review a product from a delivered order
  async canUserReview(userId, productId, orderId) {
    if (!userId || !productId) return false;
    try {
      // 1. Check if user already reviewed this product from this order
      const { data: existingReview } = await insforge.database
        .from('reviews')
        .select('id')
        .eq('user_id', userId)
        .eq('product_id', productId)
        .eq('order_id', orderId)
        .maybeSingle();

      if (existingReview) return false;

      // 2. Check if the order is delivered
      if (orderId) {
        const { data: order } = await insforge.database
          .from('orders')
          .select('status')
          .eq('id', orderId)
          .eq('user_id', userId)
          .maybeSingle();

        if (!order || order.status?.toLowerCase() !== 'delivered') {
          return false;
        }
      }

      return true;
    } catch (e) {
      console.error('Error checking review eligibility:', e);
      return false;
    }
  },

  // Submit a verified purchase review
  async submitReview(reviewData) {
    if (!reviewData.userId) {
      return { success: false, error: 'Authentication required to submit a review' };
    }

    try {
      const payload = {
        user_id: reviewData.userId,
        product_id: reviewData.productId,
        order_id: reviewData.orderId || null,
        author_name: reviewData.authorName?.trim() || 'Verified Customer',
        author_location: reviewData.authorLocation?.trim() || 'India',
        rating: Number(reviewData.rating) || 5,
        title: reviewData.title?.trim() || '',
        comment: reviewData.comment?.trim(),
        is_verified_buyer: true,
        is_verified_purchase: true,
        helpful_count: 0
      };

      const { data, error } = await insforge.database
        .from('reviews')
        .insert([payload])
        .select()
        .single();

      if (error) {
        console.error('Error submitting review:', error);
        return { success: false, error: error.message };
      }

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('navya:data_sync', { detail: { type: 'reviews' } }));
      }
      return { success: true, review: data };
    } catch (e) {
      console.error('Failed to submit review:', e);
      return { success: false, error: e.message };
    }
  }
};
