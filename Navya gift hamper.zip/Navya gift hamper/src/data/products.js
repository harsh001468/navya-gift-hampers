// Helper: converts Google Drive share link to direct image URL
// Drive link format: https://drive.google.com/file/d/{FILE_ID}/view?...
// Direct image format: https://lh3.googleusercontent.com/d/{FILE_ID}

export const products = [
  // ─── MEN'S HAMPERS ───────────────────────────────────────────────────────
  {
    id: 1,
    name: "Personalized Photo & Chocolate Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 750,
    originalPrice: 999,
    discount: 25,
    rating: 4.8,
    reviews: 42,
    badge: "Bestseller",
    images: [
      "https://lh3.googleusercontent.com/d/1pfwZEh4ESO4mBe3KLqAUXln5VgfUTrsB"
    ],
    sizes: ["Standard Box"],
    colors: ["Light Blue"],
    description:
      "Light blue gift box with purple ribbon handle containing: beige Torque collared shirt, framed photograph, Bella Vita perfume box, Snickers bar, Cadbury Dairy Milk Silk Mousse, KitKat bar, and artificial decorative roses.",
    contents: [
      "Beige Torque Collared Shirt",
      "Framed Photograph",
      "Bella Vita Perfume",
      "Snickers Bar",
      "Cadbury Dairy Milk Silk Mousse",
      "KitKat Bar",
      "Artificial Decorative Roses"
    ],
    stock: 20,
    isNew: true,
    isFeatured: true,
    tags: ["Men", "Personalized", "Chocolate", "Shirt", "Birthday"]
  },
  {
    id: 2,
    name: "LP Checkered Shirt & Perfume Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 1299,
    originalPrice: 1699,
    discount: 24,
    rating: 4.7,
    reviews: 38,
    badge: "Popular",
    images: [
      "https://lh3.googleusercontent.com/d/1k64HD9ZVn8eFCbSWIWv3p0Fswq-Bez4s"
    ],
    sizes: ["Standard Box"],
    colors: ["Lavender"],
    description:
      "Louis Philippe (LP) black-and-white checkered shirt, Bella Vita Luxury 'CEO Man' Eau De Parfum, three KitKat chocolate bars, two decorative light-green artificial flower buds, packed in a lavender gift box with ribbon tie and a small greeting card note.",
    contents: [
      "Louis Philippe Checkered Shirt",
      "Bella Vita CEO Man EDP",
      "3x KitKat Bars",
      "Artificial Flower Buds",
      "Greeting Card"
    ],
    stock: 15,
    isNew: false,
    isFeatured: true,
    tags: ["Men", "Shirt", "Perfume", "LP", "Birthday"]
  },
  {
    id: 3,
    name: "Navya Personalized 'King' Hamper",
    category: "Gifts",
    subcategory: "Personalized Hampers",
    gender: "Men",
    price: 1299,
    originalPrice: 1799,
    discount: 28,
    rating: 4.9,
    reviews: 61,
    badge: "Bestseller",
    images: [
      "https://lh3.googleusercontent.com/d/1iE5cuh0nsMcSwCVcS3o_-TGDTTpLUNif"
    ],
    sizes: ["Standard Box"],
    colors: ["Black"],
    description:
      "Heart-shaped photo collage with LED fairy lights and 'Navya gift hamper' card. Box contents: red Zara polo shirt, black customized leather wallet with crown emblem tagged 'KING', personalized photo coffee mug, mini framed photo print, black wristwatch, black sunglasses, Yardley London 'Gold' deodorant, three KitKat bars, personalized leather keychain with crown charm tagged 'Navya', and yellow artificial roses with baby's breath. Presented in a black gift box against a white fur rug backdrop with a green ceramic vase.",
    contents: [
      "Red Zara Polo Shirt",
      "Customized Leather Wallet (KING)",
      "Personalized Photo Coffee Mug",
      "Mini Framed Photo Print",
      "Black Wristwatch",
      "Black Sunglasses",
      "Yardley London Gold Deodorant",
      "3x KitKat Bars",
      "Personalized Leather Keychain",
      "Yellow Artificial Roses & Baby's Breath"
    ],
    stock: 12,
    isNew: true,
    isFeatured: true,
    tags: ["Personalized", "Men", "King", "Watch", "Sunglasses", "Birthday"]
  },
  {
    id: 4,
    name: "Spider Tee & Sparklerider Accessories Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 1050,
    originalPrice: 1399,
    discount: 25,
    rating: 4.6,
    reviews: 29,
    badge: "New",
    images: [
      "https://lh3.googleusercontent.com/d/1ozyfZiVSFmZCbxGEIuxOs3aZ060FXg3c"
    ],
    sizes: ["Standard Box"],
    colors: ["Black"],
    description:
      "Heart-shaped photo collage with LED fairy lights and 'Navya gift hamper' card. Box contents: red Zara polo shirt, black customized leather wallet with crown emblem tagged 'KING', personalized photo coffee mug, mini framed photo print, black wristwatch, black sunglasses, Yardley London 'Gold' deodorant, three KitKat bars, personalized leather keychain with crown charm tagged 'Navya', and yellow artificial roses with baby's breath. Presented in a black gift box against a white fur rug backdrop with a green ceramic vase.",
    contents: [
      "Graphic Spider Tee",
      "Sparklerider Accessories",
      "Personalized Items",
      "Chocolates & Roses"
    ],
    stock: 18,
    isNew: true,
    isFeatured: false,
    tags: ["Men", "T-Shirt", "Accessories", "Birthday"]
  },
  {
    id: 5,
    name: "Wine Shirt & Crochet Rose Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 699,
    originalPrice: 999,
    discount: 30,
    rating: 4.5,
    reviews: 22,
    badge: "Value Pick",
    images: [
      "https://lh3.googleusercontent.com/d/10rDei3W_phLjiLSzTXREYNFC_aquZX34"
    ],
    sizes: ["Standard Box"],
    colors: ["Mustard Yellow"],
    description:
      "Maroon/wine-red button-down collared shirt, handcrafted crochet red rose bouquet wrapped in paper with white ribbon, dark brown leather bi-fold wallet (Letfirok), black Sunsilk shampoo bottle, black-framed wayfarer sunglasses. Presented in a mustard-yellow rectangular gift box.",
    contents: [
      "Wine-Red Collared Shirt",
      "Handcrafted Crochet Rose Bouquet",
      "Letfirok Leather Wallet",
      "Sunsilk Shampoo",
      "Wayfarer Sunglasses"
    ],
    stock: 25,
    isNew: false,
    isFeatured: false,
    tags: ["Men", "Shirt", "Rose", "Wallet", "Sunglasses"]
  },
  {
    id: 6,
    name: "Wine Red Formal Shirt Grooming Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 999,
    originalPrice: 1299,
    discount: 23,
    rating: 4.7,
    reviews: 45,
    badge: "Trending",
    images: [
      "https://lh3.googleusercontent.com/d/12GvRi-Mzsrw9Bq3uJ4EJEESEbbKseSf9"
    ],
    sizes: ["Standard Box"],
    colors: ["Kraft Brown"],
    description:
      "Wine red tailored formal shirt, chronograph-style stainless steel watch with silver bracelet and blue dial, black leather bi-fold wallet and matching belt with silver buckle, Denver Original deodorant. Packed in a sturdy kraft box lined with white crinkle paper and satin ribbons.",
    contents: [
      "Wine Red Formal Shirt",
      "Chronograph Stainless Steel Watch",
      "Black Leather Wallet & Belt",
      "Denver Original Deodorant"
    ],
    stock: 17,
    isNew: false,
    isFeatured: true,
    tags: ["Men", "Shirt", "Watch", "Belt", "Deodorant", "Formal"]
  },
  {
    id: 7,
    name: "Brown Shirt Birthday Grooming Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 950,
    originalPrice: 1299,
    discount: 27,
    rating: 4.8,
    reviews: 54,
    badge: "Birthday Special",
    images: [
      "https://lh3.googleusercontent.com/d/1f1O37s4_tm9g1eXwHlxfnUnj53xuiME6"
    ],
    sizes: ["Standard Box"],
    colors: ["Brown"],
    description:
      "Brown button-down 'Premium Cotton' shirt, analog watch with brown strap in watch box, dark sunglasses in protective case, Brit Accent 'Canyon' Eau De Parfum, VLCC Anti-Tan face wash, Mamaearth Vitamin C SPF50 sunscreen, travel-size lavender body wash, purple mesh loofah, teal mini portable gadget, Cadbury 5 Star bar, Nestle KitKat bar. Includes a 'Happy Birthday Dear' greeting card, packed in a brown gift box with paper shred filler and a satin ribbon printed 'Especially for you'.",
    contents: [
      "Brown Premium Cotton Shirt",
      "Analog Watch with Brown Strap",
      "Brit Accent Canyon EDP",
      "VLCC Anti-Tan Face Wash",
      "Mamaearth Vitamin C Sunscreen SPF50",
      "Lavender Body Wash",
      "Cadbury 5 Star Bar",
      "KitKat Bar",
      "Birthday Greeting Card"
    ],
    stock: 14,
    isNew: false,
    isFeatured: true,
    tags: ["Men", "Shirt", "Grooming", "Skincare", "Birthday", "Perfume"]
  },
  {
    id: 8,
    name: "Anniversary Sneaker & Watch Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 1299,
    originalPrice: 1799,
    discount: 28,
    rating: 4.9,
    reviews: 67,
    badge: "Anniversary Special",
    images: [
      "https://lh3.googleusercontent.com/d/1Q5uSG5DBZEpMib4BOLUxiwuVQI0DBR7X"
    ],
    sizes: ["Standard Box"],
    colors: ["Matte Black"],
    description:
      "Light blue collared dress shirt tied with a black 'For You' ribbon tag, white/light-blue casual sneakers, all-black metal link analog watch with gold accents in display box, brown bi-fold wallet customized with crown charm and 'VIJAY' name tag, black-and-gold twist pen, geometric metal-frame sunglasses, Boss Bottled (Hugo Boss) fragrance with box, gold-lettered 'Happy Anniversary' card, and a 'To My King' mini tag. Presented in a large matte black gift box with warm white fairy lights and a satin bow ribbon.",
    contents: [
      "Light Blue Collared Shirt",
      "White/Blue Casual Sneakers",
      "All-Black Metal Link Watch",
      "Customized Bi-Fold Wallet",
      "Hugo Boss Bottled Fragrance",
      "Metal Frame Sunglasses",
      "Anniversary Card",
      "Fairy Lights"
    ],
    stock: 10,
    isNew: true,
    isFeatured: true,
    tags: ["Men", "Anniversary", "Sneakers", "Watch", "Hugo Boss", "Personalized"]
  },
  {
    id: 9,
    name: "Lacoste Birthday Gaming Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 1350,
    originalPrice: 1799,
    discount: 25,
    rating: 4.8,
    reviews: 39,
    badge: "Limited Edition",
    images: [
      "https://lh3.googleusercontent.com/d/1zN5ata7eUU_OGtESO4FGVzM0byZOrQs3"
    ],
    sizes: ["Standard Box"],
    colors: ["Cream"],
    description:
      "Navy blue Lacoste button-down shirt, silver-tone square-dial wristwatch, two Bella Vita Luxury mini perfumes (CEO Man & White Oud), Galaxy Fruit & Nut chocolate bar, anime-edition (One Piece Sanji) Nestle KitKat, gaming-controller shaped decorative mug/figurine, two small artificial red rosettes, 'Happy Birthday' greeting card, and a wooden 'Happy Birthday' topper. Packed in a cream textured gift box with satin ribbon bow and 'Best Wishes' tag.",
    contents: [
      "Navy Blue Lacoste Shirt",
      "Silver Square-Dial Wristwatch",
      "Bella Vita CEO Man + White Oud Mini Perfumes",
      "Galaxy Fruit & Nut Bar",
      "One Piece Sanji Edition KitKat",
      "Gaming Controller Mug/Figurine",
      "Happy Birthday Card & Topper"
    ],
    stock: 8,
    isNew: true,
    isFeatured: true,
    tags: ["Men", "Lacoste", "Gaming", "Birthday", "Anime", "Perfume"]
  },
  {
    id: 10,
    name: "Onam Special Mundu & Perfume Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 1199,
    originalPrice: 1599,
    discount: 25,
    rating: 4.9,
    reviews: 51,
    badge: "Onam Special",
    images: [
      "https://lh3.googleusercontent.com/d/1gTg36hGOdB7k6B0_dbxcXF7CY868A9Ax"
    ],
    sizes: ["Standard Box"],
    colors: ["Grey"],
    description:
      "Grey/blue-grey collared shirt, white Kasavu mundu/dhoti tied with lavender satin ribbon and silver border, two Bella Vita Luxury mini perfumes (CEO Man & White Oud), Casio silver-tone analog watch with square dial, a 'Happy Onam My Love' note card, and a white-and-lavender artificial floral arrangement. Presented in a grey rigid gift box with clear display window lid, internal compartments and satin ribbon pull tabs.",
    contents: [
      "Grey Collared Shirt",
      "White Kasavu Mundu/Dhoti",
      "Bella Vita CEO Man + White Oud Mini Perfumes",
      "Casio Analog Watch",
      "Floral Arrangement",
      "Happy Onam Card"
    ],
    stock: 15,
    isNew: true,
    isFeatured: true,
    tags: ["Men", "Onam", "Ethnic", "Mundu", "Casio", "Perfume"]
  },
  {
    id: 11,
    name: "Peter England Shirt & Fogg Perfume Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 1050,
    originalPrice: 1399,
    discount: 25,
    rating: 4.7,
    reviews: 33,
    badge: "Popular",
    images: [
      "https://lh3.googleusercontent.com/d/1wR5sAybaPB2tiHIOZHI8PFnvPAcO1q9P"
    ],
    sizes: ["Standard Box"],
    colors: ["White"],
    description:
      "Peter England 'Nuvo' fit royal/peacock blue textured shirt, Fogg 'Xtremo' Eau De Parfum (100ml boxed), dark brown bifold leather wallet with metal emblem, Fastrack-style matte black analog watch with orange/red dial accents on a watch pillow. Presented in a white rigid gift box tied with a wide dark brown/black satin ribbon bow.",
    contents: [
      "Peter England Peacock Blue Shirt",
      "Fogg Xtremo EDP (100ml)",
      "Dark Brown Leather Wallet",
      "Fastrack-Style Matte Black Watch"
    ],
    stock: 18,
    isNew: false,
    isFeatured: false,
    tags: ["Men", "Peter England", "Fogg", "Shirt", "Watch", "Wallet"]
  },
  {
    id: 12,
    name: "Raymond Black Shirt Grooming Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 1050,
    originalPrice: 1399,
    discount: 25,
    rating: 4.8,
    reviews: 47,
    badge: "Premium",
    images: [
      "https://lh3.googleusercontent.com/d/1dNwWWRsUM-Rig6N1RDZbiD_5OGxxplYq"
    ],
    sizes: ["Standard Box"],
    colors: ["White"],
    description:
      "Raymond solid black button-down shirt, Lafz 'Dariush' Premium Body Spray (boxed), black faux leather bifold wallet with woven trim and metal emblem, silver-tone analog watch with dark blue dial, illustrated floral 'Happy Birthday' greeting card. Presented against a soft white fur/plush backdrop in a white hamper gift box.",
    contents: [
      "Raymond Solid Black Shirt",
      "Lafz Dariush Premium Body Spray",
      "Black Faux Leather Wallet",
      "Silver Analog Watch (Blue Dial)",
      "Happy Birthday Greeting Card"
    ],
    stock: 13,
    isNew: false,
    isFeatured: false,
    tags: ["Men", "Raymond", "Shirt", "Watch", "Birthday", "Grooming"]
  },
  {
    id: 13,
    name: "Polo RL Flannel Shirt Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 999,
    originalPrice: 1299,
    discount: 23,
    rating: 4.6,
    reviews: 27,
    badge: "Trending",
    images: [
      "https://lh3.googleusercontent.com/d/1rrjN535XCOCIscH692TUqmgJtCJd5zG5"
    ],
    sizes: ["Standard Box"],
    colors: ["Black"],
    description:
      "Polo Ralph Lauren red-and-navy flannel/plaid shirt, Johnwin 'Club Intense' perfumed body spray (200ml), black stitched leather belt with silver-tone buckle, one artificial decorative red rose. Presented in a black gift box lined with a black-and-white gingham inner pattern.",
    contents: [
      "Polo Ralph Lauren Plaid Flannel Shirt",
      "Johnwin Club Intense Body Spray (200ml)",
      "Black Stitched Leather Belt",
      "Artificial Red Rose"
    ],
    stock: 20,
    isNew: false,
    isFeatured: false,
    tags: ["Men", "Polo Ralph Lauren", "Flannel", "Shirt", "Belt"]
  },
  {
    id: 14,
    name: "Black Cotton Shirt Birthday Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 999,
    originalPrice: 1399,
    discount: 29,
    rating: 4.8,
    reviews: 58,
    badge: "Birthday Special",
    images: [
      "https://lh3.googleusercontent.com/d/1RCnRbOrbvyx9VtR47adLO1fc3ZD9OEFw"
    ],
    sizes: ["Standard Box"],
    colors: ["Black"],
    description:
      "Solid black 'Premium Cotton' button-down shirt tied with a black satin bow, Bella Vita Luxury 'CEO Man' Eau De Parfum, Maximo silver-tone watch with white dial and brown leather strap, classic aviator sunglasses, Cadbury 5 Star bar, Nestle KitKat (2-finger pack), 'Happy Birthday My Love' greeting card with heart accents, and warm fairy/LED string lights. Presented in a black gift box with shredded crinkle paper bedding and a golden rim border.",
    contents: [
      "Black Premium Cotton Shirt",
      "Bella Vita CEO Man EDP",
      "Maximo Silver Watch (Brown Strap)",
      "Aviator Sunglasses",
      "Cadbury 5 Star Bar",
      "KitKat Bar",
      "Birthday Card",
      "LED Fairy Lights"
    ],
    stock: 16,
    isNew: false,
    isFeatured: true,
    tags: ["Men", "Shirt", "Birthday", "Watch", "Perfume", "Sunglasses"]
  },
  {
    id: 15,
    name: "Denim Shirt & Rose Bouquet Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 850,
    originalPrice: 1199,
    discount: 29,
    rating: 4.6,
    reviews: 31,
    badge: "Popular",
    images: [
      "https://lh3.googleusercontent.com/d/1HdhqTX4p05IskkRUt13xweiaay0RHZ8R"
    ],
    sizes: ["Standard Box"],
    colors: ["Light Blue Denim"],
    description:
      "Light-wash denim/chambray button-down shirt embroidered with the number '26', Toblerone chocolate bar, gold-foil-wrapped Ferrero Rocher chocolates, artificial white and sky-blue rosettes lining the box, packed in a rectangular gift box. Accompanied by a bouquet of three red roses wrapped in black-and-white layered cone paper with a white satin ribbon printed 'Just For You'.",
    contents: [
      "Light Wash Denim Shirt (Embroidered '26')",
      "Toblerone Chocolate Bar",
      "Ferrero Rocher (Gold Foil)",
      "Artificial Rosettes",
      "Red Rose Bouquet (3 stems)"
    ],
    stock: 22,
    isNew: false,
    isFeatured: false,
    tags: ["Men", "Denim", "Shirt", "Roses", "Birthday", "Chocolates"]
  },
  {
    id: 16,
    name: "Focus Plaid Shirt & Fogg Perfume Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 899,
    originalPrice: 1199,
    discount: 25,
    rating: 4.6,
    reviews: 24,
    badge: "New",
    images: [
      "https://lh3.googleusercontent.com/d/1aFNQfWwElitndXGJQnSKuosMB6VIpEtA"
    ],
    sizes: ["Standard Box"],
    colors: ["White & Green"],
    description:
      "Blue/red/white checkered Focus button-down shirt, Fogg Scent Xpressio Eau de Parfum (boxed), three Bounty coconut chocolate bars, three Ferrero Raffaello almond-coconut wafer packs, and small red decorative rosettes, with a small card tied in sheer green organza ribbon. Presented in a white base box with a green damask patterned lid.",
    contents: [
      "Focus Checkered Shirt",
      "Fogg Scent Xpressio EDP",
      "3x Bounty Bars",
      "3x Ferrero Raffaello Packs",
      "Decorative Rosettes"
    ],
    stock: 19,
    isNew: true,
    isFeatured: false,
    tags: ["Men", "Shirt", "Fogg", "Chocolates", "Birthday"]
  },
  {
    id: 17,
    name: "Men's Prayer & Grooming Accessories Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 1050,
    originalPrice: 1499,
    discount: 30,
    rating: 4.7,
    reviews: 36,
    badge: "Unique",
    images: [
      "https://lh3.googleusercontent.com/d/1x0dorKoa6SFeQ2UUH2e07_iBhpblouuR"
    ],
    sizes: ["Standard Box"],
    colors: ["Black"],
    description:
      "Black leather belt with matte black buckle, black-beaded Tasbih/Misbaha prayer beads with silver-tone tassel, engraved flip-top Zippo-style lighter customized with 'OSMAN KURTLAR', black leather cardholder/bifold wallet with snap-button closure, 'WESS COLLECTION' Eau de Parfum (50ml), all-black chronograph-style wristwatch with silicone strap, stacked men's beaded accent bracelets. Presented in a custom presentation gift box with fitted compartments for each accessory.",
    contents: [
      "Black Leather Belt",
      "Tasbih Prayer Beads",
      "Customized Engraved Lighter",
      "Black Leather Wallet",
      "WESS Collection EDP (50ml)",
      "Black Chronograph Watch",
      "Beaded Accent Bracelets"
    ],
    stock: 11,
    isNew: false,
    isFeatured: false,
    tags: ["Men", "Prayer Beads", "Watch", "Grooming", "Accessories", "Personalized"]
  },
  {
    id: 18,
    name: "Dual Shirt Birthday Grooming Hamper",
    category: "Men",
    subcategory: "Men's Hamper",
    gender: "Men",
    price: 1250,
    originalPrice: 1699,
    discount: 26,
    rating: 4.8,
    reviews: 43,
    badge: "Birthday Special",
    images: [
      "https://lh3.googleusercontent.com/d/1We3Z9EUwI18Gh_0q8o8GAAKX6z4BCeMz"
    ],
    sizes: ["Standard Box"],
    colors: ["Black & Pink"],
    description:
      "A black collared shirt and a light pink striped collared shirt, both tied with pink satin ribbons, a dark brown/black leather belt, a brown bifold wallet, a wristwatch with black dial and brown strap, a customized ceramic photo mug, a heart-shaped red gift/chocolate box, and a gold-stemmed artificial rose. Presented in a multi-compartment gift box with a purple/pink watercolor floral exterior, alongside a 'Happy Birthday' heart-shaped photo collage with cartoon bear cutouts and pink ribbon bows.",
    contents: [
      "Black Collared Shirt",
      "Light Pink Striped Shirt",
      "Leather Belt",
      "Brown Bifold Wallet",
      "Wristwatch (Black Dial)",
      "Customized Ceramic Photo Mug",
      "Heart-Shaped Chocolate Box",
      "Gold-Stemmed Artificial Rose"
    ],
    stock: 9,
    isNew: true,
    isFeatured: true,
    tags: ["Men", "Shirt", "Birthday", "Watch", "Wallet", "Mug"]
  },

  // ─── WOMEN'S HAMPERS ──────────────────────────────────────────────────────
  {
    id: 19,
    name: "Women's Birthday Accessories Hamper",
    category: "Women",
    subcategory: "Women's Hamper",
    gender: "Women",
    price: 750,
    originalPrice: 999,
    discount: 25,
    rating: 4.7,
    reviews: 35,
    badge: "Birthday Special",
    images: [
      "https://lh3.googleusercontent.com/d/10grmCxscyvNePDD6GZcjnT72NoUl1N81"
    ],
    sizes: ["Standard Box"],
    colors: ["Beige"],
    description:
      "Beige/tan crossbody handbag with gold-tone chain strap, 'Happy Birthday!' greeting card, folded brown scarf/hijab wrapped with a white paper label, silver-tone mesh strap women's wristwatch on a display pillow, terracotta ruffled fabric hair scrunchie, black elastic hair ties with pearl bead accents. Packed in a cardboard gift box with shredded paper filler cushioning.",
    contents: [
      "Beige Crossbody Handbag (Gold Chain Strap)",
      "Brown Scarf/Hijab",
      "Silver Mesh Strap Women's Watch",
      "Terracotta Hair Scrunchie",
      "Pearl Bead Hair Ties",
      "Birthday Greeting Card"
    ],
    stock: 20,
    isNew: true,
    isFeatured: true,
    tags: ["Women", "Handbag", "Watch", "Accessories", "Birthday"]
  },
  {
    id: 20,
    name: "Ethnic Wear & Perfume Birthday Hamper",
    category: "Women",
    subcategory: "Women's Hamper",
    gender: "Women",
    price: 1450,
    originalPrice: 1999,
    discount: 27,
    rating: 4.9,
    reviews: 72,
    badge: "Bestseller",
    images: [
      "https://lh3.googleusercontent.com/d/1XhftF9W_MccsuN8C55SZyjFCB3ypMQfA"
    ],
    sizes: ["Standard Box"],
    colors: ["White Trunk"],
    description:
      "Mauve/plum embroidered kurti with white neckline and border embroidery, a boxed 4-piece mini perfume discovery set (coral, peach, purple, magenta), tan-soled criss-cross slide sandals, white tabletop photo frame, purple/violet/cream artificial rosettes, and assorted Cadbury Dairy Milk and Galaxy chocolate bars. Lid features five polaroid-style photos on a string with mini clothespins, a golden 'Happy Birthday' acrylic cutout, 3D butterfly decals, and a sky/cloud insert card. Presented in a multi-compartment white presentation trunk box.",
    contents: [
      "Mauve Embroidered Kurti",
      "4-Piece Mini Perfume Discovery Set",
      "Criss-Cross Slide Sandals",
      "White Tabletop Photo Frame",
      "Cadbury Dairy Milk & Galaxy Bars",
      "Artificial Rosettes",
      "Polaroid Photo String Display",
      "'Happy Birthday' Acrylic Cutout"
    ],
    stock: 10,
    isNew: true,
    isFeatured: true,
    tags: ["Women", "Kurti", "Ethnic", "Perfume", "Birthday", "Sandals", "Photo"]
  },
  {
    id: 21,
    name: "Bella Vita Discovery Set & Love Note Hamper",
    category: "Women",
    subcategory: "Women's Hamper",
    gender: "Women",
    price: 850,
    originalPrice: 1099,
    discount: 23,
    rating: 4.7,
    reviews: 44,
    badge: "Popular",
    images: [
      "https://lh3.googleusercontent.com/d/1wso_GTQv7D-2n8s7ZouJm2uUoTOrlARa"
    ],
    sizes: ["Standard Box"],
    colors: ["Pink & Cream"],
    description:
      "Bella Vita 4-piece women's mini perfume discovery set (Rose, Glam, Date, Senorita), a classic Nestle KitKat 4-finger bar, two 3-piece Ferrero Rocher packs, red and cream artificial roses, and a personalized light-blue love note card with envelope-and-hearts artwork.",
    contents: [
      "Bella Vita 4-Piece Mini Perfume Set (Rose, Glam, Date, Senorita)",
      "KitKat 4-Finger Bar",
      "2x Ferrero Rocher 3-Piece Packs",
      "Artificial Roses (Red & Cream)",
      "Personalized Love Note Card"
    ],
    stock: 24,
    isNew: false,
    isFeatured: true,
    tags: ["Women", "Bella Vita", "Perfume", "Chocolates", "Love Note"]
  },
  {
    id: 22,
    name: "Self-Care & Motivation Hamper",
    category: "Women",
    subcategory: "Women's Hamper",
    gender: "Women",
    price: 999,
    originalPrice: 1399,
    discount: 29,
    rating: 4.8,
    reviews: 59,
    badge: "Trending",
    images: [
      "https://lh3.googleusercontent.com/d/1v7QnjA6NFLURcJ0HETabL0uy_rLMvKNW"
    ],
    sizes: ["Standard Box"],
    colors: ["Natural"],
    description:
      "Insulated travel tumbler printed 'Make today amazing', a tan faux-leather journal/planner personalized 'Dream. Plan. Do.', a gold-tone heart pendant necklace ('You are something beautiful'), a dried lavender and baby's breath bouquet tagged 'Especially for you', a light brown plush teddy bear, a Bath & Body Works 'A Thousand Wishes' travel body mist, a 'Just for you' scented jar candle, a Cadbury Dairy Milk bar, and a Ferrero Rocher 2-piece pack.",
    contents: [
      "Insulated Travel Tumbler",
      "Faux-Leather Journal/Planner",
      "Gold Heart Pendant Necklace",
      "Dried Lavender & Baby's Breath Bouquet",
      "Plush Teddy Bear",
      "Bath & Body Works Body Mist",
      "Scented Jar Candle",
      "Cadbury Dairy Milk Bar",
      "Ferrero Rocher 2-Piece Pack"
    ],
    stock: 13,
    isNew: true,
    isFeatured: true,
    tags: ["Women", "Self-Care", "Tumbler", "Journal", "Teddy Bear", "Candle"]
  },

  // ─── PERSONALIZED HAMPERS ─────────────────────────────────────────────────
  {
    id: 23,
    name: "Akshay Personalized Wallet Hamper",
    category: "Gifts",
    subcategory: "Personalized Hampers",
    gender: "Men",
    price: 750,
    originalPrice: 999,
    discount: 25,
    rating: 4.6,
    reviews: 28,
    badge: "Personalized",
    images: [
      "https://lh3.googleusercontent.com/d/1pDB8LwuWpiFsc6r2O--G0cVOh2nqjL3E"
    ],
    sizes: ["Standard Box"],
    colors: ["Black"],
    description:
      "Personalized black/dark brown leather wallet with 'Love' metal lettering and 'AKSHAY' nameplate engraving, black chronograph-style watch with brown multi-dial face and leather strap, four Cadbury Dairy Milk chocolate bars, three artificial white rose rosettes, gold 'Happy Birthday' script decal on the lid window. Presented in a black rigid gift box with internal compartments, display window, satin bow ribbon, and a customized greeting card/envelope inside the lid.",
    contents: [
      "Personalized Leather Wallet (AKSHAY)",
      "Black Chronograph Watch",
      "4x Cadbury Dairy Milk Bars",
      "White Rose Rosettes",
      "Customized Greeting Card"
    ],
    stock: 18,
    isNew: false,
    isFeatured: false,
    tags: ["Personalized", "Wallet", "Watch", "Birthday", "Chocolates"]
  },
  {
    id: 24,
    name: "Navya Luxury Men's Accessories Hamper",
    category: "Gifts",
    subcategory: "Personalized Hampers",
    gender: "Men",
    price: 899,
    originalPrice: 1299,
    discount: 31,
    rating: 4.8,
    reviews: 52,
    badge: "Luxury",
    images: [
      "https://lh3.googleusercontent.com/d/1BBK65bfmDbZpXKX0V3OoIXuSTRySeD5p"
    ],
    sizes: ["Standard Box"],
    colors: ["Custom Black Box"],
    description:
      "Dark brown leather bifold wallet with embossed crown motif and buckle strap, dark-tinted aviator sunglasses, chronograph analog watch with brown leather strap, amber/brown glass men's cologne bottle with geometric black cap, chrome-accented metal rollerball pen, black satin pre-tied bow tie. Presented in a custom luxury gift box hinged lid inscribed 'Navya gift hamper' with a custom foam cut-out insert.",
    contents: [
      "Dark Brown Leather Wallet (Crown Motif)",
      "Dark-Tinted Aviator Sunglasses",
      "Chronograph Analog Watch",
      "Men's Cologne Bottle",
      "Chrome Metal Rollerball Pen",
      "Black Satin Bow Tie"
    ],
    stock: 16,
    isNew: false,
    isFeatured: true,
    tags: ["Personalized", "Luxury", "Watch", "Sunglasses", "Wallet", "Men"]
  },
  {
    id: 25,
    name: "Best Brother Personalized Hamper",
    category: "Gifts",
    subcategory: "Personalized Hampers",
    gender: "Men",
    price: 1599,
    originalPrice: 1999,
    discount: 20,
    rating: 4.9,
    reviews: 63,
    badge: "Bestseller",
    images: [
      "https://lh3.googleusercontent.com/d/17xv2qFMXGeR4xbvXZHR6P1PZd5rLT2ab"
    ],
    sizes: ["Standard Box"],
    colors: ["Clear Acrylic"],
    description:
      "White formal dress shirt tied with a white satin ribbon and 'FOR MY BROTHER' tag, 'BEST BROTHER IN THE WORLD' greeting card/print, stainless steel wristwatch with black dial on an acrylic display stand, Bella Vita Luxury 'CEO Man' Eau De Parfum, black leather bifold wallet, black aviator sunglasses, two metal ballpoint pens (black & silver), two engraved silver-tone dog-tag keychains reading 'Best BROTHER —EVER—'. Presented in a clear acrylic display organizer tray/hamper box with custom molded compartments.",
    contents: [
      "White Formal Shirt ('FOR MY BROTHER')",
      "'BEST BROTHER' Greeting Card",
      "Stainless Steel Watch (Black Dial)",
      "Bella Vita CEO Man EDP",
      "Black Leather Wallet",
      "Aviator Sunglasses",
      "2x Metal Ballpoint Pens",
      "2x Engraved Dog-Tag Keychains"
    ],
    stock: 7,
    isNew: true,
    isFeatured: true,
    tags: ["Personalized", "Brother", "Shirt", "Watch", "Keychains", "Rakshabandhan"]
  },
  {
    id: 26,
    name: "OGGI Shirt Anniversary Hamper",
    category: "Gifts",
    subcategory: "Personalized Hampers",
    gender: "Unisex",
    price: 950,
    originalPrice: 1299,
    discount: 27,
    rating: 4.7,
    reviews: 30,
    badge: "Anniversary Special",
    images: [
      "https://lh3.googleusercontent.com/d/1wbq7oFke6M0TC2kvbACSq36rfT4LxCSn"
    ],
    sizes: ["Standard Box"],
    colors: ["Kraft/Wood"],
    description:
      "Brown/tan OGGI button-down casual shirt, wooden tabletop photo frame with a black-and-white couple photo collage and 'Anniversary' script, Ferrero Rocher chocolate pack, and cream/champagne artificial rosettes. Presented in a shallow wooden/kraft hamper box.",
    contents: [
      "OGGI Brown Casual Shirt",
      "Wooden Photo Frame (Anniversary Collage)",
      "Ferrero Rocher Pack",
      "Champagne Artificial Rosettes"
    ],
    stock: 14,
    isNew: false,
    isFeatured: false,
    tags: ["Anniversary", "Personalized", "Shirt", "Photo Frame", "Chocolates"]
  },
  {
    id: 27,
    name: "LP Plaid Shirt Husband Birthday Hamper",
    category: "Gifts",
    subcategory: "Personalized Hampers",
    gender: "Men",
    price: 650,
    originalPrice: 899,
    discount: 28,
    rating: 4.6,
    reviews: 25,
    badge: "Budget Friendly",
    images: [
      "https://lh3.googleusercontent.com/d/14c5dEypknWIRsy3bX0eOKnTLA8rVCjc2"
    ],
    sizes: ["Standard Box"],
    colors: ["Marble Pattern"],
    description:
      "Louis Philippe (LP) red/white/grey checkered slim-fit shirt, three mini Nestle KitKat bars, a framed heartfelt birthday message card for a husband with rose illustrations, and red-and-white artificial rosettes. Presented in a square marble/floral-patterned presentation box.",
    contents: [
      "LP Red/Grey Checkered Slim-Fit Shirt",
      "3x Mini KitKat Bars",
      "Framed Birthday Message Card",
      "Red & White Artificial Rosettes"
    ],
    stock: 21,
    isNew: false,
    isFeatured: false,
    tags: ["Personalized", "LP", "Shirt", "Husband", "Birthday"]
  },
  {
    id: 28,
    name: "Lalit Personalized Grooming Hamper",
    category: "Gifts",
    subcategory: "Personalized Hampers",
    gender: "Men",
    price: 1199,
    originalPrice: 1599,
    discount: 25,
    rating: 4.8,
    reviews: 41,
    badge: "Personalized",
    images: [
      "https://lh3.googleusercontent.com/d/12gniZniNUT6BLJKCQ6_eFy1VPzn-17PL"
    ],
    sizes: ["Standard Box"],
    colors: ["Matte Black"],
    description:
      "Light pink 'Cotton Candy' formal shirt, Denver 'Hamilton' deodorant spray, a CK-branded gold gift box, black square sunglasses, a black belt, a Nestle Munch bar, a Cadbury Dairy Milk Silk bar, a Hindi-script personalized keychain, a black thermos engraved 'Lalit', a silver wristwatch with white dial in a display box, a metallic red artificial rose with gold stem, and a black ballpoint pen, cushioned with pink crinkle paper. Presented in a matte black gift box.",
    contents: [
      "Light Pink Formal Shirt",
      "Denver Hamilton Deodorant",
      "Black Square Sunglasses",
      "Personalized Thermos (Lalit)",
      "Silver Wristwatch (White Dial)",
      "Personalized Hindi Keychain",
      "Cadbury Dairy Milk Silk Bar",
      "Nestle Munch Bar",
      "Metallic Red Artificial Rose"
    ],
    stock: 12,
    isNew: true,
    isFeatured: true,
    tags: ["Personalized", "Grooming", "Thermos", "Watch", "Birthday", "Shirt"]
  },

  // ─── COUPLE HAMPERS ───────────────────────────────────────────────────────
  {
    id: 29,
    name: "Couple Watch & Ring Anniversary Hamper",
    category: "Gifts",
    subcategory: "Couple Gifts",
    gender: "Unisex",
    price: 1399,
    originalPrice: 1899,
    discount: 26,
    rating: 4.9,
    reviews: 78,
    badge: "Bestseller",
    images: [
      "https://lh3.googleusercontent.com/d/1hFQSOw9t5FQYxBq2FOevNdpGJwajmLn-"
    ],
    sizes: ["Standard Box"],
    colors: ["Gold & Silver"],
    description:
      "Mini rose bouquet with baby's breath and a red ribbon bow, an anniversary greeting card, a two-tone gold-and-silver couple watch set on cushions, a dark brown men's bifold wallet, a floral-print women's bifold wallet/clutch with heart clasp, a Bella Vita 2-piece mini perfume duo (Skai Aquatic & Date Woman), a velvet ring box with two couple rings, and a heart-shaped Ferrero Rocher box (8 pieces).",
    contents: [
      "Rose Bouquet with Baby's Breath",
      "Anniversary Greeting Card",
      "Gold & Silver Couple Watch Set",
      "Men's Dark Brown Wallet",
      "Women's Floral Wallet/Clutch",
      "Bella Vita 2-Piece Perfume Duo",
      "Velvet Ring Box with Couple Rings",
      "Heart-Shaped Ferrero Rocher (8 pcs)"
    ],
    stock: 9,
    isNew: true,
    isFeatured: true,
    tags: ["Couple", "Anniversary", "Watch", "Ring", "Ferrero", "Perfume"]
  },
  {
    id: 30,
    name: "Renu & Rehan Personalized Couple Hamper",
    category: "Gifts",
    subcategory: "Couple Gifts",
    gender: "Unisex",
    price: 1050,
    originalPrice: 1499,
    discount: 30,
    rating: 4.8,
    reviews: 49,
    badge: "Personalized",
    images: [
      "https://lh3.googleusercontent.com/d/1Ktf1K641NkPY64QRiqGjIx2rKkvg24Yj"
    ],
    sizes: ["Standard Box"],
    colors: ["Black"],
    description:
      "Black American Eagle button-down shirt, Denver deodorant spray, a black insulated tumbler personalized 'Renu', black square sunglasses, a black-and-gold executive pen, a black leather bifold wallet, a leather keychain personalized 'Rehan', a white-dial analog wristwatch, Ferrero Rocher chocolates, a rolled black leather belt, and red-and-white artificial roses, cushioned with yellow crinkle paper. Lid features a heart-shaped photo collage with warm fairy string lights.",
    contents: [
      "Black American Eagle Shirt",
      "Denver Deodorant",
      "Personalized Tumbler (Renu)",
      "Black Square Sunglasses",
      "Black Leather Wallet",
      "Personalized Leather Keychain (Rehan)",
      "Analog Wristwatch",
      "Ferrero Rocher",
      "Heart-Shaped Photo Collage with Fairy Lights"
    ],
    stock: 11,
    isNew: false,
    isFeatured: true,
    tags: ["Couple", "Personalized", "Anniversary", "Shirt", "Watch", "Tumbler"]
  },

  // ─── ROMANTIC HAMPERS ─────────────────────────────────────────────────────
  {
    id: 31,
    name: "Romantic Rose & Teddy Bear Hamper",
    category: "Gifts",
    subcategory: "Couple Gifts",
    gender: "Unisex",
    price: 950,
    originalPrice: 1299,
    discount: 27,
    rating: 4.8,
    reviews: 64,
    badge: "Romantic",
    images: [
      "https://lh3.googleusercontent.com/d/1nJ6ylk5nsZlUu5igyTYU3WVbETENbe7t"
    ],
    sizes: ["Standard Box"],
    colors: ["Burgundy"],
    description:
      "Mini bouquet with a pink rose, red rose, and baby's breath tied with a pink bow and 'Just For You' tag, a 'You are Special' greeting card, a beige plush teddy bear with a bow tie, Bella women's Eau De Parfum (20ml) with rose-gold box, a Ferrero Rocher chocolate box, a Cadbury Dairy Milk Silk bar, a gold-tone heart-charm keychain tagged 'LOVE', and a mini glass message jar tied with gold twine. Cushioned with burgundy shredded crinkle paper.",
    contents: [
      "Pink & Red Rose Bouquet",
      "'You Are Special' Greeting Card",
      "Beige Plush Teddy Bear",
      "Bella Women's EDP (20ml)",
      "Ferrero Rocher Chocolate Box",
      "Cadbury Dairy Milk Silk Bar",
      "Gold Heart-Charm Keychain",
      "Mini Glass Message Jar"
    ],
    stock: 17,
    isNew: false,
    isFeatured: true,
    tags: ["Romantic", "Valentine", "Teddy", "Roses", "Chocolates", "Perfume"]
  },

  // ─── TEACHER'S DAY HAMPERS ────────────────────────────────────────────────
  {
    id: 32,
    name: "Teachers Day Polo Shirt Hamper",
    category: "Gifts",
    subcategory: "Teacher's Day Hamper",
    gender: "Men",
    price: 799,
    originalPrice: 1099,
    discount: 27,
    rating: 4.7,
    reviews: 33,
    badge: "Teacher's Day Special",
    images: [
      "https://lh3.googleusercontent.com/d/1ipvPJMw4cZbU6Tqbng7VcMLn8se-Zp2e"
    ],
    sizes: ["Standard Box"],
    colors: ["Red & White"],
    description:
      "White ribbed Mavie polo shirt, a black coffee mug, a mini bouquet of dried bunny-tail grass wrapped in black paper with a red ribbon, a pen/cartridge set, a dark journal/notebook, and a 'Happy Teachers Day' greeting card/tag with a red ribbon bow. Presented in a clear acrylic-lid gift box with a red base tray and white fabric lining.",
    contents: [
      "White Mavie Polo Shirt",
      "Black Coffee Mug",
      "Dried Bunny-Tail Grass Mini Bouquet",
      "Pen & Cartridge Set",
      "Dark Journal/Notebook",
      "'Happy Teachers Day' Greeting Card"
    ],
    stock: 20,
    isNew: true,
    isFeatured: false,
    tags: ["Teacher's Day", "Shirt", "Mug", "Journal", "Pen", "Gift"]
  }
];

export const giftCategories = [
  {
    id: "mens",
    name: "Men's Hampers",
    description: "Premium shirts, grooming essentials, watches, wallets and more — curated for him.",
    image: "https://lh3.googleusercontent.com/d/1pfwZEh4ESO4mBe3KLqAUXln5VgfUTrsB",
    link: "/men"
  },
  {
    id: "womens",
    name: "Women's Hampers",
    description: "Ethnic wear, perfumes, accessories and self-care hampers for every occasion.",
    image: "https://lh3.googleusercontent.com/d/10grmCxscyvNePDD6GZcjnT72NoUl1N81",
    link: "/women"
  },
  {
    id: "personalized",
    name: "Personalized Hampers",
    description: "Custom engraved gifts, name wallets, photo frames and monogrammed keepsakes.",
    image: "https://lh3.googleusercontent.com/d/1iE5cuh0nsMcSwCVcS3o_-TGDTTpLUNif",
    link: "/gifts?sub=Personalized Hampers"
  },
  {
    id: "couple",
    name: "Couple Gifts",
    description: "Romantic hampers with watches, rings, chocolates and roses for anniversaries.",
    image: "https://lh3.googleusercontent.com/d/1hFQSOw9t5FQYxBq2FOevNdpGJwajmLn-",
    link: "/gifts?sub=Couple Gifts"
  },
  {
    id: "birthday",
    name: "Birthday Hampers",
    description: "Make their birthday unforgettable with curated birthday surprise hampers.",
    image: "https://lh3.googleusercontent.com/d/1f1O37s4_tm9g1eXwHlxfnUnj53xuiME6",
    link: "/gifts?sub=Birthday Hampers"
  },
  {
    id: "onam",
    name: "Festive & Occasion",
    description: "Special Onam, Teacher's Day, and festive season gift hampers.",
    image: "https://lh3.googleusercontent.com/d/1gTg36hGOdB7k6B0_dbxcXF7CY868A9Ax",
    link: "/gifts?filter=new"
  }
];
