import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ToastProvider } from './context/ToastContext';
import { WishlistProvider } from './context/WishlistContext';
import { CartProvider } from './context/CartContext';
import { AuthProvider } from './context/AuthContext';
import { StoreProvider } from './context/StoreContext';
import { MainLayout } from './layouts/MainLayout';
import { ProtectedRoute } from './components/ProtectedRoute';

import { Home } from './pages/Home';
import { Men } from './pages/Men';
import { Women } from './pages/Women';
import { Gifts } from './pages/Gifts';
import { ProductDetails } from './pages/ProductDetails';
import { Cart } from './pages/Cart';
import { Checkout } from './pages/Checkout';
import { Payment } from './pages/Payment';
import { OrderSuccess } from './pages/OrderSuccess';
import { Wishlist } from './pages/Wishlist';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { Profile } from './pages/Profile';
import { About } from './pages/About';
import { Contact } from './pages/Contact';
import { TermsAndConditions } from './pages/TermsAndConditions';

import { AdminRoute } from './components/AdminRoute';
import { AdminLayout } from './layouts/AdminLayout';
import { AdminLogin } from './pages/admin/AdminLogin';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { AdminProducts } from './pages/admin/AdminProducts';
import { AdminProductForm } from './pages/admin/AdminProductForm';
import { AdminCategories } from './pages/admin/AdminCategories';
import { AdminOrders } from './pages/admin/AdminOrders';
import { AdminCustomers } from './pages/admin/AdminCustomers';
import { AdminReviews } from './pages/admin/AdminReviews';
import { AdminSettings } from './pages/admin/AdminSettings';

export function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <StoreProvider>
          <WishlistProvider>
            <CartProvider>
              <Router>
              <Routes>
                {/* ─── OWNER ADMIN ROUTES (COMPLETELY SEPARATE LAYOUT & PERMISSION) ─── */}
                <Route path="/admin/login" element={<AdminLogin />} />
                <Route
                  path="/admin"
                  element={
                    <AdminRoute>
                      <AdminLayout />
                    </AdminRoute>
                  }
                >
                  <Route index element={<Navigate to="/admin/dashboard" replace />} />
                  <Route path="dashboard" element={<AdminDashboard />} />
                  <Route path="products" element={<AdminProducts />} />
                  <Route path="products/add" element={<AdminProductForm />} />
                  <Route path="products/edit/:id" element={<AdminProductForm />} />
                  <Route path="categories" element={<AdminCategories />} />
                  <Route path="orders" element={<AdminOrders />} />
                  <Route path="customers" element={<AdminCustomers />} />
                  <Route path="reviews" element={<AdminReviews />} />
                  <Route path="settings" element={<AdminSettings />} />
                </Route>

                {/* ─── CUSTOMER-FACING STORE ROUTES (UNCHANGED MAIN LAYOUT) ─── */}
                <Route path="/" element={<MainLayout />}>
                  {/* Public Browsing Routes */}
                  <Route index element={<Home />} />
                  <Route path="men" element={<Men />} />
                  <Route path="women" element={<Women />} />
                  <Route path="gifts" element={<Gifts />} />
                  <Route path="product/:id" element={<ProductDetails />} />
                  <Route path="cart" element={<Cart />} />
                  <Route path="wishlist" element={<Wishlist />} />
                  <Route path="login" element={<Login />} />
                  <Route path="signup" element={<Signup />} />
                  <Route path="about" element={<About />} />
                  <Route path="contact" element={<Contact />} />
                  <Route path="terms-and-conditions" element={<TermsAndConditions />} />
                  <Route path="terms" element={<Navigate to="/terms-and-conditions" replace />} />

                  {/* Protected Routes (Require Customer Authentication) */}
                  <Route
                    path="checkout"
                    element={
                      <ProtectedRoute>
                        <Checkout />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="payment/:orderId"
                    element={
                      <ProtectedRoute>
                        <Payment />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="order-success/:orderId"
                    element={
                      <ProtectedRoute>
                        <OrderSuccess />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="order-success"
                    element={
                      <ProtectedRoute>
                        <OrderSuccess />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="profile"
                    element={
                      <ProtectedRoute>
                        <Profile />
                      </ProtectedRoute>
                    }
                  />
                  <Route path="account" element={<Navigate to="/profile" replace />} />
                  <Route path="profile/orders" element={<Navigate to="/profile?tab=orders" replace />} />
                  <Route path="profile/wishlist" element={<Navigate to="/profile?tab=wishlist" replace />} />
                  <Route path="profile/addresses" element={<Navigate to="/profile?tab=addresses" replace />} />
                  <Route path="profile/settings" element={<Navigate to="/profile?tab=settings" replace />} />
                  <Route path="profile/offers" element={<Navigate to="/profile?tab=offers" replace />} />
                  <Route path="profile/gift-vouchers" element={<Navigate to="/profile?tab=vouchers" replace />} />

                  {/* Fallback */}
                  <Route path="*" element={<Home />} />
                </Route>
              </Routes>
            </Router>
          </CartProvider>
        </WishlistProvider>
      </StoreProvider>
    </AuthProvider>
  </ToastProvider>
  );
}

export default App;
