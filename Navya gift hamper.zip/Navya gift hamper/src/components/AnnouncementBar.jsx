import React from 'react';
import { Mail, Sparkles } from 'lucide-react';
import { InstagramIcon } from './SocialIcons';
import { useStore } from '../context/StoreContext';

export const AnnouncementBar = () => {
  const { announcement, email, instagram } = useStore();

  const announcementText = announcement?.text || 'Free Premium Gift Packaging & Complimentary Gift Cards';
  const displayEmail = announcement?.email || email || 'Supportnavya0@gmail.com';
  const displayInstagram = announcement?.instagram || (instagram.includes('.com/') ? '@' + instagram.split('.com/')[1].split('?')[0] : '@navyagift_hamper');
  const instagramLink = instagram || 'https://www.instagram.com/navyagift_hamper?stkn=aDl5N3Q1NHZkb2Fv';

  // A single announcement item set matching the exact specifications
  const renderItemSet = (keyPrefix) => (
    <div key={keyPrefix} className="inline-flex items-center shrink-0">
      {/* 1. Instagram Link */}
      <a
        href={instagramLink}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-1.5 text-[#E8D7BE] hover:text-[#C8A45D] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C8A45D] rounded px-1 group/link"
        aria-label={`Follow on Instagram: ${displayInstagram}`}
      >
        <InstagramIcon className="w-3 h-3 text-[#C8A45D] shrink-0 transition-transform group-hover/link:scale-110" />
        <span className="font-medium tracking-wide">{displayInstagram}</span>
      </a>

      {/* Separator */}
      <span className="text-[#C8A45D]/60 mx-3 sm:mx-5 select-none font-serif text-xs" aria-hidden="true">
        •
      </span>

      {/* 2. Support Email Link */}
      <a
        href={`mailto:${displayEmail}`}
        className="inline-flex items-center gap-1.5 text-[#E8D7BE] hover:text-[#C8A45D] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#C8A45D] rounded px-1 group/link"
        aria-label={`Send email to ${displayEmail}`}
      >
        <Mail className="w-3 h-3 text-[#C8A45D] shrink-0 transition-transform group-hover/link:scale-110" />
        <span className="font-medium tracking-wide">{displayEmail}</span>
      </a>

      {/* Separator */}
      <span className="text-[#C8A45D]/60 mx-3 sm:mx-5 select-none font-serif text-xs" aria-hidden="true">
        •
      </span>

      {/* 3. Informational Text */}
      <span className="inline-flex items-center gap-1.5 text-[#F5E6D3] select-none">
        <Sparkles className="w-3 h-3 text-[#C8A45D] shrink-0 animate-pulse" />
        <span className="font-medium tracking-wide">
          {announcementText}
        </span>
      </span>

      {/* Trailing Separator to loop seamlessly to next repetition */}
      <span className="text-[#C8A45D]/60 mx-3 sm:mx-5 select-none font-serif text-xs" aria-hidden="true">
        •
      </span>
    </div>
  );

  return (
    <aside
      aria-label="Announcements & Quick Support"
      className="marquee-container w-full bg-[#141210] text-[#E8D7BE] text-[10px] sm:text-[11px] md:text-xs border-b border-[#2C261F] overflow-hidden relative z-50 h-7 sm:h-7.5 md:h-8 flex items-center select-none"
    >
      {/* 
        The outer flex wrapper contains two identical halves (half-1 and half-2).
        The CSS animation luxuryMarquee translates this wrapper from 0% to -50%.
        When half-1 has moved fully out of view, half-2 sits in its exact original spot,
        guaranteeing an infinitely seamless, uninterrupted loop with zero stutter or jumps.
      */}
      <div className="animate-luxury-marquee flex items-center whitespace-nowrap">
        {/* Half 1 */}
        <div className="flex items-center shrink-0">
          {renderItemSet('half1-rep1')}
          {renderItemSet('half1-rep2')}
          {renderItemSet('half1-rep3')}
        </div>

        {/* Half 2 (Exact mirror copy for zero-jump seamless loop) */}
        <div className="flex items-center shrink-0" aria-hidden="true">
          {renderItemSet('half2-rep1')}
          {renderItemSet('half2-rep2')}
          {renderItemSet('half2-rep3')}
        </div>
      </div>
    </aside>
  );
};
