import React from 'react';
import { Link } from 'react-router-dom';
import logoSrc from '../../photos/logo-new.png';
import { useStore } from '../context/StoreContext';

/**
 * BrandLogo — Reusable official logo component for Navya Gift Hamper.
 *
 * Props:
 *  @param {string}  className    - Extra classes for the wrapper element
 *  @param {string}  imgClassName - Extra classes for the <img> tag
 *  @param {boolean} asLink       - Wrap logo in a <Link to="/"> (default: true)
 *  @param {string}  height       - Tailwind height class (default: 'h-12')
 *  @param {boolean} showName     - Show company name text next to logo (default: true)
 *  @param {string}  nameColor    - Tailwind text-color class for company name
 */
export const BrandLogo = ({
  className = '',
  imgClassName = '',
  asLink = true,
  height = 'h-12',
  showName = true,
  nameColor = 'text-[#1a1815]',
}) => {
  const { storeName } = useStore();
  const words = (storeName || 'Navya Gift Hamper').split(' ');
  const firstWord = words[0] || 'Navya';
  const restWords = words.slice(1).join(' ') || 'Gift Hamper';

  const content = (
    <span className="inline-flex items-center gap-2.5">
      {/* Logo image */}
      <img
        src={logoSrc}
        alt={`${storeName} — Official Logo`}
        className={`${height} w-auto object-contain object-center select-none flex-shrink-0 ${imgClassName}`}
        draggable={false}
      />

      {/* Company name */}
      {showName && (
        <span className="flex flex-col leading-tight select-none">
          <span
            className={`font-serif font-bold tracking-wide uppercase ${nameColor}`}
            style={{ fontSize: 'clamp(0.75rem, 1.5vw, 1.1rem)' }}
          >
            {firstWord}
          </span>
          <span
            className={`font-sans font-semibold tracking-[0.18em] uppercase text-[#C8A45D]`}
            style={{ fontSize: 'clamp(0.55rem, 1vw, 0.72rem)' }}
          >
            {restWords}
          </span>
        </span>
      )}
    </span>
  );

  if (asLink) {
    return (
      <Link
        to="/"
        className={`inline-flex items-center focus:outline-none ${className}`}
        aria-label="Navya Gift Hamper — Home"
      >
        {content}
      </Link>
    );
  }

  return (
    <div className={`inline-flex items-center ${className}`}>
      {content}
    </div>
  );
};
