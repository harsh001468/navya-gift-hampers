import React, { useState } from 'react';
import { X } from 'lucide-react';
import { useStore } from '../context/StoreContext';

// Official WhatsApp Brand Icon (standard speech-bubble + phone logo)
export const WhatsAppIcon = ({ className = "w-7 h-7" }) => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
    aria-hidden="true"
  >
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
  </svg>
);

export const FloatingWhatsApp = () => {
  const [showNotification, setShowNotification] = useState(true);
  const { whatsapp, storeName } = useStore();
  const whatsappUrl = whatsapp || 'https://wa.me/message/SE4USKU3N2UNE1';

  return (
    <aside
      aria-label="Customer Support"
      className="fixed bottom-6 right-6 z-50 flex flex-col items-end space-y-2 select-none pointer-events-auto"
    >
      {/* Floating Prompt Notification */}
      {showNotification && (
        <div className="bg-[#171717] text-[#F5E6D3] text-xs py-2 px-3.5 rounded-xl shadow-2xl border border-[#C8A45D]/40 flex items-center gap-2.5 max-w-xs animate-bounce font-sans">
          <span className="font-semibold text-white">Chat with {storeName}</span>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setShowNotification(false);
            }}
            className="text-stone-400 hover:text-white p-0.5 transition-colors focus:outline-none ml-1"
            aria-label="Close message"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Circular Floating WhatsApp Button with subtle hover/scale animation */}
      <div className="relative group">
        {/* Subtle hover tooltip */}
        <div
          role="tooltip"
          className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-neutral-900/95 text-white text-xs font-medium rounded-lg shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none border border-white/10 hidden sm:block"
        >
          Chat with {storeName}
          <span className="absolute left-full top-1/2 -translate-y-1/2 -ml-1 border-4 border-transparent border-l-neutral-900/95" />
        </div>

        {/* Pulse effect in background */}
        <span
          className="absolute inset-0 rounded-full bg-[#25D366] opacity-35 animate-ping -z-10 pointer-events-none"
          aria-hidden="true"
        />

        {/* Floating circular button */}
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Chat with Navya Gift Hamper"
          title="Chat with Navya Gift Hamper"
          className="w-14 h-14 rounded-full bg-[#25D366] hover:bg-[#20ba59] text-white flex items-center justify-center shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-110 active:scale-95 focus:outline-none focus:ring-4 focus:ring-[#25D366]/40 cursor-pointer"
        >
          <WhatsAppIcon className="w-7 h-7 text-white fill-current drop-shadow-sm" />
        </a>
      </div>
    </aside>
  );
};
