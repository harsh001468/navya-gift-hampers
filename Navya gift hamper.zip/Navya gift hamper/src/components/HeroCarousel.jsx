import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const HeroCarousel = () => {
  const { homepage } = useStore();

  const slides = [
    {
      id: 1,
      title: homepage?.hero_title || "Gifts Made Beautiful",
      subtitle: homepage?.hero_subtitle || "Thoughtfully curated hampers for unforgettable moments.",
      ctaText: homepage?.cta_text || "Shop Now",
      ctaLink: homepage?.cta_link || "/gifts",
      image: homepage?.banner_image || "https://lh3.googleusercontent.com/d/1iE5cuh0nsMcSwCVcS3o_-TGDTTpLUNif",
      tag: homepage?.hero_tag || "CURATED WITH LOVE"
    },
    {
      id: 2,
      title: "Celebrate Love",
      subtitle: "Beautiful gifts for birthdays, anniversaries and special moments.",
      ctaText: "Shop Couple Gifts",
      ctaLink: "/gifts?sub=Couple Gifts",
      image: "https://lh3.googleusercontent.com/d/1hFQSOw9t5FQYxBq2FOevNdpGJwajmLn-",
      tag: "ANNIVERSARY & COUPLE EDITS"
    },
    {
      id: 3,
      title: "Personalized With Emotion",
      subtitle: "Make your gift truly yours with personalized keepsakes.",
      ctaText: "Explore Personalized",
      ctaLink: "/gifts?sub=Personalized Hampers",
      image: "https://lh3.googleusercontent.com/d/1wR5sAybaPB2tiHIOZHI8PFnvPAcO1q9P",
      tag: "BESPOKE ENGRAVING"
    },
    {
      id: 4,
      title: "Luxury Couple Hampers",
      subtitle: "Thoughtfully curated hampers for celebrating togetherness.",
      ctaText: "Shop Couple Hampers",
      ctaLink: "/gifts?sub=Couple Gifts",
      image: "https://lh3.googleusercontent.com/d/1v7QnjA6NFLURcJ0HETabL0uy_rLMvKNW",
      tag: "ROMANTIC & SPECIAL"
    },
    {
      id: 5,
      title: "Something Special For Everyone",
      subtitle: "Find the perfect gift for every occasion.",
      ctaText: "Explore Gifts",
      ctaLink: "/gifts",
      image: "https://lh3.googleusercontent.com/d/10grmCxscyvNePDD6GZcjnT72NoUl1N81",
      tag: "FOR HIM & FOR HER"
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const touchStartX = useRef(0);
  const touchEndX = useRef(0);

  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % slides.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [currentIndex, isPaused, slides.length]);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % slides.length);
  };

  const handleTouchStart = (e) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (touchStartX.current - touchEndX.current > 50) {
      nextSlide();
    } else if (touchEndX.current - touchStartX.current > 50) {
      prevSlide();
    }
  };

  const currentSlide = slides[currentIndex];

  return (
    <section
      className="relative w-full h-[550px] sm:h-[650px] bg-[#171717] text-[#FFFFFF] overflow-hidden group select-none"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Background Image with Ken Burns Subtle Zoom */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide.id}
          initial={{ opacity: 0, scale: 1.08 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
          className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${currentSlide.image})` }}
        />
      </AnimatePresence>

      {/* Luxury Dark Gradient Vignette — stronger for product shots */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0d0c0a]/95 via-black/55 to-black/70 z-0" />

      {/* Hero Content Box */}
      <div className="relative z-10 max-w-4xl mx-auto h-full px-4 sm:px-6 flex flex-col justify-center items-center text-center space-y-6 pt-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col items-center space-y-4"
          >
            <span className="inline-block text-[10px] sm:text-xs font-bold uppercase tracking-[0.3em] text-[#C8A45D] px-3.5 py-1 rounded-full bg-black/60 border border-[#C8A45D]/40 backdrop-blur-xs">
              {currentSlide.tag}
            </span>

            <h1 className="font-serif text-3xl sm:text-6xl md:text-7xl font-bold tracking-tight text-white uppercase leading-[1.1] max-w-3xl">
              {currentSlide.title}
            </h1>

            <p className="font-serif italic text-base sm:text-2xl text-[#E8D7BE] max-w-xl font-light">
              “{currentSlide.subtitle}”
            </p>

            <div className="pt-3 flex items-center justify-center gap-4">
              <Link
                to={currentSlide.ctaLink}
                className="bg-[#C8A45D] hover:bg-[#d4b472] text-[#171717] text-xs uppercase font-bold tracking-[0.2em] px-8 py-3.5 sm:px-9 sm:py-4 rounded-md shadow-xl transition-all transform hover:-translate-y-0.5 flex items-center gap-2"
              >
                <span>{currentSlide.ctaText}</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/40 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-xs border border-white/20 transition-all opacity-0 group-hover:opacity-100"
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/40 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-xs border border-white/20 transition-all opacity-0 group-hover:opacity-100"
        aria-label="Next slide"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Pagination Dots */}
      <div className="absolute bottom-6 inset-x-0 z-20 flex justify-center items-center space-x-2">
        {slides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentIndex(idx)}
            className={`transition-all duration-300 rounded-full ${
              currentIndex === idx
                ? 'w-8 h-2 bg-[#C8A45D]'
                : 'w-2 h-2 bg-white/50 hover:bg-white'
            }`}
            aria-label={`Go to slide ${idx + 1}`}
          />
        ))}
      </div>
    </section>
  );
};
