import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  ShoppingBag,
  Heart,
  User,
  Menu,
  X,
  ChevronRight,
  Mail
} from 'lucide-react';
import { InstagramIcon } from './SocialIcons';
import { BrandLogo } from './BrandLogo';
import { AnnouncementBar } from './AnnouncementBar';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { useAuth } from '../context/AuthContext';

export const Navbar = ({ onOpenSearch, onOpenAccount }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { cartItemCount, setIsCartOpen } = useCart();
  const { wishlistCount } = useWishlist();
  const { user, profile } = useAuth();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { name: 'Women', path: '/women' },
    { name: 'Men', path: '/men' },
    { name: 'Gift Hampers', path: '/gifts' },
    { name: 'New Arrivals', path: '/gifts?filter=new' },
    { name: 'Offers', path: '/gifts?filter=offers' }
  ];

  const activeLink = (path) => {
    if (path.includes('?')) {
      return location.pathname + location.search === path;
    }
    return location.pathname === path;
  };

  return (
    <header className="sticky top-0 z-40 w-full transition-all duration-300">
      {/* Top Rolling Marquee Announcement Bar */}
      <AnnouncementBar />

      {/* Main Responsive Header */}
      <nav
        className={`w-full transition-all duration-300 bg-[#F8F5F0] border-b border-[#E7E2DA] ${
          isScrolled ? 'shadow-md py-3' : 'py-4 sm:py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between min-h-[55px]">
          
          {/* Mobile Left: Hamburger Icon */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-2 text-[#171717] hover:text-[#C8A45D] transition-colors focus:outline-none"
              aria-label="Open Navigation Menu"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>

          {/* Center / Left Logo */}
          <div className="flex items-center">
            <BrandLogo height="h-10 sm:h-12 lg:h-14" />
          </div>

          {/* Desktop Navigation Center Links */}
          <div className="hidden lg:flex items-center space-x-7">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`relative text-xs tracking-[0.14em] uppercase font-semibold transition-colors py-1 ${
                  activeLink(link.path)
                    ? 'text-[#C8A45D]'
                    : 'text-[#171717] hover:text-[#C8A45D]'
                }`}
              >
                {link.name}
                {link.name === 'Offers' && (
                  <span className="absolute -top-2 -right-3 px-1 py-0.2 bg-rose-700 text-[8px] text-white font-bold rounded-full uppercase tracking-tighter">
                    Sale
                  </span>
                )}
                {activeLink(link.path) && (
                  <motion.div
                    layoutId="activeNav"
                    className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#C8A45D]"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </Link>
            ))}
          </div>

          {/* Right Icons (Desktop & Mobile) */}
          <div className="flex items-center space-x-1 sm:space-x-3">
            {/* Search */}
            <button
              onClick={onOpenSearch}
              className="p-2 text-[#171717] hover:text-[#C8A45D] transition-colors focus:outline-none"
              aria-label="Search"
              title="Search"
            >
              <Search className="w-5 h-5 stroke-[1.75]" />
            </button>

            {/* Account (Mobile & Desktop) */}
            <button
              onClick={onOpenAccount}
              className="p-2 text-[#171717] hover:text-[#C8A45D] transition-colors relative focus:outline-none flex items-center gap-1.5 cursor-pointer"
              aria-label="Account"
              title={user ? profile?.name || user.email : 'Sign In / Account'}
            >
              {user ? (
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-full bg-[#1a1815] text-[#c5a880] text-[11px] font-bold flex items-center justify-center font-serif">
                    {(profile?.name || user.email)?.[0]?.toUpperCase()}
                  </div>
                  <span className="hidden md:inline text-xs font-semibold text-stone-900 max-w-[100px] truncate">
                    {profile?.name?.split(' ')[0] || user.email.split('@')[0]}
                  </span>
                </div>
              ) : (
                <User className="w-5 h-5 stroke-[1.75]" />
              )}
            </button>

            {/* Wishlist */}
            <Link
              to="/wishlist"
              className="p-2 text-[#171717] hover:text-[#C8A45D] transition-colors relative focus:outline-none"
              aria-label="Wishlist"
              title="Wishlist"
            >
              <Heart className="w-5 h-5 stroke-[1.75]" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 bg-[#C8A45D] text-white text-[9px] w-4 h-4 font-bold rounded-full flex items-center justify-center leading-none">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {/* Shopping Bag / Cart */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="p-2 text-[#171717] hover:text-[#C8A45D] transition-colors relative focus:outline-none flex items-center gap-1"
              aria-label="Shopping Cart"
              title="Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5 stroke-[1.75]" />
              {cartItemCount > 0 && (
                <span className="bg-[#171717] text-[#F8F5F0] text-[9px] w-4 h-4 font-bold rounded-full flex items-center justify-center leading-none">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileMenuOpen(false)}
              className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="fixed inset-y-0 left-0 z-50 w-4/5 max-w-xs bg-[#F8F5F0] shadow-2xl flex flex-col justify-between border-r border-[#E7E2DA]"
            >
              <div>
                <div className="p-5 flex items-center justify-between border-b border-[#E7E2DA]">
                  <BrandLogo height="h-10" asLink={false} />
                  <button
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-2 text-[#171717]"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Account quick badge */}
                <div className="p-4 bg-[#faf8f5] border-b border-[#E7E2DA]">
                  {user ? (
                    <Link
                      to="/profile"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center justify-between p-3 bg-white rounded-xl border border-[#e8dfd1] shadow-xs"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-[#1a1815] text-[#c5a880] text-sm font-bold flex items-center justify-center font-serif">
                          {(profile?.name || user.email)?.[0]?.toUpperCase()}
                        </div>
                        <div>
                          <span className="font-serif font-bold text-sm text-stone-900 block truncate max-w-[150px]">
                            {profile?.name || user.email.split('@')[0]}
                          </span>
                          <span className="text-[10px] text-[#8c7355] font-semibold">View Profile & Orders</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-400" />
                    </Link>
                  ) : (
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        onOpenAccount();
                      }}
                      className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-bold uppercase tracking-wider py-3 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                    >
                      <User className="w-4 h-4 text-[#c5a880]" />
                      <span>Sign In / Register</span>
                    </button>
                  )}
                </div>

                <div className="py-4 px-5 space-y-4">
                  {navLinks.map((link) => (
                    <Link
                      key={link.name}
                      to={link.path}
                      className="flex items-center justify-between py-2 text-xs tracking-widest uppercase font-semibold text-[#171717] hover:text-[#C8A45D] border-b border-[#E7E2DA]"
                    >
                      <span>{link.name}</span>
                      <ChevronRight className="w-4 h-4 text-[#777777]" />
                    </Link>
                  ))}
                  <div className="pt-2 space-y-2">
                    <Link
                      to="/about"
                      className="block text-xs uppercase tracking-widest text-[#777777] hover:text-black py-1"
                    >
                      Our Story & Philosophy
                    </Link>
                    <Link
                      to="/contact"
                      className="block text-xs uppercase tracking-widest text-[#777777] hover:text-black py-1"
                    >
                      Contact Concierge
                    </Link>
                  </div>
                </div>
              </div>

              <div className="p-5 border-t border-[#E7E2DA] bg-[#E8D7BE]/30 space-y-3">
                <div className="flex flex-col gap-2 text-xs text-[#171717]">
                  <a
                    href="https://www.instagram.com/navyagift_hamper?stkn=aDl5N3Q1NHZkb2Fv"
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-2 hover:text-[#C8A45D] transition-colors"
                  >
                    <InstagramIcon className="w-4 h-4 text-[#C8A45D]" />
                    <span>@navyagift_hamper</span>
                  </a>
                  <a
                    href="mailto:Supportnavya0@gmail.com"
                    className="flex items-center gap-2 hover:text-[#C8A45D] transition-colors"
                  >
                    <Mail className="w-4 h-4 text-[#C8A45D]" />
                    <span>Supportnavya0@gmail.com</span>
                  </a>
                </div>
                <p className="text-xs text-[#777777] font-serif italic text-center pt-2 border-t border-[#E7E2DA]/60">
                  “Curated with Love, Gifted with Emotion.”
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
};
