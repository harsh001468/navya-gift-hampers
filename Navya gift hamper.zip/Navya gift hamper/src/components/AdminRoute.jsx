import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { Loader2, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AccessDenied } from './AccessDenied';

export const AdminRoute = ({ children }) => {
  const { user, profile, loading, verifyOwner } = useAuth();
  const location = useLocation();
  const [verifying, setVerifying] = useState(true);
  const [isAuthorizedOwner, setIsAuthorizedOwner] = useState(false);

  useEffect(() => {
    let active = true;

    async function checkOwnerAuthorization() {
      if (loading) return;

      if (!user) {
        if (active) {
          setIsAuthorizedOwner(false);
          setVerifying(false);
        }
        return;
      }

      // 1. Verify email matches configured owner email: supportnavya0@gmail.com
      const userEmail = (user.email || '').toLowerCase().trim();
      if (userEmail !== 'supportnavya0@gmail.com') {
        if (active) {
          setIsAuthorizedOwner(false);
          setVerifying(false);
        }
        return;
      }

      // 2. Verify role in database
      const dbConfirmed = await verifyOwner();
      if (active) {
        setIsAuthorizedOwner(dbConfirmed);
        setVerifying(false);
      }
    }

    checkOwnerAuthorization();

    return () => {
      active = false;
    };
  }, [user, profile?.role, loading]);

  if (loading || verifying) {
    return (
      <div className="min-h-screen bg-stone-950 flex flex-col items-center justify-center space-y-4">
        <div className="relative">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-500 animate-pulse">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <Loader2 className="w-6 h-6 text-amber-400 animate-spin absolute -bottom-2 -right-2" />
        </div>
        <div className="text-center">
          <p className="font-serif text-stone-200 text-base tracking-wide">Navya Gift Hamper</p>
          <span className="text-[11px] font-mono text-stone-400 uppercase tracking-widest">
            Verifying Owner Credentials...
          </span>
        </div>
      </div>
    );
  }

  // Not authenticated at all -> redirect to admin login
  if (!user) {
    return (
      <Navigate
        to={`/admin/login?returnTo=${encodeURIComponent(location.pathname + location.search)}`}
        state={{ from: location }}
        replace
      />
    );
  }

  // Authenticated, but not the authorized Owner account -> strictly display Access Denied
  if (!isAuthorizedOwner) {
    return <AccessDenied />;
  }

  return children;
};
