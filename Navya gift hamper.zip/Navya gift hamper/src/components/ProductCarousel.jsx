import React, { useRef, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { ProductCard } from './ProductCard';

export const ProductCarousel = ({ title, subtitle, products = [], viewAllLink, autoSlide = true }) => {
  const scrollRef = useRef(null);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (!autoSlide || isPaused || products.length === 0) return;

    const interval = setInterval(() => {
      if (scrollRef.current) {
        const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
        // Check if reached near the end
        if (scrollLeft + clientWidth >= scrollWidth - 20) {
          scrollRef.current.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          scrollRef.current.scrollBy({ left: 280, behavior: 'smooth' });
        }
      }
    }, 3800);

    return () => clearInterval(interval);
  }, [autoSlide, isPaused, products.length]);

  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -280, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      if (scrollLeft + clientWidth >= scrollWidth - 20) {
        scrollRef.current.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        scrollRef.current.scrollBy({ left: 280, behavior: 'smooth' });
      }
    }
  };

  return (
    <section
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 my-12"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={() => setIsPaused(true)}
      onTouchEnd={() => setIsPaused(false)}
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#E7E2DA] pb-4">
        <div>
          <h2 className="font-serif text-2xl sm:text-4xl font-bold text-[#171717] uppercase tracking-wide">
            {title}
          </h2>
          {subtitle && (
            <p className="font-serif italic text-xs sm:text-sm text-[#777777] mt-1">
              “{subtitle}”
            </p>
          )}
        </div>

        <div className="flex items-center justify-between sm:justify-end gap-3">
          {viewAllLink && (
            <Link
              to={viewAllLink}
              className="text-xs font-bold uppercase tracking-widest text-[#171717] hover:text-[#C8A45D] flex items-center gap-1 transition-colors mr-2"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          )}

          <div className="flex items-center gap-2">
            <button
              onClick={scrollLeft}
              className="w-9 h-9 rounded-full border border-[#E7E2DA] bg-white hover:bg-[#171717] hover:text-white text-[#171717] flex items-center justify-center transition-colors shadow-xs"
              aria-label="Previous Products"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={scrollRight}
              className="w-9 h-9 rounded-full border border-[#E7E2DA] bg-white hover:bg-[#171717] hover:text-white text-[#171717] flex items-center justify-center transition-colors shadow-xs"
              aria-label="Next Products"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Horizontal Carousel Track with Automatic Smooth Sliding */}
      <div
        ref={scrollRef}
        className="flex gap-4 sm:gap-6 overflow-x-auto no-scrollbar py-2 snap-x-mandatory"
        style={{ scrollSnapType: 'x mandatory' }}
      >
        {products.map((product) => (
          <div
            key={product.id}
            className="w-[72%] sm:w-[32%] lg:w-[23.5%] shrink-0 snap-start"
          >
            <ProductCard product={product} />
          </div>
        ))}
      </div>
    </section>
  );
};
