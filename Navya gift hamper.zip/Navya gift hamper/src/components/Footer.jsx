import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, ArrowRight, ShieldCheck, Truck, Gift, Mail } from 'lucide-react';
import { InstagramIcon } from './SocialIcons';
import { WhatsAppIcon } from './FloatingWhatsApp';
import { useToast } from '../context/ToastContext';
import { useStore } from '../context/StoreContext';
import { BrandLogo } from './BrandLogo';

export const Footer = () => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const { addToast } = useToast();
  const { storeName, tagline, email: storeEmail, phone: storePhone, whatsapp: storeWhatsapp, instagram: storeInstagram, address: storeAddress } = useStore();

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      addToast('Thank you for subscribing to Navya Privé updates!', 'success');
      setNewsletterEmail('');
    }
  };

  return (
    <footer className="bg-[#141210] text-[#e3d5c3] pt-16 pb-10 border-t border-[#2e2820]">
      {/* Value Proposition Strip */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-14 border-b border-[#2e2820]/80">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div className="flex flex-col items-center p-4">
            <Gift className="w-6 h-6 text-[#c5a880] mb-3 stroke-[1.5]" />
            <h4 className="font-serif text-sm tracking-wider uppercase text-white font-medium">Free Packaging</h4>
            <p className="text-xs text-stone-400 mt-1 font-sans">Complimentary luxury gift box with ribbon</p>
          </div>
          <div className="flex flex-col items-center p-4">
            <Truck className="w-6 h-6 text-[#c5a880] mb-3 stroke-[1.5]" />
            <h4 className="font-serif text-sm tracking-wider uppercase text-white font-medium">Pan-India Delivery</h4>
            <p className="text-xs text-stone-400 mt-1 font-sans">Safe & insured express shipping</p>
          </div>
          <div className="flex flex-col items-center p-4">
            <Heart className="w-6 h-6 text-[#c5a880] mb-3 stroke-[1.5]" />
            <h4 className="font-serif text-sm tracking-wider uppercase text-white font-medium">100% Curated</h4>
            <p className="text-xs text-stone-400 mt-1 font-sans">Personalized cards & hand-picked items</p>
          </div>
          <div className="flex flex-col items-center p-4">
            <ShieldCheck className="w-6 h-6 text-[#c5a880] mb-3 stroke-[1.5]" />
            <h4 className="font-serif text-sm tracking-wider uppercase text-white font-medium">Premium Assurance</h4>
            <p className="text-xs text-stone-400 mt-1 font-sans">Quality guaranteed on every order</p>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-4 pr-0 lg:pr-8">
            <BrandLogo height="h-14" nameColor="text-white" />
            <p className="font-serif italic text-stone-300 text-sm leading-relaxed max-w-md">
              “{tagline}”
            </p>
            <p className="text-xs text-stone-400 leading-relaxed font-sans max-w-sm">
              {storeName} turns special moments into beautiful memories with bespoke gifts, artisanal chocolates, fragrances, watches, and personalized keepsakes.
            </p>
            <div className="pt-2 flex items-center space-x-3 text-stone-300">
              <a
                href={storeInstagram}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#24201a] flex items-center justify-center hover:bg-[#c5a880] hover:text-black transition-colors"
                aria-label="Instagram"
                title="Follow us on Instagram"
              >
                <InstagramIcon className="w-4 h-4" />
              </a>
              <a
                href={`mailto:${storeEmail}`}
                className="w-9 h-9 rounded-full bg-[#24201a] flex items-center justify-center hover:bg-[#c5a880] hover:text-black transition-colors"
                aria-label="Email Support"
                title={`Email ${storeEmail}`}
              >
                <Mail className="w-4 h-4" />
              </a>
              <a
                href={storeWhatsapp}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#24201a] flex items-center justify-center hover:bg-[#25D366] hover:text-white transition-colors"
                aria-label="WhatsApp Concierge"
                title={`WhatsApp: ${storePhone}`}
              >
                <WhatsAppIcon className="w-4 h-4 text-white fill-current" />
              </a>
            </div>

            {/* Quick Contact snippet */}
            <div className="pt-2 text-xs text-stone-400 space-y-1 font-sans">
              <p className="flex items-center gap-2">
                <WhatsAppIcon className="w-3.5 h-3.5 text-[#25D366] shrink-0" />
                <a
                  href={storeWhatsapp}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white transition-colors"
                >
                  {storePhone}
                </a>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#c5a880] shrink-0" />
                <a href={`mailto:${storeEmail}`} className="hover:text-white transition-colors">
                  {storeEmail}
                </a>
              </p>
              <p className="flex items-center gap-2">
                <InstagramIcon className="w-3.5 h-3.5 text-[#c5a880] shrink-0" />
                <a
                  href={storeInstagram}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white transition-colors"
                >
                  {storeInstagram.includes('.com/') ? '@' + storeInstagram.split('.com/')[1].split('?')[0] : '@navyagift_hamper'}
                </a>
              </p>
              {storeAddress && (
                <p className="text-[11px] text-stone-500 pt-0.5">
                  Studio: {storeAddress}
                </p>
              )}
            </div>
          </div>


          {/* Column 1: Shop */}
          <div className="space-y-3">
            <h4 className="font-serif text-sm tracking-[0.2em] text-white uppercase font-semibold">
              Shop
            </h4>
            <ul className="space-y-2 text-xs text-stone-400 font-sans">
              <li>
                <Link to="/women" className="hover:text-[#c5a880] transition-colors">Women's Collection</Link>
              </li>
              <li>
                <Link to="/men" className="hover:text-[#c5a880] transition-colors">Men's Collection</Link>
              </li>
              <li>
                <Link to="/gifts" className="hover:text-[#c5a880] transition-colors">Gift Hampers</Link>
              </li>
              <li>
                <Link to="/gifts?sub=Personalized Hampers" className="hover:text-[#c5a880] transition-colors">Personalized Gifts</Link>
              </li>
              <li>
                <Link to="/gifts?sub=Couple Gifts" className="hover:text-[#c5a880] transition-colors">Couple Gifts</Link>
              </li>
              <li>
                <Link to="/gifts?filter=new" className="hover:text-[#c5a880] transition-colors">New Arrivals</Link>
              </li>
            </ul>
          </div>

          {/* Column 2: Help & Company */}
          <div className="space-y-3">
            <h4 className="font-serif text-sm tracking-[0.2em] text-white uppercase font-semibold">
              Company
            </h4>
            <ul className="space-y-2 text-xs text-stone-400 font-sans">
              <li>
                <Link to="/about" className="hover:text-[#c5a880] transition-colors">Our Story & Philosophy</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-[#c5a880] transition-colors">Contact Studio</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-[#c5a880] transition-colors">Shipping & Delivery</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-[#c5a880] transition-colors">Returns & Exchange</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-[#c5a880] transition-colors">FAQ & Support</Link>
              </li>
              <li className="pt-1">
                <a href="mailto:Supportnavya0@gmail.com" className="hover:text-white transition-colors flex items-center gap-1.5">
                  <Mail className="w-3 h-3 text-[#c5a880]" />
                  <span>Supportnavya0@gmail.com</span>
                </a>
              </li>
              <li>
                <a
                  href="https://www.instagram.com/navyagift_hamper?stkn=aDl5N3Q1NHZkb2Fv"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <InstagramIcon className="w-3 h-3 text-[#c5a880]" />
                  <span>Instagram</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Newsletter */}
          <div className="space-y-3">
            <h4 className="font-serif text-sm tracking-[0.2em] text-white uppercase font-semibold">
              Join Privé Club
            </h4>
            <p className="text-xs text-stone-400 leading-relaxed font-sans">
              Receive VIP invitations to seasonal hamper releases, curated gifting advice, and exclusive offers.
            </p>
            <form onSubmit={handleSubscribe} className="pt-1">
              <div className="relative flex items-center">
                <input
                  type="email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Your email address"
                  required
                  className="w-full bg-[#24201a] text-white text-xs px-3.5 py-2.5 rounded-l-md border border-[#3e352b] focus:outline-none focus:border-[#c5a880] placeholder-stone-500"
                />
                <button
                  type="submit"
                  className="bg-[#c5a880] text-black px-3.5 py-2.5 rounded-r-md hover:bg-[#d8bd98] transition-colors flex items-center justify-center focus:outline-none"
                  aria-label="Subscribe"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>

        </div>
      </div>

      {/* Bottom Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 border-t border-[#2e2820]/60 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-400 gap-4">
        <p className="text-center sm:text-left">
          © 2026 Navya Gift Hamper. All rights reserved. Crafted with love in India.
        </p>
        <div className="flex space-x-6">
          <Link to="/about" className="hover:text-stone-300">Privacy Policy</Link>
          <Link to="/terms-and-conditions" className="hover:text-stone-300">Terms & Conditions</Link>
        </div>
      </div>
    </footer>
  );
};
