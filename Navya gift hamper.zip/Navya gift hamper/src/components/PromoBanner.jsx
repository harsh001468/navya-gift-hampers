import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Gift, ArrowRight } from 'lucide-react';

export const PromoBanner = ({ variant = 'special' }) => {
  if (variant === 'special') {
    return (
      <section className="relative my-16 overflow-hidden bg-[#1a1815] text-[#faf8f5] py-20 px-6 sm:px-12 rounded-xl shadow-2xl max-w-7xl mx-auto border border-[#3e352b]">
        {/* Background Overlay */}
        <div
          className="absolute inset-0 opacity-20 bg-cover bg-center mix-blend-overlay"
          style={{
            backgroundImage:
              'url(https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&q=80&w=1600)'
          }}
        />

        <div className="relative z-10 max-w-2xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-[#c5a880] px-3 py-1 rounded-full bg-[#2a241e] border border-[#4a3d30]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Exquisite Craftsmanship</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-white leading-tight">
            MAKE THEIR DAY EXTRA SPECIAL
          </h2>

          <p className="font-serif italic text-lg text-stone-300">
            “Thoughtfully curated hampers. Personalized details. Beautiful memories.”
          </p>

          <div className="pt-2">
            <Link
              to="/gifts"
              className="inline-flex items-center gap-2 bg-[#c5a880] hover:bg-[#d4b993] text-black text-xs uppercase font-bold tracking-widest px-8 py-4 rounded-md shadow-lg transition-all transform hover:-translate-y-0.5"
            >
              <span>SHOP GIFT HAMPERS</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="my-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="bg-[#f5f0e6] border border-[#e5dccb] rounded-xl p-8 sm:p-12 text-center flex flex-col items-center space-y-4 shadow-xs">
        <div className="w-12 h-12 rounded-full bg-[#1a1815] text-[#c5a880] flex items-center justify-center">
          <Gift className="w-6 h-6 stroke-[1.5]" />
        </div>
        <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#1a1815] tracking-wide">
          FREE PREMIUM GIFT PACKAGING
        </h3>
        <p className="font-serif italic text-base text-[#8c7a65] max-w-md">
          “Because presentation matters as much as the present.”
        </p>
        <p className="text-xs text-stone-600 max-w-lg font-sans">
          Every Navya order arrives hand-wrapped in our signature rigid presentation box, tied with satin ribbon, and accompanied by a custom wax-sealed greeting card.
        </p>
      </div>
    </section>
  );
};
