import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, TrendingUp, Sparkles, ChevronRight } from 'lucide-react';
import { productService } from '../services/productService';

export const SearchModal = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const popularSearches = [
    'Anniversary',
    'Couple Hamper',
    'Leather Wallet',
    'Perfume',
    'Preserved Rose',
    'Birthday',
    'Personalized Hamper'
  ];

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  useEffect(() => {
    let active = true;
    if (!query.trim()) {
      setResults((prev) => (prev.length === 0 ? prev : []));
      return;
    }

    setLoading(true);
    const timer = setTimeout(async () => {
      const res = await productService.searchProducts(query);
      if (active) {
        setResults(res);
        setLoading(false);
      }
    }, 200);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [query]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs"
        />

        {/* Modal Window */}
        <div className="relative min-h-screen flex items-start justify-center pt-16 px-4 pb-20">
          <motion.div
            initial={{ opacity: 0, y: -30, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.98 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="relative w-full max-w-2xl bg-[#faf8f5] rounded-xl shadow-2xl overflow-hidden border border-[#e8dfd1] z-10"
          >
            {/* Search Input Bar */}
            <div className="p-4 sm:p-6 border-b border-[#e8dfd1] flex items-center gap-3 bg-white">
              <Search className="w-5 h-5 text-[#8c7355] shrink-0" />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search hampers, gifts, perfumes, watches..."
                className="w-full bg-transparent text-[#1a1815] text-base sm:text-lg focus:outline-none placeholder-stone-400 font-sans"
              />
              {query && (
                <button
                  onClick={() => setQuery('')}
                  className="text-stone-400 hover:text-stone-700 text-xs uppercase tracking-wider font-semibold"
                >
                  Clear
                </button>
              )}
              <button
                onClick={onClose}
                className="p-1 text-stone-500 hover:text-black rounded-full hover:bg-stone-100 transition-colors"
                aria-label="Close search"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Results or Suggested Tags */}
            <div className="p-6 max-h-[65vh] overflow-y-auto">
              {!query && (
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#8c7a65] mb-3">
                      <TrendingUp className="w-4 h-4 text-[#8c7355]" />
                      <span>Trending Searches</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {popularSearches.map((tag) => (
                        <button
                          key={tag}
                          onClick={() => setQuery(tag)}
                          className="bg-white hover:bg-[#8c7355] hover:text-white text-[#2c2824] border border-[#e8dfd1] text-xs px-3.5 py-1.5 rounded-full transition-all duration-200"
                        >
                          {tag}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 bg-[#f4efe6] rounded-lg border border-[#e5dccb]">
                    <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#4a3c2c] mb-1">
                      <Sparkles className="w-4 h-4 text-[#8c7355]" />
                      <span>Need Personal Guidance?</span>
                    </div>
                    <p className="text-xs text-stone-600 leading-relaxed font-sans">
                      Our concierge gifting team can customize any hamper with personal notes, custom sizes, and specialized branding.
                    </p>
                  </div>
                </div>
              )}

              {loading && (
                <div className="py-8 text-center text-sm text-stone-500 font-sans">
                  Searching Navya collection...
                </div>
              )}

              {!loading && query && results.length === 0 && (
                <div className="py-10 text-center space-y-2">
                  <p className="text-base font-serif font-semibold text-stone-800">
                    No gift hampers matching "{query}"
                  </p>
                  <p className="text-xs text-stone-500">
                    Try searching for "Perfume", "Couple", "Leather", "Chocolate", or "Rose".
                  </p>
                </div>
              )}

              {!loading && results.length > 0 && (
                <div className="space-y-4">
                  <div className="text-xs font-semibold uppercase tracking-widest text-[#8c7a65]">
                    Found {results.length} Curated Gift{results.length > 1 ? 's' : ''}
                  </div>
                  <div className="divide-y divide-[#eee6d8]">
                    {results.map((item) => (
                      <Link
                        key={item.id}
                        to={`/product/${item.id}`}
                        onClick={onClose}
                        className="py-3 flex items-center gap-4 group hover:bg-white p-2 rounded-lg transition-colors"
                      >
                        <img
                          src={item.images[0]}
                          alt={item.name}
                          className="w-14 h-14 object-cover rounded-md bg-stone-100"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs uppercase tracking-wider text-[#8c7a65] font-sans">
                            {item.category} • {item.subcategory}
                          </p>
                          <h4 className="font-serif font-semibold text-sm text-[#1a1815] group-hover:text-[#8c7355] truncate">
                            {item.name}
                          </h4>
                          <span className="text-xs font-bold text-[#1a1815] font-sans">
                            ₹{item.price.toLocaleString('en-IN')}
                          </span>
                        </div>
                        <ChevronRight className="w-5 h-5 text-stone-400 group-hover:text-[#8c7355] transition-colors" />
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </AnimatePresence>
  );
};
