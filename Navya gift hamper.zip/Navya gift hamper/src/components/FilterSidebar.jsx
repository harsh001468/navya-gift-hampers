import React from 'react';
import { RotateCcw, X, SlidersHorizontal } from 'lucide-react';

export const FilterSidebar = ({
  filters,
  setFilters,
  resetFilters,
  availableSubcategories = [],
  isMobileOpen = false,
  onCloseMobile = () => {}
}) => {
  const handleCategoryToggle = (subcat) => {
    setFilters((prev) => {
      const exists = prev.subcategories.includes(subcat);
      const updated = exists
        ? prev.subcategories.filter((s) => s !== subcat)
        : [...prev.subcategories, subcat];
      return { ...prev, subcategories: updated };
    });
  };

  const handlePriceChange = (e) => {
    setFilters((prev) => ({ ...prev, maxPrice: Number(e.target.value) }));
  };

  const handleBadgeToggle = (badge) => {
    setFilters((prev) => {
      const exists = prev.badges.includes(badge);
      const updated = exists
        ? prev.badges.filter((b) => b !== badge)
        : [...prev.badges, badge];
      return { ...prev, badges: updated };
    });
  };

  const content = (
    <div className="space-y-6 text-sm font-sans">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-[#e8dfd1]">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-[#8c7355]" />
          <h3 className="font-serif text-base font-bold tracking-wider text-[#1a1815] uppercase">
            Filters
          </h3>
        </div>
        <button
          onClick={resetFilters}
          className="text-xs text-[#8c7a65] hover:text-[#1a1815] flex items-center gap-1 font-semibold uppercase tracking-wider transition-colors"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      {/* Subcategories */}
      {availableSubcategories.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-serif font-bold text-xs uppercase tracking-widest text-[#1a1815]">
            Subcategory
          </h4>
          <div className="space-y-2">
            {availableSubcategories.map((subcat) => {
              const isChecked = filters.subcategories.includes(subcat);
              return (
                <label
                  key={subcat}
                  className="flex items-center gap-2.5 text-xs text-stone-700 hover:text-stone-900 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={() => handleCategoryToggle(subcat)}
                    className="accent-[#8c7355] w-4 h-4 rounded-xs border-stone-300"
                  />
                  <span>{subcat}</span>
                </label>
              );
            })}
          </div>
        </div>
      )}

      {/* Price Range Slider */}
      <div className="space-y-3 pt-4 border-t border-[#e8dfd1]">
        <div className="flex justify-between items-center">
          <h4 className="font-serif font-bold text-xs uppercase tracking-widest text-[#1a1815]">
            Max Price
          </h4>
          <span className="text-xs font-bold text-[#8c7355]">
            ₹{filters.maxPrice.toLocaleString('en-IN')}
          </span>
        </div>
        <input
          type="range"
          min={1000}
          max={8000}
          step={500}
          value={filters.maxPrice}
          onChange={handlePriceChange}
          className="w-full accent-[#8c7355] cursor-pointer"
        />
        <div className="flex justify-between text-[11px] text-stone-500 font-sans">
          <span>₹1,000</span>
          <span>₹8,000</span>
        </div>
      </div>

      {/* Badge Filter */}
      <div className="space-y-3 pt-4 border-t border-[#e8dfd1]">
        <h4 className="font-serif font-bold text-xs uppercase tracking-widest text-[#1a1815]">
          Curated Collection
        </h4>
        <div className="flex flex-wrap gap-2">
          {['Bestseller', 'Personalized', 'Trending', 'Luxury', 'New'].map((badge) => {
            const isSelected = filters.badges.includes(badge);
            return (
              <button
                key={badge}
                onClick={() => handleBadgeToggle(badge)}
                className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                  isSelected
                    ? 'bg-[#1a1815] text-white border-[#1a1815]'
                    : 'bg-white text-stone-700 border-[#e8dfd1] hover:border-[#8c7355]'
                }`}
              >
                {badge}
              </button>
            );
          })}
        </div>
      </div>

      {/* In Stock Only Toggle */}
      <div className="pt-4 border-t border-[#e8dfd1]">
        <label className="flex items-center justify-between text-xs text-stone-700 cursor-pointer">
          <span className="font-medium">In Stock Items Only</span>
          <input
            type="checkbox"
            checked={filters.inStockOnly}
            onChange={(e) =>
              setFilters((prev) => ({ ...prev, inStockOnly: e.target.checked }))
            }
            className="accent-[#8c7355] w-4 h-4 rounded-xs"
          />
        </label>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar Container */}
      <aside className="hidden lg:block w-64 shrink-0 pr-6">
        <div className="sticky top-24 bg-white p-5 rounded-lg border border-[#e8dfd1] shadow-xs">
          {content}
        </div>
      </aside>

      {/* Mobile Drawer */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            onClick={onCloseMobile}
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
          />
          <div className="fixed inset-y-0 left-0 w-4/5 max-w-xs bg-[#faf8f5] p-6 shadow-2xl overflow-y-auto border-r border-[#e8dfd1]">
            <div className="flex justify-between items-center mb-6">
              <span className="font-serif font-bold text-lg text-[#1a1815]">REFINE SELECTION</span>
              <button onClick={onCloseMobile} className="p-1 text-stone-500">
                <X className="w-5 h-5" />
              </button>
            </div>
            {content}
          </div>
        </div>
      )}
    </>
  );
};
