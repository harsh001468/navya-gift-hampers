import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, User, Lock, Mail, Phone, ArrowRight, LogOut, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export const AccountModal = ({ isOpen, onClose }) => {
  const [mode, setMode] = useState('login'); // 'login' | 'signup'
  const { user, profile, signIn, signUp, signOut } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();

  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [signupData, setSignupData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    const res = await signIn({
      email: loginData.email,
      password: loginData.password
    });
    setIsSubmitting(false);

    if (res.success) {
      onClose();
    }
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    if (!signupData.name.trim()) {
      addToast('Please enter your full name', 'error');
      return;
    }
    if (!signupData.email.trim()) {
      addToast('Please enter your email address', 'error');
      return;
    }
    if (!signupData.phone.trim()) {
      addToast('Please enter your mobile number', 'error');
      return;
    }
    if (!signupData.password || signupData.password.length < 6) {
      addToast('Password must be at least 6 characters long', 'error');
      return;
    }
    if (signupData.password !== signupData.confirmPassword) {
      addToast('Passwords do not match', 'error');
      return;
    }

    setIsSubmitting(true);
    const res = await signUp({
      email: signupData.email.trim(),
      password: signupData.password,
      name: signupData.name.trim(),
      phone: signupData.phone.trim()
    });
    setIsSubmitting(false);

    if (res.success) {
      setSignupData({
        name: '',
        email: '',
        phone: '',
        password: '',
        confirmPassword: ''
      });
      onClose();
    }
  };

  const handleSignOut = async () => {
    await signOut();
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs"
        />

        <div className="min-h-screen flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="relative w-full max-w-md bg-[#faf8f5] rounded-xl shadow-2xl overflow-hidden border border-[#e8dfd1] z-10"
          >
            {/* Header */}
            <div className="p-6 bg-white border-b border-[#e8dfd1] text-center relative">
              <button
                onClick={onClose}
                className="absolute top-4 right-4 text-stone-400 hover:text-black p-1"
              >
                <X className="w-5 h-5" />
              </button>
              <h3 className="font-serif text-2xl font-bold tracking-widest text-[#1a1815] uppercase">
                NAVYA PRIVÉ
              </h3>
              <p className="text-xs text-[#8c7a65] font-serif italic mt-1">
                {user
                  ? 'Your Luxury Account'
                  : mode === 'login'
                  ? 'Sign in to access your saved hampers & orders'
                  : 'Create your gifting account'}
              </p>
            </div>

            {/* If Logged In View */}
            {user ? (
              <div className="p-6 space-y-4 font-sans text-xs">
                <div className="bg-white rounded-xl p-4 border border-[#e8dfd1] space-y-2 text-center shadow-xs">
                  <div className="w-14 h-14 rounded-full bg-[#1a1815] text-[#c5a880] mx-auto flex items-center justify-center font-serif text-xl font-bold shadow-inner">
                    {(profile?.name || user.email)?.[0]?.toUpperCase()}
                  </div>
                  <h4 className="font-serif text-lg font-bold text-stone-900">
                    {profile?.name || user.email.split('@')[0]}
                  </h4>
                  <p className="text-stone-500 text-[11px]">{user.email}</p>
                  <span className="inline-block text-[9px] bg-[#f5f0e6] text-[#8c7355] font-bold uppercase tracking-widest px-2.5 py-0.5 rounded-full border border-[#e8dfd1]">
                    ✨ Navya Privé Member
                  </span>
                </div>

                <div className="divide-y divide-[#f0e8dc] border border-[#e8dfd1] rounded-xl overflow-hidden bg-white">
                  {[
                    { label: 'My Profile', tab: 'overview' },
                    { label: 'My Orders', tab: 'orders' },
                    { label: 'Wishlist', tab: 'wishlist' },
                    { label: 'Offers & Coupons', tab: 'offers' },
                    { label: 'Gift Vouchers', tab: 'vouchers' },
                    { label: 'Saved Addresses', tab: 'addresses' },
                    { label: 'Account Settings', tab: 'settings' },
                    { label: 'Help & Support', tab: 'help' }
                  ].map((item) => (
                    <button
                      key={item.tab}
                      onClick={() => {
                        onClose();
                        navigate(`/profile?tab=${item.tab}`);
                      }}
                      className="w-full text-left px-4 py-2.5 text-stone-700 hover:bg-[#faf8f5] hover:text-[#8c7355] font-semibold flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span>{item.label}</span>
                      <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleSignOut}
                  className="w-full bg-rose-50 hover:bg-rose-100 text-rose-700 py-2.5 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2 border border-rose-200 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Log Out</span>
                </button>
              </div>
            ) : (
              /* Logged Out Forms */
              <div className="p-6 space-y-5">
                {mode === 'login' ? (
                  <form onSubmit={handleLogin} className="space-y-4 font-sans text-xs">
                    <div>
                      <label className="block text-stone-700 font-semibold mb-1">Email Address</label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                        <input
                          type="email"
                          required
                          value={loginData.email}
                          onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                          placeholder="you@example.com"
                          className="w-full bg-white border border-[#e8dfd1] rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-stone-700 font-semibold">Password</label>
                        <a href="#forgot" onClick={(e) => e.preventDefault()} className="text-[11px] text-[#8c7355] hover:underline">
                          Forgot Password?
                        </a>
                      </div>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                        <input
                          type="password"
                          required
                          value={loginData.password}
                          onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                          placeholder="••••••••"
                          className="w-full bg-white border border-[#e8dfd1] rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white font-semibold py-3 rounded-md uppercase tracking-wider transition-colors shadow-md flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      <span>{isSubmitting ? 'Signing In...' : 'Sign In'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </form>
                ) : (
                  <form onSubmit={handleSignup} className="space-y-3 font-sans text-xs">
                    <div>
                      <label className="block text-stone-700 font-semibold mb-1">Full Name</label>
                      <div className="relative">
                        <User className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                        <input
                          type="text"
                          required
                          value={signupData.name}
                          onChange={(e) => setSignupData({ ...signupData, name: e.target.value })}
                          placeholder="Enter your full name"
                          className="w-full bg-white border border-[#e8dfd1] rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-stone-700 font-semibold mb-1">Email Address</label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                        <input
                          type="email"
                          required
                          value={signupData.email}
                          onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                          placeholder="Enter your email address"
                          className="w-full bg-white border border-[#e8dfd1] rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-stone-700 font-semibold mb-1">Mobile Number</label>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                        <input
                          type="tel"
                          required
                          maxLength={10}
                          value={signupData.phone}
                          onChange={(e) => setSignupData({ ...signupData, phone: e.target.value.replace(/\D/g, '') })}
                          placeholder="10-digit mobile number"
                          className="w-full bg-white border border-[#e8dfd1] rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-stone-700 font-semibold mb-1">Password</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                        <input
                          type="password"
                          required
                          value={signupData.password}
                          onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                          placeholder="••••••••"
                          className="w-full bg-white border border-[#e8dfd1] rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-stone-700 font-semibold mb-1">Confirm Password</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                        <input
                          type="password"
                          required
                          value={signupData.confirmPassword}
                          onChange={(e) => setSignupData({ ...signupData, confirmPassword: e.target.value })}
                          placeholder="••••••••"
                          className="w-full bg-white border border-[#e8dfd1] rounded-md py-2.5 pl-9 pr-3 text-stone-900 focus:outline-none focus:border-[#8c7355]"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white font-semibold py-3 rounded-md uppercase tracking-wider transition-colors shadow-md flex items-center justify-center gap-2 mt-2 disabled:opacity-50"
                    >
                      <span>{isSubmitting ? 'Creating Account...' : 'Create Account'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </form>
                )}

                <div className="pt-3 border-t border-[#e8dfd1] text-center">
                  {mode === 'login' ? (
                    <p className="text-xs text-stone-600">
                      New to Navya Gift Hamper?{' '}
                      <button
                        onClick={() => setMode('signup')}
                        className="text-[#8c7355] font-bold hover:underline ml-1"
                      >
                        Create an Account
                      </button>
                    </p>
                  ) : (
                    <p className="text-xs text-stone-600">
                      Already have an account?{' '}
                      <button
                        onClick={() => setMode('login')}
                        className="text-[#8c7355] font-bold hover:underline ml-1"
                      >
                        Sign In
                      </button>
                    </p>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </AnimatePresence>
  );
};

