import React from 'react';
import { ArrowUpDown } from 'lucide-react';

export const SortDropdown = ({ sortOption, setSortOption }) => {
  return (
    <div className="flex items-center gap-2 text-xs font-sans">
      <ArrowUpDown className="w-3.5 h-3.5 text-[#8c7355]" />
      <span className="text-stone-500 font-medium uppercase tracking-wider hidden sm:inline">
        Sort By:
      </span>
      <select
        value={sortOption}
        onChange={(e) => setSortOption(e.target.value)}
        className="bg-white border border-[#e8dfd1] text-[#1a1815] font-semibold text-xs py-2 px-3 rounded-md focus:outline-none focus:border-[#8c7355] cursor-pointer"
      >
        <option value="featured">Featured & Recommended</option>
        <option value="price-asc">Price: Low to High</option>
        <option value="price-desc">Price: High to Low</option>
        <option value="rating">Highest Rated</option>
        <option value="newest">Newest Arrivals</option>
      </select>
    </div>
  );
};
