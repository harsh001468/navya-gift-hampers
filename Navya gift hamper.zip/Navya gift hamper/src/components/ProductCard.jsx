import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Star, ShoppingBag, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';

export const ProductCard = ({ product }) => {
  const [isHovered, setIsHovered] = useState(false);
  const { addToCart } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();

  const isLiked = isInWishlist(product.id);

  const mainImage = (Array.isArray(product.images) && product.images[0]) || '';
  const secondaryImage = (Array.isArray(product.images) && product.images[1]) || mainImage;
  const [imgError, setImgError] = useState(false);

  const handleQuickAdd = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };

  const handleWishlist = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product);
  };

  const displayImage = imgError ? secondaryImage : (isHovered ? secondaryImage : mainImage);

  return (
    <div
      className="group relative flex flex-col bg-white rounded-xl overflow-hidden border border-[#eae3d5] shadow-xs hover:shadow-xl transition-all duration-500"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Wrapper */}
      <div className="relative aspect-4/5 w-full overflow-hidden bg-[#f7f4ef]">
        <Link to={`/product/${product.id}`} className="block w-full h-full">
          <img
            src={displayImage}
            alt={product.name}
            onError={() => {
              if (!imgError && secondaryImage !== mainImage) {
                setImgError(true);
              }
            }}
            className="w-full h-full object-cover object-center img-hover-zoom transition-all duration-700"
            loading="lazy"
            referrerPolicy="no-referrer"
          />
        </Link>

        {/* Badge Tag / Availability Status */}
        {(!product.inStock || (product.stockQuantity !== undefined && product.stockQuantity <= 0)) ? (
          <div className="absolute top-3 left-3 z-10">
            <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-sm shadow-xs text-white bg-rose-600">
              Out of Stock
            </span>
          </div>
        ) : (
          <div className="absolute top-3 left-3 z-10 flex flex-col gap-1">
            {product.badge ? (
              <span
                className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-sm shadow-xs text-white ${
                  product.badge === 'Bestseller'
                    ? 'bg-[#1a1815]'
                    : product.badge === 'Personalized'
                    ? 'bg-[#8c7355]'
                    : product.badge === 'Trending'
                    ? 'bg-rose-800'
                    : 'bg-[#4a3c2c]'
                }`}
              >
                {product.badge}
              </span>
            ) : (
              <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-sm shadow-xs text-emerald-800 bg-emerald-50 border border-emerald-200 backdrop-blur-xs">
                In Stock
              </span>
            )}
          </div>
        )}

        {/* Wishlist Button */}
        <button
          onClick={handleWishlist}
          className={`absolute top-3 right-3 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
            isLiked
              ? 'bg-rose-50 text-rose-600 shadow-md'
              : 'bg-white/80 text-stone-700 hover:bg-white hover:text-rose-600 backdrop-blur-xs'
          }`}
          aria-label="Add to Wishlist"
        >
          <motion.div whileTap={{ scale: 0.7 }}>
            <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-600 text-rose-600' : ''}`} />
          </motion.div>
        </button>

        {/* Quick Add Overlay Button on Hover (Desktop) */}
        <div className="hidden sm:flex absolute inset-x-3 bottom-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 gap-2">
          {(!product.inStock || (product.stockQuantity !== undefined && product.stockQuantity <= 0)) ? (
            <button
              disabled
              className="flex-1 bg-stone-700/80 text-white/90 text-xs uppercase font-semibold tracking-wider py-2.5 px-3 rounded-md shadow-lg cursor-not-allowed"
            >
              Out of Stock
            </button>
          ) : (
            <button
              onClick={handleQuickAdd}
              className="flex-1 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-semibold tracking-wider py-2.5 px-3 rounded-md shadow-lg flex items-center justify-center gap-1.5 transition-colors duration-200 cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Add to Cart</span>
            </button>
          )}
          <Link
            to={`/product/${product.id}`}
            className="bg-white hover:bg-stone-100 text-[#1a1815] p-2.5 rounded-md shadow-lg flex items-center justify-center transition-colors"
            title="View Details"
          >
            <Eye className="w-4 h-4" />
          </Link>
        </div>
      </div>

      {/* Details Container */}
      <div className="p-4 flex flex-col flex-grow justify-between bg-white space-y-3">
        <div>
          {/* Subcategory & Rating */}
          <div className="flex items-center justify-between text-[11px] uppercase tracking-wider text-[#8c7a65] mb-1 font-sans">
            <span className="truncate max-w-[140px]">{product.subcategory || product.category}</span>
            <div className="flex items-center gap-1 text-amber-600 shrink-0">
              <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
              <span className="font-semibold">{product.rating}</span>
              <span className="text-stone-400">({product.reviews})</span>
            </div>
          </div>

          {/* Product Name */}
          <Link
            to={`/product/${product.id}`}
            className="block font-serif text-base font-semibold text-[#1a1815] hover:text-[#8c7355] transition-colors leading-snug line-clamp-1"
          >
            {product.name}
          </Link>
        </div>

        {/* Price & Add to Cart Action */}
        <div className="pt-2 border-t border-[#f4efe6] space-y-2.5">
          <div className="flex items-baseline gap-2">
            <span className="font-sans text-base font-bold text-[#1a1815]">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-stone-400 line-through">
                ₹{product.originalPrice.toLocaleString('en-IN')}
              </span>
            )}
            {product.discount > 0 && (
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-sm">
                {product.discount}% OFF
              </span>
            )}
          </div>

          {/* Mobile visible Add to Cart button */}
          <div className="sm:hidden pt-1">
            <button
              onClick={handleQuickAdd}
              disabled={!product.inStock}
              className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase font-semibold tracking-wider py-2 px-3 rounded-md flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>{product.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
