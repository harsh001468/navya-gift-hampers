import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldAlert, ArrowLeft, Home, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const AccessDenied = () => {
  const { user, profile, signOut } = useAuth();

  return (
    <div className="min-h-screen bg-stone-900 text-stone-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-stone-950 border border-stone-800 rounded-2xl p-8 text-center shadow-2xl relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 mx-auto flex items-center justify-center mb-6 shadow-inner">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <span className="text-[11px] font-mono tracking-widest uppercase text-rose-400 bg-rose-950/60 border border-rose-900/50 px-3 py-1 rounded-full inline-block mb-3">
          403 Forbidden
        </span>

        <h1 className="font-serif text-2xl text-stone-100 mb-2 font-medium tracking-wide">
          Access Denied
        </h1>

        <p className="text-stone-400 text-sm leading-relaxed mb-6">
          This portal is restricted exclusively to authorized <strong className="text-stone-200">Navya Gift Hamper Store Owners</strong>.
          Your current account (<span className="text-stone-300 font-mono text-xs">{user?.email || 'Customer'}</span>) has the role of <strong className="text-amber-400 uppercase text-xs tracking-wider">{profile?.role || 'customer'}</strong> and does not have administrative privileges.
        </p>

        <div className="p-3.5 bg-stone-900/80 border border-stone-800 rounded-xl mb-6 text-left text-xs text-stone-400">
          <div className="flex items-center justify-between mb-1">
            <span className="text-stone-500">Security Clearance</span>
            <span className="text-rose-400 font-semibold">Owner Only</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-stone-500">Database Action</span>
            <span className="text-stone-300">Administrative APIs Locked</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Link
            to="/"
            className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-medium text-xs tracking-wider uppercase transition-all duration-200 shadow-lg shadow-amber-900/20"
          >
            <Home className="w-4 h-4" />
            Return to Store
          </Link>

          <button
            onClick={() => signOut()}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-medium tracking-wider uppercase transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Switch Account
          </button>
        </div>
      </div>
    </div>
  );
};
