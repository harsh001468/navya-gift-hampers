import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-3">
        <Loader2 className="w-8 h-8 text-[#8c7355] animate-spin" />
        <span className="text-xs font-sans text-stone-500 uppercase tracking-widest">
          Verifying secure session...
        </span>
      </div>
    );
  }

  if (!user) {
    // Redirect to login while preserving the attempted destination
    return <Navigate to={`/login?returnTo=${encodeURIComponent(location.pathname + location.search)}`} state={{ from: location }} replace />;
  }

  return children;
};
