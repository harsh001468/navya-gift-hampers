import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Trash2, Plus, Minus, ShoppingBag, Gift, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { AuthPromptModal } from './AuthPromptModal';

export const CartDrawer = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    updateQuantity,
    removeFromCart,
    cartSubtotal,
    cartItemCount,
    includeGiftWrap,
    setIncludeGiftWrap
  } = useCart();

  const { user } = useAuth();
  const [showAuthPrompt, setShowAuthPrompt] = React.useState(false);
  const navigate = useNavigate();

  if (!isCartOpen && !showAuthPrompt) return null;

  const handleCheckout = () => {
    setIsCartOpen(false);
    if (!user) {
      setShowAuthPrompt(true);
    } else {
      navigate('/checkout');
    }
  };

  return (
    <>
      <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setIsCartOpen(false)}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        />

        <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="w-screen max-w-md bg-[#faf8f5] shadow-2xl flex flex-col justify-between border-l border-[#e8dfd1]"
          >
            {/* Drawer Header */}
            <div className="p-5 bg-white border-b border-[#e8dfd1] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-[#8c7355]" />
                <h3 className="font-serif text-lg font-bold tracking-wider text-[#1a1815] uppercase">
                  Your Gift Bag ({cartItemCount})
                </h3>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-1.5 text-stone-500 hover:text-black rounded-full hover:bg-stone-100 transition-colors"
                aria-label="Close Bag"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Gift Box Promo Banner inside Drawer */}
            <div className="bg-[#1a1815] text-[#e3d5c3] px-4 py-2.5 text-xs flex items-center justify-between border-b border-[#363028]">
              <div className="flex items-center gap-2">
                <Gift className="w-4 h-4 text-[#c5a880]" />
                <span>Complimentary Luxury Box & Ribbon</span>
              </div>
              <span className="text-[10px] uppercase tracking-wider bg-[#c5a880] text-black font-bold px-1.5 py-0.5 rounded-xs">
                Included
              </span>
            </div>

            {/* Drawer Body - Items List */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-12">
                  <div className="w-16 h-16 rounded-full bg-[#f4efe6] flex items-center justify-center text-[#8c7355]">
                    <ShoppingBag className="w-8 h-8 stroke-[1.5]" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-serif text-xl font-semibold text-[#1a1815]">
                      YOUR GIFT BAG IS EMPTY
                    </h4>
                    <p className="text-xs text-stone-500 max-w-xs font-sans">
                      Discover something beautiful for someone special.
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      navigate('/gifts');
                    }}
                    className="mt-2 bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase tracking-widest font-semibold px-6 py-3 rounded-md transition-colors"
                  >
                    Explore Hampers
                  </button>
                </div>
              ) : (
                cart.map((item) => (
                  <div
                    key={item.key}
                    className="flex gap-4 p-3 bg-white rounded-lg border border-[#e8dfd1] shadow-xs"
                  >
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-20 h-24 object-cover rounded-md bg-stone-100 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex-1 flex flex-col justify-between min-w-0">
                      <div>
                        <div className="flex justify-between items-start">
                          <h4 className="font-serif text-sm font-semibold text-[#1a1815] leading-snug line-clamp-1 pr-2">
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => removeFromCart(item.key)}
                            className="text-stone-400 hover:text-rose-600 transition-colors p-0.5"
                            title="Remove"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="text-[11px] text-stone-500 mt-0.5 font-sans">
                          Variant: {item.selectedSize}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        {/* Quantity Controls */}
                        <div className="flex items-center border border-[#d8cbb8] rounded-md bg-[#faf8f5]">
                          <button
                            onClick={() => updateQuantity(item.key, item.quantity - 1)}
                            className="p-1 text-stone-600 hover:text-black transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2.5 text-xs font-bold font-sans text-[#1a1815]">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.key, item.quantity + 1)}
                            className="p-1 text-stone-600 hover:text-black transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Price */}
                        <span className="font-sans font-bold text-sm text-[#1a1815]">
                          ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Drawer Footer */}
            {cart.length > 0 && (
              <div className="p-5 bg-white border-t border-[#e8dfd1] space-y-4">
                {/* Gift Wrap Checkbox */}
                <label className="flex items-center gap-2 cursor-pointer p-2.5 bg-[#f5f0e6] rounded-md border border-[#e5dccb]">
                  <input
                    type="checkbox"
                    checked={includeGiftWrap}
                    onChange={(e) => setIncludeGiftWrap(e.target.checked)}
                    className="accent-[#8c7355] w-4 h-4 rounded-xs"
                  />
                  <div className="text-xs">
                    <span className="font-semibold text-[#1a1815]">Add Custom Gift Note & Ribbon</span>
                    <span className="text-[10px] text-emerald-700 font-bold block">FREE Gift Packaging</span>
                  </div>
                </label>

                {/* Totals */}
                <div className="space-y-1.5 text-xs font-sans">
                  <div className="flex justify-between text-stone-600">
                    <span>Subtotal</span>
                    <span>₹{cartSubtotal.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between text-stone-600">
                    <span>Pan-India Express Shipping</span>
                    <span className="text-emerald-700 font-bold">FREE</span>
                  </div>
                  <div className="flex justify-between font-serif font-bold text-base text-[#1a1815] pt-2 border-t border-[#e8dfd1]">
                    <span>Total Amount</span>
                    <span>₹{cartSubtotal.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                {/* CTAs */}
                <div className="space-y-2">
                  <button
                    onClick={handleCheckout}
                    className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs uppercase tracking-widest font-semibold py-3.5 rounded-md shadow-lg transition-colors flex items-center justify-center gap-2"
                  >
                    <span>Proceed to Checkout</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <Link
                    to="/cart"
                    onClick={() => setIsCartOpen(false)}
                    className="block text-center text-xs uppercase tracking-wider font-semibold text-[#8c7a65] hover:text-[#1a1815] py-1 transition-colors"
                  >
                    View & Edit Full Bag
                  </Link>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </AnimatePresence>
    <AuthPromptModal
      isOpen={showAuthPrompt}
      onClose={() => setShowAuthPrompt(false)}
      returnTo="/checkout"
    />
    </>
  );
};
