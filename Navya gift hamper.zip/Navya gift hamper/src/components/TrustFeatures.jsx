import React from 'react';
import { motion } from 'framer-motion';
import {
  Truck,
  RotateCcw,
  CheckCircle2,
  Headphones,
  Heart,
  Lock,
  Sparkles
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const TrustFeatures = () => {
  const { storeName, tagline } = useStore();
  const trustItems = [
    {
      icon: Lock,
      heading: "Secure Payment",
      desc: "100% safe and secure checkout"
    },
    {
      icon: Truck,
      heading: "Free Delivery",
      desc: "On selected orders"
    },
    {
      icon: RotateCcw,
      heading: "Easy Returns",
      desc: "Hassle-free returns"
    },
    {
      icon: CheckCircle2,
      heading: "Quality Checked",
      desc: "Every gift carefully checked"
    },
    {
      icon: Headphones,
      heading: "Customer Support",
      desc: "24/7 help when you need it"
    },
    {
      icon: Heart,
      heading: "Curated With Love",
      desc: "Thoughtfully created for every occasion"
    }
  ];

  return (
    <section className="bg-[#F8F5F0] py-12 px-4 sm:px-6 lg:px-8 border-y border-[#E7E2DA] my-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Subtle Brand Mark above Trust Section */}
        <div className="text-center space-y-1">
          <div className="flex items-center justify-center gap-1.5 text-[10px] font-bold tracking-[0.3em] uppercase text-[#C8A45D]">
            <Sparkles className="w-3 h-3 text-[#C8A45D]" />
            <span>{storeName}</span>
          </div>
          <p className="font-serif italic text-xs sm:text-sm text-[#777777]">
            “{tagline}”
          </p>
          <div className="w-8 h-0.5 bg-[#C8A45D] mx-auto mt-2" />
        </div>

        {/* 6 Features Grid */}
        {/* Mobile: 2x3 grid | Tablet: 3x2 grid | Desktop: 6-column layout */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 lg:gap-0 lg:divide-x lg:divide-[#E7E2DA]">
          {trustItems.map((item, idx) => {
            const IconComponent = item.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.08 }}
                className="flex flex-col items-center text-center p-3 sm:p-4 group"
              >
                <div className="w-12 h-12 rounded-full bg-white text-[#C8A45D] flex items-center justify-center border border-[#E7E2DA] shadow-xs group-hover:bg-[#171717] group-hover:border-[#171717] transition-all duration-300 mb-3">
                  <IconComponent className="w-5 h-5 stroke-[1.75]" />
                </div>
                <h4 className="font-serif font-bold text-xs sm:text-sm text-[#171717] uppercase tracking-wider mb-1">
                  {item.heading}
                </h4>
                <p className="text-[11px] text-[#777777] font-sans leading-tight max-w-[150px]">
                  {item.desc}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
