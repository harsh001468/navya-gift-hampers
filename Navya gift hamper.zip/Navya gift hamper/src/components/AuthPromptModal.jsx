import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, X, ArrowRight, UserPlus, ShoppingBag } from 'lucide-react';

export const AuthPromptModal = ({ isOpen, onClose, returnTo = '/checkout' }) => {
  const navigate = useNavigate();

  if (!isOpen) return null;

  const handleLogin = () => {
    onClose();
    navigate(`/login?returnTo=${encodeURIComponent(returnTo)}`);
  };

  const handleSignUp = () => {
    onClose();
    navigate(`/signup?returnTo=${encodeURIComponent(returnTo)}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      <div
        className="bg-[#faf8f5] border border-[#e8dfd1] rounded-2xl w-full max-w-md p-6 sm:p-8 shadow-2xl relative space-y-6 text-center"
        role="dialog"
        aria-modal="true"
        aria-labelledby="auth-modal-title"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-800 rounded-full hover:bg-stone-100 transition-colors"
          aria-label="Close authentication prompt"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Icon */}
        <div className="w-14 h-14 rounded-full bg-[#1a1815] text-[#c5a880] mx-auto flex items-center justify-center shadow-md">
          <Lock className="w-6 h-6" />
        </div>

        {/* Header */}
        <div className="space-y-2">
          <h3 id="auth-modal-title" className="font-serif text-2xl font-bold text-[#1a1815] uppercase tracking-wide">
            Login Required
          </h3>
          <p className="text-xs sm:text-sm text-stone-600 font-sans leading-relaxed max-w-xs mx-auto">
            Please login or create an account to continue with your order.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pt-2 font-sans">
          <button
            onClick={handleLogin}
            className="w-full bg-[#1a1815] hover:bg-[#8c7355] text-white text-xs font-bold uppercase tracking-widest py-3.5 rounded-lg shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Login</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={handleSignUp}
            className="w-full bg-white hover:bg-[#f5f0e6] text-[#1a1815] border border-[#d8cbb8] text-xs font-bold uppercase tracking-widest py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <UserPlus className="w-4 h-4 text-[#8c7355]" />
            <span>Create Account</span>
          </button>

          <button
            onClick={onClose}
            className="w-full text-stone-500 hover:text-stone-900 text-xs font-semibold py-2 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-stone-400" />
            <span>Continue Shopping</span>
          </button>
        </div>

        {/* Assurance */}
        <div className="pt-2 border-t border-[#e8dfd1] text-[11px] text-stone-500 font-sans">
          ✨ Your bag items will be safely preserved when you sign in.
        </div>
      </div>
    </div>
  );
};
