import React from 'react';

export const LoadingSkeleton = ({ count = 8 }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {Array.from({ length: count }).map((_, index) => (
        <div
          key={index}
          className="bg-white rounded-lg overflow-hidden border border-[#e8dfd1] animate-pulse space-y-3"
        >
          <div className="aspect-4/5 bg-stone-200 w-full" />
          <div className="p-4 space-y-2">
            <div className="h-3 bg-stone-200 rounded-xs w-1/3" />
            <div className="h-4 bg-stone-200 rounded-xs w-3/4" />
            <div className="h-4 bg-stone-200 rounded-xs w-1/2" />
          </div>
        </div>
      ))}
    </div>
  );
};
