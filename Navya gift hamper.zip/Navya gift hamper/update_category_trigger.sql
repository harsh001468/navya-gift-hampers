-- Allow CLI migrations while strictly blocking untrusted client sessions
CREATE OR REPLACE FUNCTION public.check_category_modification()
RETURNS TRIGGER AS $$
BEGIN
  IF current_user IN ('anon', 'authenticated') THEN
    IF NOT public.is_owner() THEN
      RAISE EXCEPTION 'Access Denied: Only store owners can modify categories';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.check_category_deletion()
RETURNS TRIGGER AS $$
BEGIN
  IF current_user IN ('anon', 'authenticated') THEN
    IF NOT public.is_owner() THEN
      RAISE EXCEPTION 'Access Denied: Only store owners can delete categories';
    END IF;
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Deactivate unavailable and empty categories
UPDATE public.categories 
SET is_active = false 
WHERE slug IN ('wedding-hampers', 'corporate-gifts', 'chocolate-hampers', 'hacked');
