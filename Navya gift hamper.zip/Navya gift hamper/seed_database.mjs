import { createClient } from '@insforge/sdk';

const baseUrl = 'https://94es5db4.us-east.insforge.app';
const apiKey = 'ik_0edb792bf35f9a21b037cd871577e781';

const insforge = createClient({
  baseUrl,
  anonKey: apiKey
});

async function main() {
  console.log('Seeding products to InsForge database...');

  // Import products dynamically
  const { products } = await import('./src/data/products.js');

  console.log(`Found ${products.length} products to seed.`);

  // Prepare database products array
  const dbProducts = products.map((p) => ({
    name: p.name,
    category: p.category,
    subcategory: p.subcategory || 'Hampers',
    gender: p.gender || 'Unisex',
    price: p.price,
    original_price: p.originalPrice || null,
    rating: p.rating || 5.0,
    reviews_count: p.reviewsCount || 0,
    description: p.description || '',
    full_description: p.fullDescription || '',
    is_featured: !!p.isFeatured,
    is_new: !!p.isNew,
    is_bestseller: !!p.isBestseller,
    sizes: p.sizes || [],
    colors: p.colors || [],
    tags: p.tags || [],
    images: p.images || [],
    in_stock: p.inStock !== false
  }));

  const { data, error } = await insforge.database
    .from('products')
    .insert(dbProducts);

  if (error) {
    console.error('Error inserting products:', error);
  } else {
    console.log('Products seeded successfully! Count:', data ? data.length : dbProducts.length);
  }
}

main().catch(console.error);
