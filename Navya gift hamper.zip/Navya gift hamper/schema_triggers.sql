-- ==============================================================================
-- HARD DATABASE ENFORCEMENT TRIGGERS (ROLE = OWNER ONLY)
-- ==============================================================================

-- 1. Product modifications trigger
CREATE OR REPLACE FUNCTION public.check_product_modification()
RETURNS TRIGGER AS $$
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Access Denied: Only store owners can modify products';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.check_product_deletion()
RETURNS TRIGGER AS $$
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Access Denied: Only store owners can delete products';
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_protect_products_update ON public.products;
CREATE TRIGGER trg_protect_products_update
BEFORE UPDATE ON public.products
FOR EACH ROW
EXECUTE FUNCTION public.check_product_modification();

DROP TRIGGER IF EXISTS trg_protect_products_insert ON public.products;
CREATE TRIGGER trg_protect_products_insert
BEFORE INSERT ON public.products
FOR EACH ROW
EXECUTE FUNCTION public.check_product_modification();

DROP TRIGGER IF EXISTS trg_protect_products_delete ON public.products;
CREATE TRIGGER trg_protect_products_delete
BEFORE DELETE ON public.products
FOR EACH ROW
EXECUTE FUNCTION public.check_product_deletion();

-- 2. Category modifications trigger
CREATE OR REPLACE FUNCTION public.check_category_modification()
RETURNS TRIGGER AS $$
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Access Denied: Only store owners can modify categories';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.check_category_deletion()
RETURNS TRIGGER AS $$
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Access Denied: Only store owners can delete categories';
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_protect_categories_update ON public.categories;
CREATE TRIGGER trg_protect_categories_update
BEFORE UPDATE ON public.categories
FOR EACH ROW
EXECUTE FUNCTION public.check_category_modification();

DROP TRIGGER IF EXISTS trg_protect_categories_insert ON public.categories;
CREATE TRIGGER trg_protect_categories_insert
BEFORE INSERT ON public.categories
FOR EACH ROW
EXECUTE FUNCTION public.check_category_modification();

DROP TRIGGER IF EXISTS trg_protect_categories_delete ON public.categories;
CREATE TRIGGER trg_protect_categories_delete
BEFORE DELETE ON public.categories
FOR EACH ROW
EXECUTE FUNCTION public.check_category_deletion();

-- 3. Force Row Level Security on all tables
ALTER TABLE public.products FORCE ROW LEVEL SECURITY;
ALTER TABLE public.categories FORCE ROW LEVEL SECURITY;
ALTER TABLE public.orders FORCE ROW LEVEL SECURITY;
ALTER TABLE public.order_items FORCE ROW LEVEL SECURITY;
ALTER TABLE public.profiles FORCE ROW LEVEL SECURITY;
ALTER TABLE public.reviews FORCE ROW LEVEL SECURITY;
ALTER TABLE public.store_settings FORCE ROW LEVEL SECURITY;
