-- 1. Create payments table
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES orders(id) ON DELETE SET NULL,
  user_id UUID,
  amount NUMERIC(10, 2) NOT NULL,
  currency TEXT DEFAULT 'INR',
  method TEXT DEFAULT 'UPI',
  provider TEXT DEFAULT 'Google Pay / UPI',
  upi_id TEXT DEFAULT 'vishualk375-2@okaxis',
  transaction_id TEXT UNIQUE,
  status TEXT DEFAULT 'pending',
  is_simulation BOOLEAN DEFAULT true,
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on payments
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read payments" ON payments;
CREATE POLICY "Allow public read payments" ON payments FOR SELECT USING (true);

DROP POLICY IF EXISTS "Allow public insert payments" ON payments;
CREATE POLICY "Allow public insert payments" ON payments FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Allow public update payments" ON payments;
CREATE POLICY "Allow public update payments" ON payments FOR UPDATE USING (true);

-- 2. Create coupons / discount codes table
CREATE TABLE IF NOT EXISTS coupons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  discount_type TEXT NOT NULL DEFAULT 'percentage', -- 'percentage' | 'fixed'
  discount_value NUMERIC(10, 2) NOT NULL,
  min_order_amount NUMERIC(10, 2) DEFAULT 0,
  max_discount_amount NUMERIC(10, 2),
  is_active BOOLEAN DEFAULT true,
  expiry_date TIMESTAMPTZ,
  usage_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on coupons
ALTER TABLE coupons ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow public read coupons" ON coupons;
CREATE POLICY "Allow public read coupons" ON coupons FOR SELECT USING (true);

-- 3. Insert sample data into payments
INSERT INTO payments (amount, currency, method, provider, upi_id, transaction_id, status, is_simulation, paid_at)
VALUES 
  (1299.00, 'INR', 'UPI', 'Google Pay / UPI', 'vishualk375-2@okaxis', 'SIM-NF-20260919-52871', 'paid', true, NOW() - INTERVAL '1 hour'),
  (2499.00, 'INR', 'UPI', 'Google Pay / UPI', 'vishualk375-2@okaxis', 'SIM-NF-20260919-81934', 'paid', true, NOW() - INTERVAL '3 hours'),
  (899.00, 'INR', 'UPI', 'Google Pay / UPI', 'vishualk375-2@okaxis', 'SIM-NF-20260920-10945', 'pending', true, NULL)
ON CONFLICT (transaction_id) DO NOTHING;

-- 4. Insert sample data into coupons
INSERT INTO coupons (code, discount_type, discount_value, min_order_amount, is_active, expiry_date)
VALUES
  ('NAVYA10', 'percentage', 10.00, 999.00, true, NOW() + INTERVAL '30 days'),
  ('ROYAL500', 'fixed', 500.00, 2999.00, true, NOW() + INTERVAL '60 days'),
  ('WELCOMEGIFT', 'percentage', 15.00, 499.00, true, NOW() + INTERVAL '90 days')
ON CONFLICT (code) DO NOTHING;
