import { createClient } from '@insforge/sdk';

const baseUrl = 'https://94es5db4.us-east.insforge.app';
const apiKey = 'ik_0edb792bf35f9a21b037cd871577e781';

const insforge = createClient({
  baseUrl,
  anonKey: apiKey
});

async function main() {
  console.log('Seeding customer reviews to InsForge database...');

  const initialReviews = [
    {
      author_name: 'Priya Sharma',
      author_location: 'Mumbai',
      rating: 5,
      title: 'Beautiful packaging & presentation',
      comment: 'Beautiful packaging and the hamper looked even better than I expected. My sister loved it!',
      is_verified_buyer: true
    },
    {
      author_name: 'Rahul Verma',
      author_location: 'Delhi NCR',
      rating: 5,
      title: 'Perfect anniversary gift',
      comment: 'The perfect anniversary gift. Everything was beautifully arranged and the leather quality is top-notch.',
      is_verified_buyer: true
    },
    {
      author_name: 'Ananya Mehta',
      author_location: 'Bangalore',
      rating: 5,
      title: 'Loved the personalized note',
      comment: 'Loved the personalized parchment note touch. Highly recommended for special occasions!',
      is_verified_buyer: true
    },
    {
      author_name: 'Sneha Roy',
      author_location: 'Kolkata',
      rating: 5,
      title: 'Ultra-luxurious hamper',
      comment: 'Bought this for my best friend\'s birthday. The chocolates were rich and the packaging felt ultra-luxurious.',
      is_verified_buyer: true
    },
    {
      author_name: 'Vikramaditya Singh',
      author_location: 'Jaipur',
      rating: 5,
      title: 'Exceeded expectations',
      comment: 'Exceeded all expectations. Fast delivery in Jaipur and pristine condition.',
      is_verified_buyer: true
    }
  ];

  const { data: _data, error } = await insforge.database
    .from('reviews')
    .insert(initialReviews);

  if (error) {
    console.error('Error inserting reviews:', error);
  } else {
    console.log('Reviews seeded successfully!');
  }
}

main().catch(console.error);
