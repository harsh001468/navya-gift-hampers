-- ==============================================================================
-- ADD COMPREHENSIVE PRODUCT MANAGEMENT COLUMNS & UPDATE TRIGGER
-- ==============================================================================

-- Allow CLI migrations while strictly blocking untrusted client sessions
CREATE OR REPLACE FUNCTION public.check_product_modification()
RETURNS TRIGGER AS $$
BEGIN
  IF current_user IN ('anon', 'authenticated') THEN
    IF NOT public.is_owner() THEN
      RAISE EXCEPTION 'Access Denied: Only store owners can modify products';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.check_product_deletion()
RETURNS TRIGGER AS $$
BEGIN
  IF current_user IN ('anon', 'authenticated') THEN
    IF NOT public.is_owner() THEN
      RAISE EXCEPTION 'Access Denied: Only store owners can delete products';
    END IF;
  END IF;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

ALTER TABLE public.products ADD COLUMN IF NOT EXISTS discount_percentage NUMERIC DEFAULT 0;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS specifications JSONB DEFAULT '[]'::jsonb;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS weight_size TEXT;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS delivery_info TEXT DEFAULT 'Standard 7–15 days delivery across India. Gift-ready protective packaging.';
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS personalization_options JSONB DEFAULT '{"allow_name": true, "allow_note": true}'::jsonb;

-- Populate discount_percentage for existing products if original_price > price
UPDATE public.products 
SET discount_percentage = ROUND(((original_price - price) / original_price) * 100)
WHERE original_price IS NOT NULL AND original_price > price;
