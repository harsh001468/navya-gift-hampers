-- ==============================================================================
-- NAVYA GIFT HAMPER - OWNER ADMIN BACKEND SECURITY & SCHEMA MIGRATION
-- ==============================================================================

-- 1. Ensure 'role' column on profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'customer';
UPDATE public.profiles SET role = 'customer' WHERE role IS NULL;

-- Mark official store owner account
UPDATE public.profiles 
SET role = 'owner' 
WHERE email = 'supportnavya0@gmail.com';

-- 2. Create is_owner() helper function (SECURITY DEFINER)
CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() AND role = 'owner'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- 3. Prevent privilege escalation on profiles
CREATE OR REPLACE FUNCTION public.prevent_role_escalation()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.role IS DISTINCT FROM OLD.role THEN
    IF NOT public.is_owner() THEN
      NEW.role := OLD.role;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_prevent_role_escalation ON public.profiles;
CREATE TRIGGER trg_prevent_role_escalation
BEFORE UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.prevent_role_escalation();

CREATE OR REPLACE FUNCTION public.set_default_customer_role()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.role IS NULL OR NEW.role != 'customer' THEN
    IF NOT public.is_owner() THEN
      NEW.role := 'customer';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_set_default_role ON public.profiles;
CREATE TRIGGER trg_set_default_role
BEFORE INSERT ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.set_default_customer_role();

-- 4. Update profiles RLS: owner can view all customer profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "profiles_select_policy" ON public.profiles;
CREATE POLICY "profiles_select_policy" ON public.profiles FOR SELECT TO authenticated USING (
  auth.uid() = id OR public.is_owner()
);

-- 5. Products table columns and RLS
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS stock_quantity INTEGER DEFAULT 25;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS sku TEXT;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active';
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_archived BOOLEAN DEFAULT false;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- Enable RLS on products
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "products_public_select" ON public.products;
CREATE POLICY "products_public_select" ON public.products FOR SELECT USING (true);

DROP POLICY IF EXISTS "products_owner_insert" ON public.products;
CREATE POLICY "products_owner_insert" ON public.products FOR INSERT TO authenticated WITH CHECK (public.is_owner());

DROP POLICY IF EXISTS "products_owner_update" ON public.products;
CREATE POLICY "products_owner_update" ON public.products FOR UPDATE TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());

DROP POLICY IF EXISTS "products_owner_delete" ON public.products;
CREATE POLICY "products_owner_delete" ON public.products FOR DELETE TO authenticated USING (public.is_owner());

-- 6. Categories table
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  image TEXT,
  is_active BOOLEAN DEFAULT true,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "categories_public_select" ON public.categories;
CREATE POLICY "categories_public_select" ON public.categories FOR SELECT USING (true);

DROP POLICY IF EXISTS "categories_owner_insert" ON public.categories;
CREATE POLICY "categories_owner_insert" ON public.categories FOR INSERT TO authenticated WITH CHECK (public.is_owner());

DROP POLICY IF EXISTS "categories_owner_update" ON public.categories;
CREATE POLICY "categories_owner_update" ON public.categories FOR UPDATE TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());

DROP POLICY IF EXISTS "categories_owner_delete" ON public.categories;
CREATE POLICY "categories_owner_delete" ON public.categories FOR DELETE TO authenticated USING (public.is_owner());

-- Seed initial categories if table is empty
INSERT INTO public.categories (name, slug, description, image, display_order)
VALUES
  ('Men''s Hampers', 'mens-hampers', 'Premium shirts, grooming essentials, watches, wallets and more — curated for him.', 'https://lh3.googleusercontent.com/d/1pfwZEh4ESO4mBe3KLqAUXln5VgfUTrsB', 1),
  ('Women''s Hampers', 'womens-hampers', 'Ethnic wear, perfumes, accessories and self-care hampers for every occasion.', 'https://lh3.googleusercontent.com/d/10grmCxscyvNePDD6GZcjnT72NoUl1N81', 2),
  ('Personalized Hampers', 'personalized-hampers', 'Custom engraved gifts, name wallets, photo frames and monogrammed keepsakes.', 'https://lh3.googleusercontent.com/d/1iE5cuh0nsMcSwCVcS3o_-TGDTTpLUNif', 3),
  ('Couple Gifts', 'couple-gifts', 'Romantic hampers with watches, rings, chocolates and roses for anniversaries.', 'https://lh3.googleusercontent.com/d/1hFQSOw9t5FQYxBq2FOevNdpGJwajmLn-', 4),
  ('Birthday Hampers', 'birthday-hampers', 'Make their birthday unforgettable with curated birthday surprise hampers.', 'https://lh3.googleusercontent.com/d/1f1O37s4_tm9g1eXwHlxfnUnj53xuiME6', 5),
  ('Anniversary Hampers', 'anniversary-hampers', 'Celebrate years of love with bespoke couple and luxury gift sets.', 'https://lh3.googleusercontent.com/d/1k64HD9ZVn8eFCbSWIWv3p0Fswq-Bez4s', 6),
  ('Wedding Hampers', 'wedding-hampers', 'Regal and traditional wedding blessings packaged in luxury boxes.', 'https://lh3.googleusercontent.com/d/12sQoN5t-5r2p736C5_Vl2M-hU-2X01Y-', 7),
  ('Corporate Gifts', 'corporate-gifts', 'Executive gifts, customized desk accessories and professional hampers.', 'https://lh3.googleusercontent.com/d/11w43-d3mR1FkH80aV5R2_u0-tG9t2K6N', 8),
  ('Chocolate Hampers', 'chocolate-hampers', 'Artisanal chocolates, dry fruit selections, and gourmet sweets.', 'https://lh3.googleusercontent.com/d/1j9X5eL-7_O5hQ708V9r-1s2a8d-7xL2m', 9),
  ('Premium Hampers', 'premium-hampers', 'Our flagship luxury collection featuring gold foil boxes and premium items.', 'https://lh3.googleusercontent.com/d/1gTg36hGOdB7k6B0_dbxcXF7CY868A9Ax', 10)
ON CONFLICT (name) DO NOTHING;

-- 7. Orders RLS and update protection
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "orders_user_select" ON public.orders;
CREATE POLICY "orders_user_select" ON public.orders FOR SELECT TO authenticated USING (
  public.is_owner() OR auth.uid() = user_id
);

DROP POLICY IF EXISTS "orders_owner_update" ON public.orders;
CREATE POLICY "orders_owner_update" ON public.orders FOR UPDATE TO authenticated USING (
  public.is_owner() OR auth.uid() = user_id
);

-- Trigger to prevent customers from tampering with order status
CREATE OR REPLACE FUNCTION public.check_order_status_update()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    IF NOT public.is_owner() THEN
      RAISE EXCEPTION 'Only store owner can change order status';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_check_order_status ON public.orders;
CREATE TRIGGER trg_check_order_status
BEFORE UPDATE ON public.orders
FOR EACH ROW
EXECUTE FUNCTION public.check_order_status_update();

-- 8. Order items RLS
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "order_items_user_select" ON public.order_items;
CREATE POLICY "order_items_user_select" ON public.order_items FOR SELECT TO authenticated USING (
  public.is_owner() OR EXISTS (
    SELECT 1 FROM public.orders WHERE orders.id = order_items.order_id AND orders.user_id = auth.uid()
  )
);

-- 9. Reviews: status column and RLS
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'approved';
UPDATE public.reviews SET status = 'approved' WHERE status IS NULL;

ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "reviews_public_select" ON public.reviews;
CREATE POLICY "reviews_public_select" ON public.reviews FOR SELECT USING (
  status = 'approved' OR public.is_owner() OR auth.uid() = user_id
);

DROP POLICY IF EXISTS "reviews_owner_update" ON public.reviews;
CREATE POLICY "reviews_owner_update" ON public.reviews FOR UPDATE TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());

DROP POLICY IF EXISTS "reviews_owner_delete" ON public.reviews;
CREATE POLICY "reviews_owner_delete" ON public.reviews FOR DELETE TO authenticated USING (public.is_owner());

-- 10. Store settings table
CREATE TABLE IF NOT EXISTS public.store_settings (
  id TEXT PRIMARY KEY,
  data JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "store_settings_public_select" ON public.store_settings;
CREATE POLICY "store_settings_public_select" ON public.store_settings FOR SELECT USING (true);

DROP POLICY IF EXISTS "store_settings_owner_write" ON public.store_settings;
CREATE POLICY "store_settings_owner_write" ON public.store_settings FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());

-- Seed initial settings if missing
INSERT INTO public.store_settings (id, data)
VALUES
  ('general', '{"store_name": "Navya Gift Hamper", "email": "Supportnavya0@gmail.com", "phone": "+91 97728 48274", "instagram": "@navyagift_hamper", "address": "Jaipur, Rajasthan, India", "tagline": "Bespoke Engraving & Luxury Personalized Gifts"}'::jsonb),
  ('delivery', '{"standard_fee": 0, "express_fee": 149, "free_shipping_threshold": 999, "estimated_days": "7–15 Days"}'::jsonb),
  ('inventory', '{"low_stock_threshold": 5}'::jsonb),
  ('orders', '{"allow_notes": true, "auto_invoice": true}'::jsonb)
ON CONFLICT (id) DO NOTHING;
